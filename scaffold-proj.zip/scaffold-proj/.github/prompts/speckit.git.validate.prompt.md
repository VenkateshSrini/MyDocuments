---
agent: speckit.git.validate
---
