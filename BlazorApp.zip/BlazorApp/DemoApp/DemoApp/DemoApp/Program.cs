using DemoApp.Client.Pages;
using DemoApp.Components;
using System.Runtime.InteropServices;


var builder = WebApplication.CreateBuilder(args);
var runtime = RuntimeInformation.FrameworkDescription;
Console.WriteLine($"Runtime: {runtime}");
// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddRazorComponents()
    .AddInteractiveWebAssemblyComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();
app.MapControllers();
app.MapRazorComponents<App>()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(DemoApp.Client._Imports).Assembly);

app.Run();
