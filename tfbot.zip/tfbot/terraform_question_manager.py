"""
Question Manager for Terraform Bot
Generates and manages questions based on Terraform template analysis
"""
import os
from typing import Dict, List
from terraform_parser import TerraformTemplateParser
from llm_manager import LLMManager
from config import GENERATED_QUESTIONS_FILE, TEMPLATE_DIR

class TerraformQuestionManager:
    """Manages question generation and collection for Terraform variables"""
    
    def __init__(self, llm_manager: LLMManager, terraform_parser: TerraformTemplateParser):
        self.llm_manager = llm_manager
        self.terraform_parser = terraform_parser
        self.questions_file = os.path.join(TEMPLATE_DIR, GENERATED_QUESTIONS_FILE)
        
    def ensure_questions_exist(self) -> str:
        """Ensure questions file exists, generate if needed"""
        if os.path.exists(self.questions_file):
            print(f"✅ Questions file already exists: {self.questions_file}")
            return self.questions_file
        
        print("📝 Generating questions from Terraform templates...")
        self.generate_questions()
        return self.questions_file
    
    def generate_questions(self):
        """Generate questions based on Terraform template analysis"""
        print("🔍 Analyzing Terraform templates...")
        analysis = self.terraform_parser.analyze_template()
        
        if not analysis['variables']:
            print("❌ No variables found in Terraform templates.")
            return
        
        print(f"📊 Found {analysis['total_variables']} variables in {analysis['total_resources']} resources")
        
        # Generate questions using LLM
        questions = self._generate_questions_with_llm(analysis)
        
        # Save questions to file
        self._save_questions_to_file(questions)
        print(f"✅ Questions generated and saved to: {self.questions_file}")
    
    def _generate_questions_with_llm(self, analysis: Dict) -> List[str]:
        """Generate questions using LLM based on template analysis"""
        
        # Create context for LLM
        context = self._create_llm_context(analysis)
        
        prompt = f"""
As an AWS Deployment Engineer expert, analyze the following Terraform template structure and generate comprehensive questions to collect user requirements for AWS infrastructure deployment.

TERRAFORM TEMPLATE ANALYSIS:
{context}

REQUIREMENTS:
1. Generate questions that help determine which AWS services the user wants to deploy
2. Ask about specific configuration requirements for each service
3. Include questions about security, networking, and compliance needs
4. Group questions logically by AWS service/category
5. Make questions clear and include helpful explanations
6. Consider dependencies between services (e.g., VPC needed for EC2)
7. Ask about environment-specific settings (dev/staging/prod)

QUESTION FORMAT:
- Start with high-level architecture questions
- Progress to service-specific detailed questions
- Include conditional questions based on service selection
- Provide context and examples where helpful
- Use clear, non-technical language when possible

Generate a comprehensive set of questions that will help collect all necessary information to deploy AWS infrastructure using this Terraform template.
"""

        llm = self.llm_manager.get_gpt35_llm()
        response = llm.invoke(prompt)
        
        # Parse the response into individual questions
        questions = self._parse_llm_response(response.content)
        return questions
    
    def _create_llm_context(self, analysis: Dict) -> str:
        """Create context string for LLM prompt"""
        context_parts = []
        
        # Variables summary
        context_parts.append(f"VARIABLES FOUND: {analysis['total_variables']}")
        context_parts.append(f"RESOURCES FOUND: {analysis['total_resources']}")
        
        # Categories
        if analysis['categories']:
            context_parts.append("\nVARIABLE CATEGORIES:")
            for category, variables in analysis['categories'].items():
                context_parts.append(f"  {category}: {', '.join(variables[:5])}{'...' if len(variables) > 5 else ''}")
        
        # Conditional services
        if analysis['conditional']:
            context_parts.append("\nCONDITIONAL SERVICES (can be enabled/disabled):")
            for service, related_vars in analysis['conditional'].items():
                context_parts.append(f"  {service.upper()}: {len(related_vars)} configuration variables")
        
        # Key variables
        required_vars = self.terraform_parser.get_required_variables()
        boolean_vars = self.terraform_parser.get_boolean_variables()
        sensitive_vars = self.terraform_parser.get_sensitive_variables()
        
        if required_vars:
            context_parts.append(f"\nREQUIRED VARIABLES: {', '.join(required_vars[:10])}")
        if boolean_vars:
            context_parts.append(f"BOOLEAN FLAGS: {', '.join(boolean_vars[:10])}")
        if sensitive_vars:
            context_parts.append(f"SENSITIVE VARIABLES: {', '.join(sensitive_vars)}")
        
        # Available AWS services
        aws_services = set()
        for resource_info in analysis['resources'].values():
            aws_services.add(resource_info['aws_service'])
        
        if aws_services:
            context_parts.append(f"\nAWS SERVICES SUPPORTED: {', '.join(sorted(aws_services))}")
        
        return '\n'.join(context_parts)
    
    def _parse_llm_response(self, response: str) -> List[str]:
        """Parse LLM response into individual questions"""
        lines = response.strip().split('\n')
        questions = []
        
        current_question = ""
        for line in lines:
            line = line.strip()
            
            # Skip empty lines and headers
            if not line or line.startswith('#') or line.startswith('**'):
                if current_question:
                    questions.append(current_question.strip())
                    current_question = ""
                continue
            
            # Check if line starts with a number or bullet point (new question)
            if (line[0].isdigit() and '.' in line) or line.startswith('- ') or line.startswith('• '):
                if current_question:
                    questions.append(current_question.strip())
                current_question = line
            else:
                # Continue previous question
                if current_question:
                    current_question += " " + line
                else:
                    current_question = line
        
        # Add the last question
        if current_question:
            questions.append(current_question.strip())
        
        # Clean up questions
        cleaned_questions = []
        for q in questions:
            # Remove numbering and bullet points
            q = q.lstrip('0123456789.- •').strip()
            if q and '?' in q:  # Only keep actual questions
                cleaned_questions.append(q)
        
        return cleaned_questions
    
    def _save_questions_to_file(self, questions: List[str]):
        """Save questions to file"""
        os.makedirs(os.path.dirname(self.questions_file), exist_ok=True)
        
        with open(self.questions_file, 'w', encoding='utf-8') as f:
            f.write("# Terraform AWS Infrastructure Questions\n")
            f.write("# Generated automatically based on template analysis\n\n")
            
            for i, question in enumerate(questions, 1):
                f.write(f"{i}. {question}\n\n")
    
    def collect_answers(self, questions_file: str) -> Dict[str, str]:
        """Collect answers from user for the questions"""
        if not os.path.exists(questions_file):
            print(f"❌ Questions file not found: {questions_file}")
            return {}
        
        print("\n" + "="*60)
        print("🚀 TERRAFORM AWS INFRASTRUCTURE CONFIGURATION")
        print("="*60)
        print("Please answer the following questions to configure your AWS infrastructure:")
        print()
        
        answers = {}
        
        with open(questions_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Parse questions from file
        questions = self._parse_questions_from_file(content)
        
        for i, question in enumerate(questions, 1):
            print(f"\n📋 Question {i}/{len(questions)}:")
            print(f"   {question}")
            
            # Get user input
            while True:
                answer = input("\n💡 Your answer: ").strip()
                if answer:
                    answers[f"question_{i}"] = answer
                    break
                else:
                    print("   ⚠️  Please provide an answer.")
        
        print(f"\n✅ Collected {len(answers)} answers!")
        return answers
    
    def _parse_questions_from_file(self, content: str) -> List[str]:
        """Parse questions from the generated file"""
        lines = content.split('\n')
        questions = []
        
        for line in lines:
            line = line.strip()
            # Look for numbered questions
            if line and line[0].isdigit() and '.' in line:
                # Extract question text
                question = line.split('.', 1)[1].strip()
                if question:
                    questions.append(question)
        
        return questions
    
    def get_variable_questions(self) -> Dict[str, str]:
        """Generate specific questions for each Terraform variable"""
        variable_questions = {}
        
        for var_name, var_info in self.terraform_parser.variables.items():
            question = self._generate_variable_question(var_name, var_info)
            variable_questions[var_name] = question
        
        return variable_questions
    
    def _generate_variable_question(self, var_name: str, var_info: Dict) -> str:
        """Generate a specific question for a Terraform variable"""
        description = var_info.get('description', '')
        var_type = var_info.get('type', 'string')
        default = var_info.get('default')
        
        # Base question
        question = f"What should be the value for '{var_name}'?"
        
        # Add description if available
        if description:
            question += f" ({description})"
        
        # Add type information
        if 'bool' in var_type:
            question += " [yes/no]"
        elif default is not None:
            question += f" [default: {default}]"
        
        return question
