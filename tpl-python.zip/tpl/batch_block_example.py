"""
Batch Block Example using concurrent.futures
Equivalent to TPL's BatchBlock<T> in .NET

This example demonstrates how to process items in batches using Python's concurrent.futures.
The BatchBlock groups incoming items into batches of a specified size and processes them together.
"""

import concurrent.futures
import time
from typing import List, Any, Iterator, Callable
from itertools import islice


class BatchBlock:
    """
    A batch processing block that groups items into batches and processes them concurrently.
    
    Similar to TPL's BatchBlock<T>, this collects items into groups of a specified size
    and processes each batch as a unit.
    """
    
    def __init__(self, batch_size: int, max_workers: int = None):
        """
        Initialize the batch block.
        
        Args:
            batch_size: Number of items per batch
            max_workers: Maximum number of worker threads (None for default)
        """
        self.batch_size = batch_size
        self.max_workers = max_workers
    
    def _create_batches(self, items: List[Any]) -> Iterator[List[Any]]:
        """Create batches from the input items."""
        iterator = iter(items)
        while True:
            batch = list(islice(iterator, self.batch_size))
            if not batch:
                break
            yield batch
    
    def process_batches(self, items: List[Any], batch_processor: Callable[[List[Any]], Any]) -> List[Any]:
        """
        Process items in batches using the provided batch processor function.
        
        Args:
            items: List of items to process
            batch_processor: Function that processes a batch and returns a result
            
        Returns:
            List of results from processing each batch
        """
        batches = list(self._create_batches(items))
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all batches for processing
            future_to_batch = {
                executor.submit(batch_processor, batch): batch 
                for batch in batches
            }
            
            # Collect results as they complete
            results = []
            for future in concurrent.futures.as_completed(future_to_batch):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as exc:
                    batch = future_to_batch[future]
                    print(f'Batch {batch} generated an exception: {exc}')
                    results.append(None)
            
            return results


def example_batch_processor(batch: List[int]) -> dict:
    """
    Example batch processor that simulates some work on a batch of numbers.
    
    Args:
        batch: List of integers to process
        
    Returns:
        Dictionary with batch statistics
    """
    # Simulate some processing time
    time.sleep(0.5)
    
    return {
        'batch_size': len(batch),
        'sum': sum(batch),
        'avg': sum(batch) / len(batch) if batch else 0,
        'min': min(batch) if batch else None,
        'max': max(batch) if batch else None,
        'processed_at': time.time()
    }


def example_string_batch_processor(batch: List[str]) -> dict:
    """
    Example batch processor for strings.
    
    Args:
        batch: List of strings to process
        
    Returns:
        Dictionary with batch processing results
    """
    # Simulate processing time
    time.sleep(0.3)
    
    return {
        'batch_size': len(batch),
        'total_length': sum(len(s) for s in batch),
        'uppercase_count': sum(1 for s in batch if s.isupper()),
        'processed_items': [s.upper() for s in batch],
        'processed_at': time.time()
    }


if __name__ == "__main__":
    print("=== Batch Block Example ===\n")
    
    # Example 1: Processing numbers in batches
    print("1. Processing numbers in batches of 3:")
    numbers = list(range(1, 16))  # 1 to 15
    print(f"Input numbers: {numbers}")
    
    batch_block = BatchBlock(batch_size=3, max_workers=2)
    start_time = time.time()
    
    results = batch_block.process_batches(numbers, example_batch_processor)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print("Results:")
    for i, result in enumerate(results):
        print(f"  Batch {i+1}: {result}")
    
    print("\n" + "="*50 + "\n")
    
    # Example 2: Processing strings in batches
    print("2. Processing strings in batches of 4:")
    strings = ["apple", "banana", "cherry", "date", "elderberry", 
               "fig", "grape", "honeydew", "kiwi", "lemon"]
    print(f"Input strings: {strings}")
    
    string_batch_block = BatchBlock(batch_size=4, max_workers=3)
    start_time = time.time()
    
    string_results = string_batch_block.process_batches(strings, example_string_batch_processor)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print("Results:")
    for i, result in enumerate(string_results):
        print(f"  Batch {i+1}: {result}")
    
    print("\n" + "="*50 + "\n")
    
    # Example 3: Demonstrating parallel processing benefits
    print("3. Comparing sequential vs parallel processing:")
    
    def slow_batch_processor(batch: List[int]) -> int:
        """A slow processor to demonstrate parallelism benefits."""
        time.sleep(1)  # Simulate slow work
        return sum(batch)
    
    test_numbers = list(range(1, 13))  # 12 numbers
    
    # Sequential processing
    print("Sequential processing...")
    start_time = time.time()
    sequential_results = []
    for batch in BatchBlock(batch_size=3)._create_batches(test_numbers):
        sequential_results.append(slow_batch_processor(batch))
    sequential_time = time.time() - start_time
    
    # Parallel processing
    print("Parallel processing...")
    parallel_batch_block = BatchBlock(batch_size=3, max_workers=4)
    start_time = time.time()
    parallel_results = parallel_batch_block.process_batches(test_numbers, slow_batch_processor)
    parallel_time = time.time() - start_time
    
    print(f"Sequential time: {sequential_time:.2f} seconds")
    print(f"Parallel time: {parallel_time:.2f} seconds")
    print(f"Speedup: {sequential_time / parallel_time:.2f}x")
    print(f"Sequential results: {sequential_results}")
    print(f"Parallel results: {parallel_results}")
