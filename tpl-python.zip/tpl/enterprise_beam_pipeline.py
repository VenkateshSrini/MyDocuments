"""
Enterprise Apache Beam Complex Pipeline Implementation
Advanced TPL-like functionality with comprehensive enterprise features

This module demonstrates complex Apache Beam usage with:
- Multi-stage processing pipelines
- Advanced error handling and recovery
- Real-time monitoring and alerting
- Configuration-driven processing
- Production-ready patterns
"""

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, SetupOptions
from apache_beam.transforms import window, trigger
import time
import logging
import argparse
import json
import os
from typing import List, Any, Dict, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import uuid


# Configure enterprise-grade logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s:%(lineno)d] - %(message)s'
)
logger = logging.getLogger(__name__)


class ProcessingStage(Enum):
    """Enumeration of processing stages for better tracking."""
    VALIDATION = "validation"
    ENRICHMENT = "enrichment"
    TRANSFORMATION = "transformation"
    AGGREGATION = "aggregation"
    QUALITY_CONTROL = "quality_control"


@dataclass
class EnterpriseConfig:
    """
    Comprehensive enterprise configuration.
    
    This is like the master control panel for your entire data processing factory.
    Every aspect of processing can be configured here without touching the code.
    """
    # Processing Configuration
    batch_size: int = 15
    max_workers: int = 6
    timeout_seconds: int = 600
    
    # Performance Configuration
    processing_delay: float = 0.05  # Reduced for better performance
    enable_fast_processing: bool = True
    max_parallelism: int = 20
    
    # Quality Control Configuration
    error_threshold: float = 0.05  # 5% error rate threshold
    quality_score_threshold: float = 0.8  # Minimum quality score
    enable_quality_gates: bool = True
    
    # Monitoring Configuration
    enable_detailed_monitoring: bool = True
    metrics_namespace: str = "enterprise_pipeline"
    alert_on_errors: bool = True
    
    # Data Configuration
    min_batch_size: int = 5
    max_batch_size: int = 25
    enable_data_validation: bool = True
    
    # Output Configuration
    output_directory: str = "/tmp/enterprise_beam_complex"
    enable_detailed_output: bool = True
    compress_output: bool = False


class DataValidationProcessor(beam.DoFn):
    """
    Enterprise data validation processor.
    
    This is like the quality inspection station at the beginning of your factory
    that ensures only good quality raw materials enter the processing line.
    """
    
    def __init__(self, config: EnterpriseConfig):
        self.config = config
        self.valid_counter = beam.metrics.Metrics.counter(config.metrics_namespace, 'items_validated')
        self.invalid_counter = beam.metrics.Metrics.counter(config.metrics_namespace, 'items_rejected')
        self.validation_timer = beam.metrics.Metrics.distribution(config.metrics_namespace, 'validation_time_ms')
    
    def setup(self):
        logger.info("🔍 DataValidationProcessor starting - Quality control active")
    
    def process(self, element: Any):
        """Validate input data with enterprise-grade checks."""
        start_time = time.time()
        
        try:
            validation_result = self._comprehensive_validation(element)
            
            if validation_result['is_valid']:
                self.valid_counter.inc()
                
                enriched_element = {
                    'original_value': element,
                    'validation_id': str(uuid.uuid4()),
                    'validation_timestamp': time.time(),
                    'validation_stage': ProcessingStage.VALIDATION.value,
                    'quality_score': validation_result['quality_score'],
                    'validation_metadata': validation_result['metadata']
                }
                
                logger.debug(f"✅ Validated item: {element} (Quality: {validation_result['quality_score']:.2f})")
                yield beam.TaggedOutput('valid', enriched_element)
                
            else:
                self.invalid_counter.inc()
                
                rejection_info = {
                    'rejected_value': element,
                    'rejection_reason': validation_result['rejection_reason'],
                    'rejection_timestamp': time.time(),
                    'stage': ProcessingStage.VALIDATION.value
                }
                
                logger.warning(f"❌ Rejected item: {element} - {validation_result['rejection_reason']}")
                yield beam.TaggedOutput('rejected', rejection_info)
                
        except Exception as e:
            logger.error(f"💥 Validation error for {element}: {str(e)}")
            yield beam.TaggedOutput('errors', {
                'error': f"Validation failed: {str(e)}",
                'element': element,
                'timestamp': time.time(),
                'stage': ProcessingStage.VALIDATION.value
            })
        finally:
            processing_time_ms = int((time.time() - start_time) * 1000)
            self.validation_timer.update(processing_time_ms)
    
    def _comprehensive_validation(self, element: Any) -> Dict[str, Any]:
        """Perform comprehensive validation checks."""
        
        # Basic type validation
        if not isinstance(element, (int, float, str)):
            return {
                'is_valid': False,
                'rejection_reason': f"Invalid type: {type(element)}",
                'quality_score': 0.0,
                'metadata': {'validation_checks': ['type_check']}
            }
        
        # Numeric validation
        if isinstance(element, (int, float)):
            if element < 0:
                return {
                    'is_valid': False,
                    'rejection_reason': "Negative numbers not allowed",
                    'quality_score': 0.0,
                    'metadata': {'validation_checks': ['numeric_range']}
                }
            
            # Calculate quality score based on value characteristics
            quality_score = min(1.0, max(0.0, (element % 100) / 100.0))
            
        elif isinstance(element, str):
            if len(element.strip()) == 0:
                return {
                    'is_valid': False,
                    'rejection_reason': "Empty string not allowed",
                    'quality_score': 0.0,
                    'metadata': {'validation_checks': ['string_length']}
                }
                
            # String quality based on length and content
            quality_score = min(1.0, len(element) / 20.0)
        
        else:
            quality_score = 0.5  # Default for other types
        
        return {
            'is_valid': True,
            'rejection_reason': None,
            'quality_score': quality_score,
            'metadata': {
                'validation_checks': ['type_check', 'range_check', 'content_check'],
                'validated_at': time.time()
            }
        }


class EnterpriseEnrichmentProcessor(beam.DoFn):
    """
    Advanced data enrichment processor.
    
    This is like a sophisticated workstation that adds valuable information
    and context to each item, making it more useful for downstream processing.
    """
    
    def __init__(self, config: EnterpriseConfig):
        self.config = config
        self.enriched_counter = beam.metrics.Metrics.counter(config.metrics_namespace, 'items_enriched')
        self.enrichment_timer = beam.metrics.Metrics.distribution(config.metrics_namespace, 'enrichment_time_ms')
    
    def setup(self):
        logger.info("🔧 EnterpriseEnrichmentProcessor starting - Data enrichment active")
    
    def process(self, validated_element: Dict[str, Any]):
        """Enrich validated data with additional context and calculations."""
        start_time = time.time()
        
        try:
            original_value = validated_element['original_value']
            
            # Perform comprehensive enrichment
            enrichment_data = self._perform_enrichment(original_value, validated_element)
            
            enriched_result = {
                **validated_element,
                'enrichment_id': str(uuid.uuid4()),
                'enrichment_timestamp': time.time(),
                'enrichment_stage': ProcessingStage.ENRICHMENT.value,
                'enrichment_data': enrichment_data,
                'processing_metadata': {
                    'enrichment_version': '2.0',
                    'enrichment_duration_ms': int((time.time() - start_time) * 1000)
                }
            }
            
            self.enriched_counter.inc()
            
            logger.debug(f"🔧 Enriched item: {original_value}")
            yield enriched_result
            
        except Exception as e:
            logger.error(f"💥 Enrichment error: {str(e)}")
            yield beam.TaggedOutput('errors', {
                'error': f"Enrichment failed: {str(e)}",
                'input': validated_element,
                'timestamp': time.time(),
                'stage': ProcessingStage.ENRICHMENT.value
            })
        finally:
            processing_time_ms = int((time.time() - start_time) * 1000)
            self.enrichment_timer.update(processing_time_ms)
    
    def _perform_enrichment(self, original_value: Any, validation_data: Dict) -> Dict[str, Any]:
        """Perform sophisticated data enrichment."""
        
        enrichment = {
            'original_type': type(original_value).__name__,
            'enrichment_timestamp': time.time(),
            'data_lineage': {
                'validation_id': validation_data.get('validation_id'),
                'quality_score': validation_data.get('quality_score', 0.0)
            }
        }
        
        if isinstance(original_value, (int, float)):
            enrichment.update({
                'numeric_properties': {
                    'is_even': original_value % 2 == 0,
                    'is_prime': self._is_prime(int(original_value)) if isinstance(original_value, int) else False,
                    'square': original_value ** 2,
                    'cube': original_value ** 3,
                    'square_root': original_value ** 0.5,
                    'factorial': self._safe_factorial(original_value),
                    'fibonacci_position': self._fibonacci_position(original_value)
                },
                'statistical_properties': {
                    'log_value': self._safe_log(original_value),
                    'normalized_value': original_value / 100.0,
                    'percentile_bucket': int((original_value % 100) / 10)
                }
            })
            
        elif isinstance(original_value, str):
            enrichment.update({
                'string_properties': {
                    'length': len(original_value),
                    'word_count': len(original_value.split()),
                    'character_counts': {
                        'alphanumeric': sum(c.isalnum() for c in original_value),
                        'alphabetic': sum(c.isalpha() for c in original_value),
                        'numeric': sum(c.isdigit() for c in original_value),
                        'uppercase': sum(c.isupper() for c in original_value),
                        'lowercase': sum(c.islower() for c in original_value)
                    },
                    'hash_value': hash(original_value),
                    'reversed': original_value[::-1]
                }
            })
        
        # Add business context (simulated)
        enrichment['business_context'] = {
            'category': self._determine_category(original_value),
            'priority': self._calculate_priority(original_value, validation_data),
            'risk_score': self._calculate_risk_score(original_value),
            'compliance_flags': self._check_compliance(original_value)
        }
        
        return enrichment
    
    def _is_prime(self, n: int) -> bool:
        """Check if a number is prime (optimized for small numbers)."""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        for i in range(3, int(n ** 0.5) + 1, 2):
            if n % i == 0:
                return False
        return True
    
    def _safe_factorial(self, n: Any) -> Optional[int]:
        """Safely calculate factorial for reasonable numbers."""
        try:
            if isinstance(n, (int, float)) and 0 <= n <= 20:
                import math
                return math.factorial(int(n))
        except:
            pass
        return None
    
    def _fibonacci_position(self, n: Any) -> Optional[int]:
        """Find position in Fibonacci sequence (if applicable)."""
        try:
            if isinstance(n, (int, float)) and n >= 0:
                # Generate Fibonacci sequence up to n
                fib_seq = [0, 1]
                while fib_seq[-1] < n:
                    fib_seq.append(fib_seq[-1] + fib_seq[-2])
                
                if n in fib_seq:
                    return fib_seq.index(n)
        except:
            pass
        return None
    
    def _safe_log(self, n: Any) -> Optional[float]:
        """Safely calculate natural logarithm."""
        try:
            if isinstance(n, (int, float)) and n > 0:
                import math
                return math.log(n)
        except:
            pass
        return None
    
    def _determine_category(self, value: Any) -> str:
        """Determine business category for the value."""
        if isinstance(value, (int, float)):
            if value < 10:
                return "low_value"
            elif value < 100:
                return "medium_value"
            else:
                return "high_value"
        elif isinstance(value, str):
            if len(value) < 5:
                return "short_text"
            elif len(value) < 20:
                return "medium_text"
            else:
                return "long_text"
        else:
            return "unknown"
    
    def _calculate_priority(self, value: Any, validation_data: Dict) -> str:
        """Calculate business priority."""
        quality_score = validation_data.get('quality_score', 0.0)
        
        if quality_score > 0.8:
            return "high"
        elif quality_score > 0.5:
            return "medium"
        else:
            return "low"
    
    def _calculate_risk_score(self, value: Any) -> float:
        """Calculate risk score (0.0 = low risk, 1.0 = high risk)."""
        if isinstance(value, (int, float)):
            # Higher values might be riskier
            return min(1.0, abs(value) / 1000.0)
        elif isinstance(value, str):
            # Longer strings might be riskier
            return min(1.0, len(value) / 100.0)
        else:
            return 0.5
    
    def _check_compliance(self, value: Any) -> Dict[str, bool]:
        """Check various compliance requirements."""
        return {
            'gdpr_compliant': True,  # Simplified compliance check
            'pci_compliant': not (isinstance(value, str) and any(c.isdigit() for c in value)),
            'hipaa_compliant': True,
            'sox_compliant': True
        }


class AdvancedBatchProcessor(beam.DoFn):
    """
    Advanced batch processor with enterprise features.
    
    This is like a high-tech assembly station that can handle complex
    batch operations with sophisticated analysis and quality control.
    """
    
    def __init__(self, config: EnterpriseConfig):
        self.config = config
        self.batches_processed = beam.metrics.Metrics.counter(config.metrics_namespace, 'batches_processed')
        self.batch_quality_scores = beam.metrics.Metrics.distribution(config.metrics_namespace, 'batch_quality_scores')
        self.batch_processing_timer = beam.metrics.Metrics.distribution(config.metrics_namespace, 'batch_processing_time_ms')
    
    def setup(self):
        logger.info("📦 AdvancedBatchProcessor starting - Advanced batch processing active")
    
    def process(self, batch: List[Dict[str, Any]]):
        """Process batches with advanced analytics and quality control."""
        start_time = time.time()
        
        try:
            if not batch:
                logger.warning("⚠️ Empty batch received")
                return
            
            logger.info(f"📦 Processing advanced batch of {len(batch)} enriched items")
            
            # Perform advanced batch analysis
            batch_analysis = self._perform_batch_analysis(batch)
            
            # Quality gate check
            if self.config.enable_quality_gates and batch_analysis['overall_quality_score'] < self.config.quality_score_threshold:
                logger.warning(f"🚫 Batch failed quality gate: {batch_analysis['overall_quality_score']:.2f} < {self.config.quality_score_threshold}")
                yield beam.TaggedOutput('quality_failures', {
                    'batch': batch,
                    'analysis': batch_analysis,
                    'failure_reason': 'Quality gate failure',
                    'timestamp': time.time()
                })
                return
            
            # Create comprehensive batch result
            batch_result = {
                'batch_id': str(uuid.uuid4()),
                'batch_timestamp': time.time(),
                'batch_stage': ProcessingStage.TRANSFORMATION.value,
                'batch_size': len(batch),
                'batch_items': batch,
                'batch_analysis': batch_analysis,
                'processing_metadata': {
                    'processing_duration_ms': int((time.time() - start_time) * 1000),
                    'processor_version': '3.0',
                    'quality_assured': True
                }
            }
            
            self.batches_processed.inc()
            self.batch_quality_scores.update(int(batch_analysis['overall_quality_score'] * 100))
            
            logger.info(f"✅ Advanced batch processed successfully (Quality: {batch_analysis['overall_quality_score']:.2f})")
            yield batch_result
            
        except Exception as e:
            logger.error(f"💥 Batch processing error: {str(e)}")
            yield beam.TaggedOutput('errors', {
                'error': f"Batch processing failed: {str(e)}",
                'batch_size': len(batch) if batch else 0,
                'timestamp': time.time(),
                'stage': ProcessingStage.TRANSFORMATION.value
            })
        finally:
            processing_time_ms = int((time.time() - start_time) * 1000)
            self.batch_processing_timer.update(processing_time_ms)
    
    def _perform_batch_analysis(self, batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Perform comprehensive batch analysis."""
        
        # Extract original values and quality scores
        original_values = [item.get('original_value', 0) for item in batch]
        quality_scores = [item.get('quality_score', 0.0) for item in batch]
        
        # Calculate statistical measures
        numeric_values = [v for v in original_values if isinstance(v, (int, float))]
        
        analysis = {
            'item_statistics': {
                'total_items': len(batch),
                'numeric_items': len(numeric_values),
                'string_items': len([v for v in original_values if isinstance(v, str)]),
                'other_items': len(original_values) - len(numeric_values) - len([v for v in original_values if isinstance(v, str)])
            },
            'quality_metrics': {
                'overall_quality_score': sum(quality_scores) / len(quality_scores) if quality_scores else 0.0,
                'min_quality_score': min(quality_scores) if quality_scores else 0.0,
                'max_quality_score': max(quality_scores) if quality_scores else 0.0,
                'quality_variance': self._calculate_variance(quality_scores)
            }
        }
        
        if numeric_values:
            analysis['numeric_statistics'] = {
                'sum': sum(numeric_values),
                'average': sum(numeric_values) / len(numeric_values),
                'min': min(numeric_values),
                'max': max(numeric_values),
                'range': max(numeric_values) - min(numeric_values),
                'variance': self._calculate_variance(numeric_values),
                'std_deviation': self._calculate_variance(numeric_values) ** 0.5,
                'median': self._calculate_median(numeric_values)
            }
        
        # Advanced analysis
        analysis['advanced_metrics'] = {
            'diversity_score': self._calculate_diversity_score(batch),
            'complexity_score': self._calculate_complexity_score(batch),
            'business_value_score': self._calculate_business_value_score(batch),
            'risk_assessment': self._assess_batch_risk(batch)
        }
        
        return analysis
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of a list of values."""
        if len(values) < 2:
            return 0.0
        
        mean = sum(values) / len(values)
        return sum((x - mean) ** 2 for x in values) / len(values)
    
    def _calculate_median(self, values: List[float]) -> float:
        """Calculate median of a list of values."""
        sorted_values = sorted(values)
        n = len(sorted_values)
        
        if n % 2 == 0:
            return (sorted_values[n//2 - 1] + sorted_values[n//2]) / 2
        else:
            return sorted_values[n//2]
    
    def _calculate_diversity_score(self, batch: List[Dict[str, Any]]) -> float:
        """Calculate how diverse the batch items are."""
        categories = [item.get('enrichment_data', {}).get('business_context', {}).get('category', 'unknown') for item in batch]
        unique_categories = len(set(categories))
        total_categories = len(categories)
        
        return unique_categories / total_categories if total_categories > 0 else 0.0
    
    def _calculate_complexity_score(self, batch: List[Dict[str, Any]]) -> float:
        """Calculate complexity score based on enrichment data."""
        complexity_scores = []
        
        for item in batch:
            enrichment_data = item.get('enrichment_data', {})
            
            # Count number of enrichment properties
            complexity = 0
            if 'numeric_properties' in enrichment_data:
                complexity += len(enrichment_data['numeric_properties'])
            if 'string_properties' in enrichment_data:
                complexity += len(enrichment_data['string_properties'])
            if 'business_context' in enrichment_data:
                complexity += len(enrichment_data['business_context'])
            
            complexity_scores.append(complexity)
        
        return sum(complexity_scores) / len(complexity_scores) / 20.0 if complexity_scores else 0.0  # Normalized
    
    def _calculate_business_value_score(self, batch: List[Dict[str, Any]]) -> float:
        """Calculate business value score for the batch."""
        priorities = [item.get('enrichment_data', {}).get('business_context', {}).get('priority', 'low') for item in batch]
        
        priority_scores = {'high': 1.0, 'medium': 0.6, 'low': 0.3}
        total_score = sum(priority_scores.get(p, 0.3) for p in priorities)
        
        return total_score / len(priorities) if priorities else 0.0
    
    def _assess_batch_risk(self, batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Assess risk for the entire batch."""
        risk_scores = [item.get('enrichment_data', {}).get('business_context', {}).get('risk_score', 0.5) for item in batch]
        
        return {
            'average_risk': sum(risk_scores) / len(risk_scores) if risk_scores else 0.5,
            'max_risk': max(risk_scores) if risk_scores else 0.5,
            'high_risk_items': len([r for r in risk_scores if r > 0.7]),
            'risk_classification': 'high' if max(risk_scores) > 0.8 else 'medium' if max(risk_scores) > 0.5 else 'low'
        }


class EnterpriseAggregationProcessor(beam.DoFn):
    """
    Final enterprise aggregation and reporting processor.
    
    This is like the executive summary station that creates comprehensive
    reports and insights from all the processed data.
    """
    
    def __init__(self, config: EnterpriseConfig):
        self.config = config
        self.aggregations_created = beam.metrics.Metrics.counter(config.metrics_namespace, 'aggregations_created')
        self.aggregation_timer = beam.metrics.Metrics.distribution(config.metrics_namespace, 'aggregation_time_ms')
    
    def setup(self):
        logger.info("📊 EnterpriseAggregationProcessor starting - Final aggregation active")
    
    def process(self, batch_result: Dict[str, Any]):
        """Create comprehensive enterprise aggregation and reporting."""
        start_time = time.time()
        
        try:
            logger.info(f"📊 Creating enterprise aggregation for batch {batch_result.get('batch_id')}")
            
            # Extract batch analysis
            batch_analysis = batch_result.get('batch_analysis', {})
            batch_items = batch_result.get('batch_items', [])
            
            # Create executive summary
            executive_summary = self._create_executive_summary(batch_result, batch_analysis)
            
            # Create detailed analytics
            detailed_analytics = self._create_detailed_analytics(batch_items, batch_analysis)
            
            # Create compliance report
            compliance_report = self._create_compliance_report(batch_items)
            
            # Create performance metrics
            performance_metrics = self._create_performance_metrics(batch_result)
            
            # Assemble final aggregation
            enterprise_aggregation = {
                'aggregation_id': str(uuid.uuid4()),
                'aggregation_timestamp': time.time(),
                'aggregation_stage': ProcessingStage.AGGREGATION.value,
                'source_batch_id': batch_result.get('batch_id'),
                'executive_summary': executive_summary,
                'detailed_analytics': detailed_analytics,
                'compliance_report': compliance_report,
                'performance_metrics': performance_metrics,
                'enterprise_metadata': {
                    'aggregation_version': '4.0',
                    'created_by': 'EnterpriseAggregationProcessor',
                    'processing_duration_ms': int((time.time() - start_time) * 1000),
                    'data_classification': self._classify_data_sensitivity(batch_items),
                    'retention_policy': self._determine_retention_policy(batch_analysis)
                }
            }
            
            self.aggregations_created.inc()
            
            logger.info(f"✅ Enterprise aggregation created successfully")
            yield enterprise_aggregation
            
        except Exception as e:
            logger.error(f"💥 Aggregation error: {str(e)}")
            yield beam.TaggedOutput('errors', {
                'error': f"Aggregation failed: {str(e)}",
                'input': batch_result,
                'timestamp': time.time(),
                'stage': ProcessingStage.AGGREGATION.value
            })
        finally:
            processing_time_ms = int((time.time() - start_time) * 1000)
            self.aggregation_timer.update(processing_time_ms)
    
    def _create_executive_summary(self, batch_result: Dict, batch_analysis: Dict) -> Dict[str, Any]:
        """Create executive summary for leadership."""
        quality_metrics = batch_analysis.get('quality_metrics', {})
        advanced_metrics = batch_analysis.get('advanced_metrics', {})
        
        return {
            'key_insights': {
                'total_items_processed': batch_result.get('batch_size', 0),
                'overall_quality_score': quality_metrics.get('overall_quality_score', 0.0),
                'business_value_score': advanced_metrics.get('business_value_score', 0.0),
                'risk_level': advanced_metrics.get('risk_assessment', {}).get('risk_classification', 'unknown')
            },
            'recommendations': self._generate_recommendations(batch_analysis),
            'success_metrics': {
                'quality_gate_passed': quality_metrics.get('overall_quality_score', 0.0) >= self.config.quality_score_threshold,
                'processing_efficiency': 'high' if batch_result.get('processing_metadata', {}).get('processing_duration_ms', 0) < 1000 else 'medium',
                'data_completeness': 'high' if batch_analysis.get('item_statistics', {}).get('total_items', 0) > 0 else 'low'
            }
        }
    
    def _create_detailed_analytics(self, batch_items: List[Dict], batch_analysis: Dict) -> Dict[str, Any]:
        """Create detailed analytics report."""
        return {
            'statistical_analysis': batch_analysis.get('numeric_statistics', {}),
            'quality_analysis': batch_analysis.get('quality_metrics', {}),
            'business_analysis': {
                'category_distribution': self._analyze_category_distribution(batch_items),
                'priority_distribution': self._analyze_priority_distribution(batch_items),
                'risk_distribution': self._analyze_risk_distribution(batch_items)
            },
            'technical_analysis': {
                'data_types': batch_analysis.get('item_statistics', {}),
                'complexity_metrics': {
                    'diversity_score': batch_analysis.get('advanced_metrics', {}).get('diversity_score', 0.0),
                    'complexity_score': batch_analysis.get('advanced_metrics', {}).get('complexity_score', 0.0)
                }
            }
        }
    
    def _create_compliance_report(self, batch_items: List[Dict]) -> Dict[str, Any]:
        """Create compliance report."""
        compliance_scores = []
        
        for item in batch_items:
            compliance_flags = item.get('enrichment_data', {}).get('business_context', {}).get('compliance_flags', {})
            compliance_scores.append(compliance_flags)
        
        # Aggregate compliance results
        compliance_summary = {}
        for compliance_type in ['gdpr_compliant', 'pci_compliant', 'hipaa_compliant', 'sox_compliant']:
            compliant_count = sum(1 for item in compliance_scores if item.get(compliance_type, False))
            compliance_summary[compliance_type] = {
                'compliant_items': compliant_count,
                'total_items': len(compliance_scores),
                'compliance_rate': compliant_count / len(compliance_scores) if compliance_scores else 0.0
            }
        
        return {
            'compliance_summary': compliance_summary,
            'overall_compliance_score': sum(cs['compliance_rate'] for cs in compliance_summary.values()) / len(compliance_summary) if compliance_summary else 0.0,
            'compliance_issues': [f"{k}: {v['compliance_rate']:.1%}" for k, v in compliance_summary.items() if v['compliance_rate'] < 1.0]
        }
    
    def _create_performance_metrics(self, batch_result: Dict) -> Dict[str, Any]:
        """Create performance metrics."""
        processing_metadata = batch_result.get('processing_metadata', {})
        
        return {
            'timing_metrics': {
                'batch_processing_time_ms': processing_metadata.get('processing_duration_ms', 0),
                'average_item_processing_time_ms': processing_metadata.get('processing_duration_ms', 0) / batch_result.get('batch_size', 1)
            },
            'throughput_metrics': {
                'items_per_second': batch_result.get('batch_size', 0) / (processing_metadata.get('processing_duration_ms', 1) / 1000),
                'batches_per_minute': 60000 / processing_metadata.get('processing_duration_ms', 1)
            },
            'resource_metrics': {
                'estimated_cpu_usage': 'moderate',  # Would be actual metrics in production
                'estimated_memory_usage': 'low',
                'estimated_io_usage': 'minimal'
            }
        }
    
    def _generate_recommendations(self, batch_analysis: Dict) -> List[str]:
        """Generate actionable recommendations based on analysis."""
        recommendations = []
        
        quality_score = batch_analysis.get('quality_metrics', {}).get('overall_quality_score', 0.0)
        if quality_score < 0.7:
            recommendations.append("Consider implementing additional data validation rules to improve quality scores")
        
        diversity_score = batch_analysis.get('advanced_metrics', {}).get('diversity_score', 0.0)
        if diversity_score < 0.3:
            recommendations.append("Data appears homogeneous - consider expanding data sources for better insights")
        
        risk_level = batch_analysis.get('advanced_metrics', {}).get('risk_assessment', {}).get('risk_classification', 'medium')
        if risk_level == 'high':
            recommendations.append("High risk items detected - implement additional security and monitoring measures")
        
        return recommendations if recommendations else ["Data processing completed successfully with no immediate action required"]
    
    def _analyze_category_distribution(self, batch_items: List[Dict]) -> Dict[str, int]:
        """Analyze distribution of business categories."""
        categories = [item.get('enrichment_data', {}).get('business_context', {}).get('category', 'unknown') for item in batch_items]
        category_counts = {}
        for category in categories:
            category_counts[category] = category_counts.get(category, 0) + 1
        return category_counts
    
    def _analyze_priority_distribution(self, batch_items: List[Dict]) -> Dict[str, int]:
        """Analyze distribution of business priorities."""
        priorities = [item.get('enrichment_data', {}).get('business_context', {}).get('priority', 'unknown') for item in batch_items]
        priority_counts = {}
        for priority in priorities:
            priority_counts[priority] = priority_counts.get(priority, 0) + 1
        return priority_counts
    
    def _analyze_risk_distribution(self, batch_items: List[Dict]) -> Dict[str, Any]:
        """Analyze risk score distribution."""
        risk_scores = [item.get('enrichment_data', {}).get('business_context', {}).get('risk_score', 0.5) for item in batch_items]
        
        return {
            'low_risk_items': len([r for r in risk_scores if r < 0.3]),
            'medium_risk_items': len([r for r in risk_scores if 0.3 <= r < 0.7]),
            'high_risk_items': len([r for r in risk_scores if r >= 0.7]),
            'average_risk_score': sum(risk_scores) / len(risk_scores) if risk_scores else 0.0
        }
    
    def _classify_data_sensitivity(self, batch_items: List[Dict]) -> str:
        """Classify data sensitivity level."""
        # Simplified classification based on content
        has_personal_data = any('string' in str(item.get('original_value', '')).lower() for item in batch_items)
        risk_scores = [item.get('enrichment_data', {}).get('business_context', {}).get('risk_score', 0.5) for item in batch_items]
        avg_risk = sum(risk_scores) / len(risk_scores) if risk_scores else 0.5
        
        if has_personal_data or avg_risk > 0.7:
            return "confidential"
        elif avg_risk > 0.4:
            return "internal"
        else:
            return "public"
    
    def _determine_retention_policy(self, batch_analysis: Dict) -> str:
        """Determine data retention policy."""
        quality_score = batch_analysis.get('quality_metrics', {}).get('overall_quality_score', 0.0)
        business_value = batch_analysis.get('advanced_metrics', {}).get('business_value_score', 0.0)
        
        if quality_score > 0.8 and business_value > 0.7:
            return "long_term"  # 7 years
        elif quality_score > 0.6 and business_value > 0.5:
            return "medium_term"  # 3 years
        else:
            return "short_term"  # 1 year


def create_enterprise_complex_pipeline(config: EnterpriseConfig, input_data: List[Any]) -> beam.Pipeline:
    """
    Create a comprehensive enterprise-grade Apache Beam pipeline.
    
    This creates a sophisticated data processing factory with multiple
    quality control stations, advanced analytics, and comprehensive reporting.
    """
    
    # Configure advanced pipeline options
    pipeline_options = PipelineOptions([
        '--runner=DirectRunner',
        f'--max_num_workers={config.max_workers}',
        f'--experiments=use_runner_v2',
        '--enable_streaming_engine',
        '--worker_machine_type=n1-standard-4',
    ])
    
    pipeline_options.view_as(SetupOptions).save_main_session = True
    
    # Create the pipeline
    pipeline = beam.Pipeline(options=pipeline_options)
    
    logger.info(f"🏗️ Creating enterprise complex pipeline with {len(input_data)} input items")
    
    # Create output directory
    os.makedirs(config.output_directory, exist_ok=True)
    
    # Stage 1: Data Validation and Enrichment
    validated_data = (
        pipeline
        | 'Create Input Data' >> beam.Create(input_data)
        | 'Add Processing Timestamps' >> beam.Map(lambda x: beam.window.TimestampedValue(x, time.time()))
        | 'Validate Data' >> beam.ParDo(DataValidationProcessor(config)).with_outputs('rejected', 'errors', main='valid')
    )
    
    # Stage 2: Data Enrichment  
    enriched_data = (
        validated_data.valid
        | 'Enrich Data' >> beam.ParDo(EnterpriseEnrichmentProcessor(config)).with_outputs('errors', main='main')
    )
    
    # Stage 3: Advanced Batch Processing
    batch_results = (
        enriched_data.main
        | 'Create Advanced Batches' >> beam.BatchElements(
            min_batch_size=config.min_batch_size,
            max_batch_size=config.max_batch_size,
            clock=beam.transforms.window.TimeDomain.WATERMARK
        )
        | 'Process Advanced Batches' >> beam.ParDo(AdvancedBatchProcessor(config)).with_outputs('quality_failures', 'errors', main='main')
    )
    
    # Stage 4: Enterprise Aggregation and Reporting
    final_aggregations = (
        batch_results.main
        | 'Create Enterprise Aggregations' >> beam.ParDo(EnterpriseAggregationProcessor(config)).with_outputs('errors', main='main')
    )
    
    # Output Management - Main Results
    main_output = (
        final_aggregations.main
        | 'Format Main Results' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Main Results' >> beam.io.WriteToText(
            f'{config.output_directory}/enterprise_aggregations',
            file_name_suffix='.json'
        )
    )
    
    # Output Management - Validation Rejections
    rejection_output = (
        validated_data.rejected
        | 'Format Rejections' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Rejections' >> beam.io.WriteToText(
            f'{config.output_directory}/data_rejections',
            file_name_suffix='.json'
        )
    )
    
    # Output Management - Quality Failures
    quality_failure_output = (
        batch_results.quality_failures
        | 'Format Quality Failures' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Quality Failures' >> beam.io.WriteToText(
            f'{config.output_directory}/quality_failures',
            file_name_suffix='.json'
        )
    )
    
    # Output Management - All Errors
    all_errors = (
        (validated_data.errors, enriched_data.errors, batch_results.errors, final_aggregations.errors)
        | 'Flatten All Errors' >> beam.Flatten()
        | 'Format All Errors' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write All Errors' >> beam.io.WriteToText(
            f'{config.output_directory}/processing_errors',
            file_name_suffix='.json'
        )
    )
    
    return pipeline


def run_enterprise_complex_pipeline():
    """
    Run the comprehensive enterprise Apache Beam pipeline.
    
    This function orchestrates the entire enterprise data processing
    operation with full monitoring, error handling, and reporting.
    """
    
    # Parse enterprise command line arguments
    parser = argparse.ArgumentParser(description='Enterprise Apache Beam Complex Pipeline')
    parser.add_argument('--batch_size', type=int, default=15, help='Size of batches to process')
    parser.add_argument('--max_workers', type=int, default=6, help='Maximum number of workers')
    parser.add_argument('--input_size', type=int, default=100, help='Number of input items to generate')
    parser.add_argument('--enable_quality_gates', action='store_true', help='Enable quality gates')
    parser.add_argument('--quality_threshold', type=float, default=0.8, help='Quality score threshold')
    parser.add_argument('--output_dir', type=str, default='/tmp/enterprise_beam_complex', help='Output directory')
    
    args = parser.parse_args()
    
    # Create enterprise configuration
    config = EnterpriseConfig(
        batch_size=args.batch_size,
        max_workers=args.max_workers,
        enable_quality_gates=args.enable_quality_gates,
        quality_score_threshold=args.quality_threshold,
        output_directory=args.output_dir
    )
    
    logger.info("🚀 Starting Enterprise Apache Beam Complex Pipeline")
    logger.info(f"📋 Configuration:")
    logger.info(f"   • Batch Size: {config.batch_size}")
    logger.info(f"   • Max Workers: {config.max_workers}")
    logger.info(f"   • Quality Gates: {'Enabled' if config.enable_quality_gates else 'Disabled'}")
    logger.info(f"   • Quality Threshold: {config.quality_score_threshold}")
    logger.info(f"   • Output Directory: {config.output_directory}")
    
    # Generate diverse sample input data for enterprise testing
    input_data = []
    
    # Add numeric data
    input_data.extend(range(1, args.input_size // 2 + 1))
    
    # Add string data
    string_samples = [
        "enterprise", "data", "processing", "apache", "beam",
        "quality", "control", "analytics", "reporting", "compliance",
        "monitoring", "performance", "scalability", "reliability"
    ]
    input_data.extend(string_samples[:args.input_size // 4])
    
    # Add some edge cases for testing
    input_data.extend([-1, 0, "", "x", 999999])  # These should trigger validation
    
    # Ensure we have the right amount of data
    while len(input_data) < args.input_size:
        input_data.append(len(input_data))
    
    input_data = input_data[:args.input_size]
    
    logger.info(f"📥 Generated {len(input_data)} diverse input items for enterprise testing")
    logger.info(f"📊 Data composition: {len([x for x in input_data if isinstance(x, int)])} numbers, "
                f"{len([x for x in input_data if isinstance(x, str)])} strings")
    
    # Create and run the complex pipeline
    start_time = time.time()
    
    try:
        pipeline = create_enterprise_complex_pipeline(config, input_data)
        
        logger.info("▶️ Starting complex pipeline execution...")
        result = pipeline.run()
        result.wait_until_finish()
        
        end_time = time.time()
        total_time = end_time - start_time
        
        logger.info("✅ Complex pipeline completed successfully!")
        logger.info(f"📊 Enterprise Performance Summary:")
        logger.info(f"   • Total Processing Time: {total_time:.2f} seconds")
        logger.info(f"   • Items Processed: {len(input_data)}")
        logger.info(f"   • Enterprise Throughput: {len(input_data) / total_time:.2f} items/second")
        logger.info(f"   • Quality Assurance: Enabled")
        logger.info(f"   • Compliance Checking: Enabled")
        
        # Display output file information
        logger.info("📄 Enterprise outputs written to:")
        logger.info(f"   • Main aggregations: {config.output_directory}/enterprise_aggregations-*.json")
        logger.info(f"   • Data rejections: {config.output_directory}/data_rejections-*.json")
        logger.info(f"   • Quality failures: {config.output_directory}/quality_failures-*.json") 
        logger.info(f"   • Processing errors: {config.output_directory}/processing_errors-*.json")
        
        # Try to display sample results
        try:
            import glob
            
            # Show sample aggregation
            agg_files = glob.glob(f'{config.output_directory}/enterprise_aggregations-*.json')
            if agg_files:
                with open(agg_files[0], 'r') as f:
                    sample_agg = f.readline().strip()
                    if sample_agg:
                        logger.info("📋 Sample Enterprise Aggregation:")
                        sample_data = json.loads(sample_agg)
                        logger.info(f"   • Aggregation ID: {sample_data.get('aggregation_id', 'N/A')}")
                        logger.info(f"   • Items Processed: {sample_data.get('executive_summary', {}).get('key_insights', {}).get('total_items_processed', 'N/A')}")
                        logger.info(f"   • Quality Score: {sample_data.get('executive_summary', {}).get('key_insights', {}).get('overall_quality_score', 'N/A'):.2f}")
                        logger.info(f"   • Business Value: {sample_data.get('executive_summary', {}).get('key_insights', {}).get('business_value_score', 'N/A'):.2f}")
            
            # Show rejection count
            rejection_files = glob.glob(f'{config.output_directory}/data_rejections-*.json')
            rejection_count = 0
            for file in rejection_files:
                with open(file, 'r') as f:
                    rejection_count += len(f.readlines())
            
            if rejection_count > 0:
                logger.info(f"⚠️ Data Quality Alert: {rejection_count} items were rejected during validation")
            else:
                logger.info("✅ Data Quality: All items passed validation")
                
        except Exception as e:
            logger.warning(f"Could not display sample results: {e}")
            
    except Exception as e:
        logger.error(f"❌ Complex pipeline failed: {str(e)}")
        raise


if __name__ == '__main__':
    run_enterprise_complex_pipeline()
