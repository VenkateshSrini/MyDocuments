import os
import re
from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
#import yaml
template_dir = 'sample_helm'
templates_subdir = os.path.join(template_dir, 'templates')

# Step 1: Install Required Dependencies (informational, not needed in script)
# Use pip install langchain langchain_community openai in your environment before running this script

def list_template_files():
    files = [f for f in os.listdir(templates_subdir) if f.endswith(('.yaml', '.tpl'))]
    print(f'📁 Found {len(files)} template files:')
    for file in files:
        print(f'   - {file}')
    print("\n" + "="*50)
    return files

def extract_variables(files):
    variables = set()
    pattern = re.compile(r'\{\{\s*\.Values\.([a-zA-Z0-9_]+)')
    print("🔍 Scanning template files for variables...")
    for fname in files:
        file_path = os.path.join(templates_subdir, fname)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                found = pattern.findall(content)
                if found:
                    print(f'   📄 {fname}: {found}')
                variables.update(found)
        except Exception as e:
            print(f'   ❌ Error reading {fname}: {e}')
    print(f'\n✅ Total unique variables found: {len(variables)}')
    print(f'📋 Variables needed: {sorted(list(variables))}')
    return variables

def setup_openai_api():
    if "OPENAI_API_KEY" not in os.environ or not os.environ["OPENAI_API_KEY"]:
        api_key = input("Please enter your OpenAI API key: ").strip()
        os.environ['OPENAI_API_KEY'] = api_key
        print("✅ API key is set successfully!")
    else:
        print("✅ API key is already set. No need to reconfigure.")
    print("✅ API key is configured!")

def init_langchain_llm(model_name='gpt-3.5-turbo', temperature=0.7):
    llm = ChatOpenAI(model=model_name, temperature=temperature)
    return llm

def create_prompt_template():
    prompt = PromptTemplate(
        input_variables=['variables'],
        template="""Given the following Helm chart variables: {variables}
Generate the minimum set of user-friendly questions needed to configure all these values.
Group related variables together where possible to minimize the number of questions.
Make the questions clear and understandable for users who may not be Kubernetes experts.
Format your response as a numbered list of questions.
For each question, briefly explain what the variable controls in parentheses.
Example format:
1. What is the name of your application? (Sets the app name used in labels and resources)
2. How many replicas do you want to run? (Controls horizontal scaling)
"""
    )
    return prompt

def generate_questions_for_variables(llm, prompt, variables_list):
    if not variables_list:
        print("❌ No variables found to generate questions for.")
        return None
    formatted_prompt = prompt.format(variables=', '.join(sorted(variables_list)))
    response = llm.invoke(formatted_prompt)
    print("🎯 Generated Questions:")
    print(response.content)
    with open(os.path.join(template_dir, 'generated_questions.txt'), 'w', encoding='utf-8') as file:
        file.write(response.content)
    print("\n💾 Questions saved to 'generated_questions.txt'")
    return response.content

def collect_answers(questions_path):
    if not os.path.exists(questions_path):
        print(f"❌ {questions_path} not found. Please run the previous steps to generate questions.")
        return None
    with open(questions_path, 'r', encoding='utf-8') as f:
        questions = [q.strip() for q in f.readlines() if q.strip()]
    print(f"✅ Loaded {len(questions)} questions from generated_questions.txt\n")
    answers = []
    print("Please answer the following questions to generate your values.yaml:")
    for idx, question in enumerate(questions, 1):
        answer = input(f"\nQ{idx}: {question}\nYour answer: ")
        answers.append((question, answer))
    return answers

def generate_values_yaml_gpt4(answers):
    
    llm_gpt4 = ChatOpenAI(model='gpt-4.1', temperature=0.3)
    # Load base values.yaml
    values_path = os.path.join(template_dir, 'values.yaml')
    base_yaml_content = ''
    if os.path.exists(values_path):
        with open(values_path, 'r', encoding='utf-8') as f:
            base_yaml_content = f.read()
    else:
        print(f"Warning: {values_path} not found. Proceeding with user answers only.")
    qa_pairs = "\n".join([f"Q: {q}\nA: {a}" for q, a in answers])
    prompt_yaml = f"""
                    Given the following Helm chart configuration questions and user answers, and the existing values.yaml content below, replace the user answers into the values.yaml in appropriate places. Do not copy any old values from the existing values.yaml file.
                    Output only the final merged YAML, suitable for use as values.yaml. Do not include any explanation or extra text.

                    Existing values.yaml:
                    {base_yaml_content}

                    Questions and Answers:
                    {qa_pairs}
                    Example 1:
                    assuming the user image as mypp and tag as v1.0 and number of instances as 2, the output should look like:
                    replicaCount: 2
                    image:
                        repository: myapp
                        tag: v1.0
                        pullPolicy: IfNotPresent
                    """
    print("\n🚀 Sending values.yaml and user answers to GPT-4.1 to generate merged YAML...")
    response = llm_gpt4.invoke(prompt_yaml)
    merged_yaml = response.content.strip()
    generated_path = os.path.join(template_dir, 'generated_values.yaml')
    with open(generated_path, 'w', encoding='utf-8') as f:
        f.write(merged_yaml)
    print(f"\n💾 Final merged values saved to {generated_path}\n")
    print("--- generated_values.yaml preview ---\n")
    print(merged_yaml)
    return merged_yaml

def main():
    # Example usage
    gen_q_path = os.path.join(template_dir, 'generated_questions.txt')
    if not os.path.exists(gen_q_path):
        print(f"❌ Question file '{gen_q_path}' does not exist. Hence generating the questions.")
        files = list_template_files()
        variables = extract_variables(files)
        setup_openai_api()
        llm = init_langchain_llm(model_name='gpt-3.5-turbo')
        prompt = create_prompt_template()
        generate_questions_for_variables(llm, prompt, variables)
    answers = collect_answers(gen_q_path)
    if answers:
        generate_values_yaml_gpt4(answers)

if __name__ == "__main__":
    main()
