﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using StackExchange.Redis;
using Steeltoe.Connector.Redis;
using Steeltoe.Connector.Services;

namespace CommonLibraries.Services.Cache
{
    public class StackExchangeRedisFactory : RedisServiceConnectorFactory
    {
        private readonly RedisCacheConfigurer _redisCacheConfigurer = new RedisCacheConfigurer();
        private readonly RedisServiceInfo _info;
        private readonly RedisCacheConnectorOptions _config;

        public StackExchangeRedisFactory(RedisServiceInfo sinfo,
            RedisCacheConnectorOptions config, 
            Type connectionType, Type optionsType, MethodInfo initalizer) : base(sinfo, config, connectionType, optionsType, initalizer)
        {
            _info = sinfo;
            _config = config;
        }

        public override object Create(IServiceProvider provider)
        {
            var connectionOptions = _redisCacheConfigurer.Configure(_info, _config);
            var redisOptions = ConfigurationOptions.Parse(connectionOptions.ToString());    

            if(_config.Ssl)
                redisOptions.CertificateValidation += RedisOptions_CertificateValidation;
            IConnectionMultiplexer connectionMultiplexer = ConnectionMultiplexer.Connect(redisOptions);
            return connectionMultiplexer;
        }

        private bool RedisOptions_CertificateValidation(object sender, System.Security.Cryptography.X509Certificates.X509Certificate? certificate,
            System.Security.Cryptography.X509Certificates.X509Chain? chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}
