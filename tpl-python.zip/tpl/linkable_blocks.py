"""
Linkable Dataflow Blocks with Producer-Consumer Pattern
Supports linking BatchBlock -> TransformBlock -> BatchBlock with configurable instances
"""

import concurrent.futures
import time
import threading
import queue
from typing import List, Any, Callable, Optional, Union
from abc import ABC, abstractmethod


class DataflowBlock(ABC):
    """Base class for all dataflow blocks that can be linked together."""
    
    def __init__(self, max_workers: int = None, max_queue_size: int = 100):
        self.max_workers = max_workers or 4
        self.max_queue_size = max_queue_size
        self.input_queue = queue.Queue(maxsize=max_queue_size)
        self.output_queue = queue.Queue(maxsize=max_queue_size)
        self.next_blocks = []
        self.is_processing = False
        self.completion_event = threading.Event()
        self.executor = None
        self.futures = []
        
    def link_to(self, next_block: 'DataflowBlock', num_instances: int = 1):
        """
        Link this block to the next block with configurable number of consumer instances.
        
        Args:
            next_block: The next block in the pipeline
            num_instances: Number of consumer instances for the next block
        """
        for _ in range(num_instances):
            self.next_blocks.append(next_block)
        return next_block
    
    def post(self, item: Any):
        """Post an item to this block for processing."""
        if not self.is_processing:
            raise RuntimeError("Block is not processing. Call start() first.")
        self.input_queue.put(item)
    
    def start(self):
        """Start processing items."""
        if self.is_processing:
            return
            
        self.is_processing = True
        self.completion_event.clear()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers)
        
        # Start worker threads
        for i in range(self.max_workers):
            future = self.executor.submit(self._worker_loop, i)
            self.futures.append(future)
    
    def complete(self):
        """Signal that no more items will be posted and wait for completion."""
        if not self.is_processing:
            return
            
        # Signal completion
        self.completion_event.set()
        
        # Wait for all workers to finish
        if self.executor:
            self.executor.shutdown(wait=True)
        
        self.is_processing = False
        
        # Signal completion to next blocks
        for next_block in set(self.next_blocks):  # Use set to avoid duplicates
            next_block.complete()
    
    def _worker_loop(self, worker_id: int):
        """Main worker loop for processing items."""
        while True:
            try:
                # Check if we should stop
                if self.completion_event.is_set() and self.input_queue.empty():
                    break
                
                # Get item with timeout
                try:
                    item = self.input_queue.get(timeout=0.1)
                except queue.Empty:
                    continue
                
                # Process the item
                try:
                    result = self._process_item(item)
                    
                    # Send result to next blocks
                    if self.next_blocks and result is not None:
                        # Distribute work among next block instances
                        next_block = self.next_blocks[hash(str(item)) % len(self.next_blocks)]
                        next_block.post(result)
                    elif result is not None:
                        # No next block, put in output queue
                        self.output_queue.put(result)
                        
                except Exception as e:
                    print(f"Error processing item {item} in worker {worker_id}: {e}")
                
                self.input_queue.task_done()
                
            except Exception as e:
                print(f"Worker {worker_id} error: {e}")
                break
    
    @abstractmethod
    def _process_item(self, item: Any) -> Any:
        """Process a single item. Must be implemented by subclasses."""
        pass
    
    def get_results(self) -> List[Any]:
        """Get all results from the output queue."""
        results = []
        while True:
            try:
                result = self.output_queue.get_nowait()
                results.append(result)
            except queue.Empty:
                break
        return results


class LinkableBatchBlock(DataflowBlock):
    """
    A batch block that can be linked with other blocks.
    Groups input items into batches and processes them.
    """
    
    def __init__(self, batch_size: int, batch_processor: Callable[[List[Any]], Any], 
                 max_workers: int = None, max_queue_size: int = 100):
        super().__init__(max_workers, max_queue_size)
        self.batch_size = batch_size
        self.batch_processor = batch_processor
        self.current_batch = []
        self.batch_lock = threading.Lock()
    
    def _process_item(self, item: Any) -> Optional[Any]:
        """Add item to current batch and process when batch is full."""
        with self.batch_lock:
            self.current_batch.append(item)
            
            if len(self.current_batch) >= self.batch_size:
                # Process the batch
                batch_to_process = self.current_batch.copy()
                self.current_batch = []
                
                try:
                    result = self.batch_processor(batch_to_process)
                    return result
                except Exception as e:
                    print(f"Error processing batch {batch_to_process}: {e}")
                    return None
        
        return None  # Batch not ready yet
    
    def complete(self):
        """Complete processing and handle any remaining items in current batch."""
        # Process any remaining items in the batch
        with self.batch_lock:
            if self.current_batch:
                try:
                    result = self.batch_processor(self.current_batch)
                    if self.next_blocks:
                        next_block = self.next_blocks[0]  # Send to first available instance
                        next_block.post(result)
                    else:
                        self.output_queue.put(result)
                except Exception as e:
                    print(f"Error processing final batch {self.current_batch}: {e}")
                
                self.current_batch = []
        
        super().complete()


class LinkableTransformBlock(DataflowBlock):
    """
    A transform block that can be linked with other blocks.
    Applies a transformation function to each input item.
    """
    
    def __init__(self, transform_func: Callable[[Any], Any], 
                 max_workers: int = None, max_queue_size: int = 100):
        super().__init__(max_workers, max_queue_size)
        self.transform_func = transform_func
    
    def _process_item(self, item: Any) -> Any:
        """Apply transformation to the item."""
        try:
            return self.transform_func(item)
        except Exception as e:
            print(f"Error transforming item {item}: {e}")
            return None


class DataflowPipeline:
    """
    A pipeline that manages linked dataflow blocks.
    """
    
    def __init__(self):
        self.blocks = []
        self.input_block = None
    
    def add_block(self, block: DataflowBlock) -> DataflowBlock:
        """Add a block to the pipeline."""
        self.blocks.append(block)
        if self.input_block is None:
            self.input_block = block
        return block
    
    def start_all(self):
        """Start all blocks in the pipeline."""
        for block in self.blocks:
            block.start()
    
    def post_data(self, items: List[Any]):
        """Post data to the input block."""
        if not self.input_block:
            raise RuntimeError("No input block configured")
        
        for item in items:
            self.input_block.post(item)
    
    def complete_all(self):
        """Complete all blocks in the pipeline."""
        if self.input_block:
            self.input_block.complete()
    
    def get_final_results(self) -> List[Any]:
        """Get results from the last block that has no next blocks."""
        results = []
        for block in self.blocks:
            if not block.next_blocks:  # This is a final block
                results.extend(block.get_results())
        return results


# Example batch processors and transform functions

def sum_batch_processor(batch: List[int]) -> dict:
    """Process a batch by calculating statistics."""
    time.sleep(0.1)  # Simulate processing time
    return {
        'batch_size': len(batch),
        'sum': sum(batch),
        'avg': sum(batch) / len(batch) if batch else 0,
        'min': min(batch) if batch else None,
        'max': max(batch) if batch else None
    }

def string_batch_processor(batch: List[str]) -> dict:
    """Process a batch of strings."""
    time.sleep(0.15)
    return {
        'batch_size': len(batch),
        'total_length': sum(len(s) for s in batch),
        'concatenated': ' | '.join(batch),
        'longest': max(batch, key=len) if batch else ''
    }

def square_transform(stats: dict) -> dict:
    """Transform statistics by squaring the sum."""
    time.sleep(0.05)
    return {
        **stats,
        'sum_squared': stats['sum'] ** 2 if stats.get('sum') else 0,
        'transformed_at': time.time()
    }

def format_transform(item: Any) -> str:
    """Transform any item to a formatted string."""
    time.sleep(0.02)
    return f"formatted_{str(item)}"

def final_batch_processor(batch: List[Any]) -> dict:
    """Final processing of transformed items."""
    time.sleep(0.2)
    return {
        'final_batch_size': len(batch),
        'items': batch,
        'processed_at': time.time(),
        'summary': f"Processed {len(batch)} transformed items"
    }


if __name__ == "__main__":
    print("=== Linkable Dataflow Blocks Example ===\n")
    
    # Example 1: InputBatch -> Transform -> ResultBatch
    print("1. Basic Pipeline: InputBatch -> Transform -> ResultBatch")
    
    # Create blocks
    input_batch_block = LinkableBatchBlock(
        batch_size=3, 
        batch_processor=sum_batch_processor, 
        max_workers=2
    )
    
    transform_block = LinkableTransformBlock(
        transform_func=square_transform, 
        max_workers=3
    )
    
    result_batch_block = LinkableBatchBlock(
        batch_size=2, 
        batch_processor=final_batch_processor, 
        max_workers=2
    )
    
    # Link blocks with configurable consumer instances
    input_batch_block.link_to(transform_block, num_instances=2)  # 2 transform instances
    transform_block.link_to(result_batch_block, num_instances=1)  # 1 result batch instance
    
    # Create pipeline
    pipeline = DataflowPipeline()
    pipeline.add_block(input_batch_block)
    pipeline.add_block(transform_block)
    pipeline.add_block(result_batch_block)
    
    # Start pipeline
    pipeline.start_all()
    
    # Post data
    input_data = list(range(1, 16))  # 15 numbers
    print(f"Input data: {input_data}")
    
    start_time = time.time()
    pipeline.post_data(input_data)
    
    # Wait a moment for processing
    time.sleep(2)
    
    # Complete pipeline
    pipeline.complete_all()
    
    end_time = time.time()
    
    # Get results
    results = pipeline.get_final_results()
    print(f"Pipeline completed in {end_time - start_time:.2f} seconds")
    print(f"Final results ({len(results)} batches):")
    for i, result in enumerate(results):
        print(f"  Batch {i+1}: {result}")
    
    print("\n" + "="*70 + "\n")
    
    # Example 2: String Processing Pipeline
    print("2. String Processing Pipeline with Multiple Consumer Instances")
    
    # Create string processing blocks
    string_input_block = LinkableBatchBlock(
        batch_size=4, 
        batch_processor=string_batch_processor, 
        max_workers=2
    )
    
    string_transform_block = LinkableTransformBlock(
        transform_func=format_transform, 
        max_workers=4
    )
    
    string_result_block = LinkableBatchBlock(
        batch_size=3, 
        batch_processor=final_batch_processor, 
        max_workers=2
    )
    
    # Link with more consumer instances
    string_input_block.link_to(string_transform_block, num_instances=3)  # 3 transform instances
    string_transform_block.link_to(string_result_block, num_instances=2)  # 2 result instances
    
    # Create and run pipeline
    string_pipeline = DataflowPipeline()
    string_pipeline.add_block(string_input_block)
    string_pipeline.add_block(string_transform_block)
    string_pipeline.add_block(string_result_block)
    
    string_pipeline.start_all()
    
    # String input data
    string_data = [
        "apple", "banana", "cherry", "date", "elderberry",
        "fig", "grape", "honeydew", "kiwi", "lemon",
        "mango", "nectarine", "orange", "papaya", "quince"
    ]
    print(f"String input data: {string_data}")
    
    start_time = time.time()
    string_pipeline.post_data(string_data)
    
    # Wait for processing
    time.sleep(3)
    
    string_pipeline.complete_all()
    end_time = time.time()
    
    # Get results
    string_results = string_pipeline.get_final_results()
    print(f"String pipeline completed in {end_time - start_time:.2f} seconds")
    print(f"Final results ({len(string_results)} batches):")
    for i, result in enumerate(string_results):
        print(f"  Batch {i+1}: {result}")
    
    print("\n" + "="*70 + "\n")
    
    # Example 3: Complex Multi-Stage Pipeline
    print("3. Complex Multi-Stage Pipeline with Different Consumer Counts")
    
    def first_stage_processor(batch: List[int]) -> dict:
        """First stage: basic statistics."""
        time.sleep(0.1)
        return {'numbers': batch, 'sum': sum(batch), 'count': len(batch)}
    
    def enrichment_transform(stats: dict) -> dict:
        """Add more computed fields."""
        time.sleep(0.08)
        numbers = stats['numbers']
        return {
            **stats,
            'avg': stats['sum'] / stats['count'],
            'product': 1 if not numbers else eval('*'.join(map(str, numbers))),
            'even_count': sum(1 for n in numbers if n % 2 == 0)
        }
    
    def final_aggregation_processor(batch: List[dict]) -> dict:
        """Final aggregation of enriched data."""
        time.sleep(0.2)
        total_sum = sum(item['sum'] for item in batch)
        total_count = sum(item['count'] for item in batch)
        
        return {
            'aggregated_batches': len(batch),
            'total_numbers_processed': total_count,
            'grand_total_sum': total_sum,
            'overall_average': total_sum / total_count if total_count > 0 else 0,
            'batch_details': batch
        }
    
    # Create complex pipeline
    stage1_block = LinkableBatchBlock(batch_size=5, batch_processor=first_stage_processor, max_workers=2)
    enrich_block = LinkableTransformBlock(transform_func=enrichment_transform, max_workers=4)
    final_block = LinkableBatchBlock(batch_size=3, batch_processor=final_aggregation_processor, max_workers=2)
    
    # Link with different consumer counts
    stage1_block.link_to(enrich_block, num_instances=4)  # 4 enrichment workers
    enrich_block.link_to(final_block, num_instances=2)   # 2 final processing workers
    
    # Create and run complex pipeline
    complex_pipeline = DataflowPipeline()
    complex_pipeline.add_block(stage1_block)
    complex_pipeline.add_block(enrich_block)
    complex_pipeline.add_block(final_block)
    
    complex_pipeline.start_all()
    
    # Large dataset
    complex_data = list(range(1, 31))  # 30 numbers
    print(f"Complex data: {len(complex_data)} numbers (1-30)")
    
    start_time = time.time()
    complex_pipeline.post_data(complex_data)
    
    # Wait for processing
    time.sleep(4)
    
    complex_pipeline.complete_all()
    end_time = time.time()
    
    # Get results
    complex_results = complex_pipeline.get_final_results()
    print(f"Complex pipeline completed in {end_time - start_time:.2f} seconds")
    print(f"Final aggregated results:")
    for i, result in enumerate(complex_results):
        print(f"  Aggregation {i+1}:")
        print(f"    Batches aggregated: {result['aggregated_batches']}")
        print(f"    Total numbers: {result['total_numbers_processed']}")
        print(f"    Grand total sum: {result['grand_total_sum']}")
        print(f"    Overall average: {result['overall_average']:.2f}")
