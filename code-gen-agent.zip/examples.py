"""
Example usage of the Code Generator
"""

import asyncio
from code_generator import CodeGenerator


async def example_basic_generation():
    """Example: Basic code generation"""
    print("=== Basic Code Generation ===\n")
    
    generator = CodeGenerator()
    
    try:
        prompt = "Create a function to calculate the factorial of a number"
        result = await generator.generate(prompt)
        
        print(f"Prompt: {prompt}\n")
        print(f"Generated Code:\n{result}\n")
    finally:
        await generator.close()


async def example_generate_function():
    """Example: Generate a specific function"""
    print("=== Generate Function ===\n")
    
    generator = CodeGenerator()
    
    try:
        result = await generator.generate_function(
            function_name="validate_email",
            description="validates an email address using regex",
            language="python"
        )
        
        print(f"Generated Function:\n{result}\n")
    finally:
        await generator.close()


async def example_generate_class():
    """Example: Generate a class"""
    print("=== Generate Class ===\n")
    
    generator = CodeGenerator()
    
    try:
        result = await generator.generate_class(
            class_name="BankAccount",
            description="manages a bank account with deposits and withdrawals",
            methods=[
                "deposit(amount) - adds money to the account",
                "withdraw(amount) - removes money from the account",
                "get_balance() - returns the current balance"
            ],
            language="python"
        )
        
        print(f"Generated Class:\n{result}\n")
    finally:
        await generator.close()


async def example_with_custom_model():
    """Example: Using a specific model"""
    print("=== Using Custom Model (Claude) ===\n")
    
    # You can specify different models like "gpt-4o", "claude-sonnet-4", "o1"
    generator = CodeGenerator(model="claude-sonnet-4")
    
    try:
        result = await generator.generate(
            "Create a Python decorator that measures function execution time"
        )
        
        print(f"Generated Code:\n{result}\n")
    finally:
        await generator.close()


async def main():
    """Run all examples"""
    try:
        await example_basic_generation()
        print("\n" + "="*70 + "\n")
        
        await example_generate_function()
        print("\n" + "="*70 + "\n")
        
        await example_generate_class()
        print("\n" + "="*70 + "\n")
        
        await example_with_custom_model()
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
