# CSV Loader and Memory Reporter

Load two CSV files from the `data/` folder into pandas and print their memory consumption. Includes memory-efficient options for large datasets.

## Setup

```powershell
# From the repo root
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Usage

### Basic Memory Reporting
```powershell
# Uses default files: master_sales_record.csv and mod_sales_record.csv from data/
python .\main.py

# Memory-efficient loading - only required columns with optimized dtypes
python .\main.py --memory-efficient

# Use different files
python .\main.py --file1 "100000 Sales Records.csv" --file2 "100000-Sales-Records.zip"
```

### Sales Trend Report Generation
```powershell
# Generate report with default files
python .\main.py --generate-report

# Generate report with memory-efficient loading (recommended for large files)
python .\main.py --generate-report --memory-efficient

# Generate report and save as PDF
python .\main.py --generate-report --save-pdf

# Generate report with memory-efficient loading and save as PDF
python .\main.py --generate-report --memory-efficient --save-pdf
```

### Performance Comparison: Pandas vs DuckDB
```powershell
# Compare pandas vs DuckDB performance and memory usage with default files
python .\main.py --compare-engines

# Compare with different files
python .\main.py --file1 "100000 Sales Records.csv" --file2 "100000-Sales-Records.zip" --compare-engines
```

### Performance Comparison: Pandas vs DuckDB
```powershell
# Compare pandas vs DuckDB performance and memory usage
python .\main.py --file1 "master_sales_record.csv" --file2 "mod_sales_record.csv" --compare-engines
```

This will show you:
- Loading time for each approach
- Peak memory usage
- Total processing time 
- Identical results from both engines

### Custom Data Directory
```powershell
python .\main.py --file1 fileA.csv --file2 fileB.csv --data-dir path\to\data --memory-efficient
```

## Performance Comparison: Pandas vs DuckDB
```powershell
# Compare pandas vs DuckDB performance and memory usage with default files
python .\main.py --compare-engines

# Compare with different files
python .\main.py --file1 "100000 Sales Records.csv" --file2 "100000-Sales-Records.zip" --compare-engines
```

This will show you:
- Loading time for each approach
- Peak memory usage
- Total processing time 
- Identical results from both engines

## Memory Optimizations

### Pandas Optimizations
- **Column Selection**: Only loads required columns (`Region`, `Country`, `Item Type`, `Sales Channel`, `Total Profit`)
- **Dtype Optimization**: Uses `category` dtype for grouping columns to reduce memory
- **Direct Aggregation**: Avoids intermediate DataFrame copies during report generation
- **Vectorized Operations**: Uses vectorized trend calculation instead of row-by-row apply

### DuckDB Optimizations  
- **Streaming Processing**: Never loads full CSV files into memory
- **SQL-based Aggregation**: Optimized columnar processing
- **Lazy Evaluation**: Only processes the data needed for final result
- **Zero-Copy Operations**: Minimal memory overhead

**Expected Results**: DuckDB typically uses 70-90% less memory than pandas for large datasets.
