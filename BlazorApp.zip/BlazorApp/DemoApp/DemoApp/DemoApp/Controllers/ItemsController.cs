﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new[]
            {
                new Shared.Items { Id = 1, Name = "Item 1", Description = "Description 1", Price = 1.99m, Quantity = 10 },
                new Shared.Items { Id = 2, Name = "Item 2", Description = "Description 2", Price = 2.99m, Quantity = 20 },
                new Shared.Items { Id = 3, Name = "Item 3", Description = "Description 3", Price = 3.99m, Quantity = 30 },
            });
        }
    }
}
