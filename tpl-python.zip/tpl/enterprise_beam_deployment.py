"""
Enterprise Apache Beam Cloud Deployment Configuration
Production-ready deployment configurations for EKS and other cloud environments

This module provides enterprise deployment configurations for:
- Kubernetes/EKS deployment
- Docker containerization
- CI/CD pipeline integration
- Monitoring and alerting setup
"""

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions, WorkerOptions
import os
import yaml
from typing import Dict, Any, List
import logging


logger = logging.getLogger(__name__)


class CloudDeploymentConfig:
    """
    Enterprise cloud deployment configuration manager.
    
    This class manages all the configuration needed to deploy
    Apache Beam pipelines to various cloud environments.
    """
    
    def __init__(self, environment: str = "development"):
        self.environment = environment
        self.configs = self._load_environment_configs()
    
    def _load_environment_configs(self) -> Dict[str, Any]:
        """Load environment-specific configurations."""
        
        base_config = {
            "development": {
                "runner": "DirectRunner",
                "max_num_workers": 2,
                "machine_type": "n1-standard-2",
                "disk_size_gb": 20,
                "use_public_ips": True,
                "network": "default"
            },
            "staging": {
                "runner": "DataflowRunner",  # Can be changed to FlinkRunner for EKS
                "max_num_workers": 10,
                "machine_type": "n1-standard-4",
                "disk_size_gb": 50,
                "use_public_ips": False,
                "network": "projects/your-project/global/networks/vpc-staging"
            },
            "production": {
                "runner": "DataflowRunner",  # Can be changed to FlinkRunner for EKS
                "max_num_workers": 50,
                "machine_type": "n1-standard-8",
                "disk_size_gb": 100,
                "use_public_ips": False,
                "network": "projects/your-project/global/networks/vpc-production",
                "enable_streaming_engine": True,
                "use_runner_v2": True
            }
        }
        
        return base_config
    
    def get_pipeline_options(self, project_id: str = None, region: str = None, 
                           temp_location: str = None, staging_location: str = None) -> PipelineOptions:
        """
        Get configured pipeline options for the specified environment.
        
        Args:
            project_id: GCP project ID (required for cloud runners)
            region: Cloud region (e.g., 'us-central1')
            temp_location: Temporary storage location (e.g., 'gs://bucket/temp')
            staging_location: Staging storage location (e.g., 'gs://bucket/staging')
        """
        
        config = self.configs.get(self.environment, self.configs["development"])
        
        # Base options
        options_list = [
            f'--runner={config["runner"]}',
            f'--max_num_workers={config["max_num_workers"]}',
            f'--machine_type={config["machine_type"]}',
            f'--disk_size_gb={config["disk_size_gb"]}',
            '--save_main_session=True',
            '--setup_file=./setup.py'  # Include if you have custom dependencies
        ]
        
        # Add cloud-specific options
        if config["runner"] != "DirectRunner":
            if project_id:
                options_list.append(f'--project={project_id}')
            if region:
                options_list.append(f'--region={region}')
            if temp_location:
                options_list.append(f'--temp_location={temp_location}')
            if staging_location:
                options_list.append(f'--staging_location={staging_location}')
            
            # Network configuration
            if "network" in config:
                options_list.append(f'--network={config["network"]}')
            
            if not config.get("use_public_ips", True):
                options_list.append('--use_public_ips=False')
        
        # Production optimizations
        if self.environment == "production":
            options_list.extend([
                '--experiments=use_runner_v2',
                '--experiments=enable_streaming_engine',
                '--autoscaling_algorithm=THROUGHPUT_BASED',
                '--enable_streaming_engine=True'
            ])
        
        return PipelineOptions(options_list)


def create_dockerfile() -> str:
    """
    Create a production-ready Dockerfile for the Apache Beam pipeline.
    """
    
    dockerfile_content = """
# Enterprise Apache Beam Pipeline Dockerfile
FROM apache/beam_python3.9_sdk:latest

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    curl \\
    wget \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create non-root user for security
RUN useradd -m -u 1000 beamuser && chown -R beamuser:beamuser /app
USER beamuser

# Set environment variables
ENV PYTHONPATH=/app
ENV BEAM_WORKER_POOL_SIZE=4

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=30s --retries=3 \\
    CMD python -c "import apache_beam; print('Beam is healthy')" || exit 1

# Default command
CMD ["python", "enterprise_beam_pipeline.py"]
"""
    
    return dockerfile_content.strip()


def create_kubernetes_deployment() -> str:
    """
    Create Kubernetes deployment configuration for EKS.
    """
    
    k8s_deployment = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: enterprise-beam-pipeline
  namespace: data-processing
  labels:
    app: enterprise-beam
    version: v1.0.0
    tier: data-processing
spec:
  replicas: 3
  selector:
    matchLabels:
      app: enterprise-beam
  template:
    metadata:
      labels:
        app: enterprise-beam
        version: v1.0.0
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
        prometheus.io/path: "/metrics"
    spec:
      serviceAccountName: beam-service-account
      containers:
      - name: beam-pipeline
        image: your-registry.com/enterprise-beam:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8080
          name: metrics
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: PROJECT_ID
          valueFrom:
            configMapKeyRef:
              name: beam-config
              key: project-id
        - name: REGION
          valueFrom:
            configMapKeyRef:
              name: beam-config
              key: region
        - name: TEMP_LOCATION
          valueFrom:
            configMapKeyRef:
              name: beam-config
              key: temp-location
        - name: STAGING_LOCATION
          valueFrom:
            configMapKeyRef:
              name: beam-config
              key: staging-location
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
          timeoutSeconds: 10
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        volumeMounts:
        - name: config-volume
          mountPath: /app/config
          readOnly: true
        - name: logs-volume
          mountPath: /app/logs
      volumes:
      - name: config-volume
        configMap:
          name: beam-config
      - name: logs-volume
        emptyDir: {}
      restartPolicy: Always
      tolerations:
      - key: "data-processing"
        operator: "Equal"
        value: "true"
        effect: "NoSchedule"
      affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
            - matchExpressions:
              - key: node-type
                operator: In
                values:
                - data-processing
---
apiVersion: v1
kind: Service
metadata:
  name: enterprise-beam-service
  namespace: data-processing
  labels:
    app: enterprise-beam
spec:
  selector:
    app: enterprise-beam
  ports:
  - name: metrics
    port: 8080
    targetPort: 8080
    protocol: TCP
  type: ClusterIP
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: beam-config
  namespace: data-processing
data:
  project-id: "your-gcp-project-id"
  region: "us-central1"
  temp-location: "gs://your-bucket/temp"
  staging-location: "gs://your-bucket/staging"
  batch-size: "15"
  max-workers: "10"
  quality-threshold: "0.8"
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: beam-service-account
  namespace: data-processing
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::YOUR-ACCOUNT:role/beam-pipeline-role
"""
    
    return k8s_deployment.strip()


def create_helm_chart() -> Dict[str, str]:
    """
    Create Helm chart configuration for easier deployment management.
    """
    
    chart_yaml = """
apiVersion: v2
name: enterprise-beam-pipeline
description: Enterprise Apache Beam Pipeline Helm Chart
type: application
version: 1.0.0
appVersion: "1.0.0"
keywords:
  - apache-beam
  - data-processing
  - enterprise
home: https://github.com/your-org/enterprise-beam
maintainers:
  - name: Data Engineering Team
    email: data-eng@yourcompany.com
"""
    
    values_yaml = """
# Default values for enterprise-beam-pipeline
replicaCount: 3

image:
  repository: your-registry.com/enterprise-beam
  pullPolicy: Always
  tag: "latest"

serviceAccount:
  create: true
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::YOUR-ACCOUNT:role/beam-pipeline-role
  name: "beam-service-account"

service:
  type: ClusterIP
  port: 8080

ingress:
  enabled: false
  className: ""
  annotations: {}
  hosts:
    - host: beam-pipeline.local
      paths:
        - path: /
          pathType: Prefix
  tls: []

resources:
  limits:
    cpu: 2000m
    memory: 4Gi
  requests:
    cpu: 1000m
    memory: 2Gi

autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
  targetMemoryUtilizationPercentage: 80

nodeSelector:
  node-type: data-processing

tolerations:
  - key: "data-processing"
    operator: "Equal"
    value: "true"
    effect: "NoSchedule"

affinity: {}

config:
  projectId: "your-gcp-project-id"
  region: "us-central1"
  tempLocation: "gs://your-bucket/temp"
  stagingLocation: "gs://your-bucket/staging"
  batchSize: 15
  maxWorkers: 10
  qualityThreshold: 0.8

monitoring:
  enabled: true
  prometheus:
    enabled: true
    port: 8080
    path: /metrics
  grafana:
    enabled: true
    dashboardsConfigMap: beam-dashboards

logging:
  level: INFO
  format: json
  destination: stdout

security:
  runAsNonRoot: true
  runAsUser: 1000
  fsGroup: 1000
  seccompProfile:
    type: RuntimeDefault
"""
    
    deployment_template = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "enterprise-beam-pipeline.fullname" . }}
  labels:
    {{- include "enterprise-beam-pipeline.labels" . | nindent 4 }}
spec:
  {{- if not .Values.autoscaling.enabled }}
  replicas: {{ .Values.replicaCount }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "enterprise-beam-pipeline.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      annotations:
        prometheus.io/scrape: "{{ .Values.monitoring.prometheus.enabled }}"
        prometheus.io/port: "{{ .Values.monitoring.prometheus.port }}"
        prometheus.io/path: "{{ .Values.monitoring.prometheus.path }}"
      labels:
        {{- include "enterprise-beam-pipeline.selectorLabels" . | nindent 8 }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ include "enterprise-beam-pipeline.serviceAccountName" . }}
      securityContext:
        runAsNonRoot: {{ .Values.security.runAsNonRoot }}
        runAsUser: {{ .Values.security.runAsUser }}
        fsGroup: {{ .Values.security.fsGroup }}
      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          ports:
            - name: metrics
              containerPort: {{ .Values.monitoring.prometheus.port }}
              protocol: TCP
          env:
            - name: ENVIRONMENT
              value: "production"
            - name: PROJECT_ID
              value: "{{ .Values.config.projectId }}"
            - name: REGION
              value: "{{ .Values.config.region }}"
            - name: TEMP_LOCATION
              value: "{{ .Values.config.tempLocation }}"
            - name: STAGING_LOCATION
              value: "{{ .Values.config.stagingLocation }}"
            - name: BATCH_SIZE
              value: "{{ .Values.config.batchSize }}"
            - name: MAX_WORKERS
              value: "{{ .Values.config.maxWorkers }}"
            - name: QUALITY_THRESHOLD
              value: "{{ .Values.config.qualityThreshold }}"
          livenessProbe:
            httpGet:
              path: /health
              port: metrics
            initialDelaySeconds: 60
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /ready
              port: metrics
            initialDelaySeconds: 30
            periodSeconds: 10
          resources:
            {{- toYaml .Values.resources | nindent 12 }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
"""
    
    return {
        "Chart.yaml": chart_yaml.strip(),
        "values.yaml": values_yaml.strip(),
        "templates/deployment.yaml": deployment_template.strip()
    }


def create_ci_cd_pipeline() -> str:
    """
    Create CI/CD pipeline configuration (GitHub Actions example).
    """
    
    github_actions = """
name: Enterprise Beam Pipeline CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

env:
  REGISTRY: your-registry.com
  IMAGE_NAME: enterprise-beam
  CLUSTER_NAME: your-eks-cluster
  CLUSTER_REGION: us-west-2

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python 3.9
      uses: actions/setup-python@v4
      with:
        python-version: 3.9
        
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest pytest-cov flake8
        
    - name: Lint with flake8
      run: |
        flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
        flake8 . --count --exit-zero --max-complexity=10 --max-line-length=127 --statistics
        
    - name: Test with pytest
      run: |
        pytest tests/ --cov=./ --cov-report=xml
        
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml

  build:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: ${{ env.CLUSTER_REGION }}
        
    - name: Login to Amazon ECR
      id: login-ecr
      uses: aws-actions/amazon-ecr-login@v1
      
    - name: Build, tag, and push image to Amazon ECR
      env:
        ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
        IMAGE_TAG: ${{ github.sha }}
      run: |
        docker build -t $ECR_REGISTRY/$IMAGE_NAME:$IMAGE_TAG .
        docker build -t $ECR_REGISTRY/$IMAGE_NAME:latest .
        docker push $ECR_REGISTRY/$IMAGE_NAME:$IMAGE_TAG
        docker push $ECR_REGISTRY/$IMAGE_NAME:latest

  deploy-staging:
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment: staging
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: ${{ env.CLUSTER_REGION }}
        
    - name: Update kube config
      run: aws eks update-kubeconfig --name $CLUSTER_NAME --region $CLUSTER_REGION
      
    - name: Install Helm
      uses: azure/setup-helm@v3
      with:
        version: '3.10.0'
        
    - name: Deploy to staging
      env:
        ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
        IMAGE_TAG: ${{ github.sha }}
      run: |
        helm upgrade --install enterprise-beam-staging ./helm-chart \\
          --namespace data-processing-staging \\
          --create-namespace \\
          --set image.repository=$ECR_REGISTRY/$IMAGE_NAME \\
          --set image.tag=$IMAGE_TAG \\
          --set config.projectId=${{ secrets.GCP_PROJECT_ID }} \\
          --values ./helm-chart/values-staging.yaml

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment: production
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: ${{ env.CLUSTER_REGION }}
        
    - name: Update kube config
      run: aws eks update-kubeconfig --name $CLUSTER_NAME --region $CLUSTER_REGION
      
    - name: Install Helm
      uses: azure/setup-helm@v3
      with:
        version: '3.10.0'
        
    - name: Deploy to production
      env:
        ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
        IMAGE_TAG: ${{ github.sha }}
      run: |
        helm upgrade --install enterprise-beam-production ./helm-chart \\
          --namespace data-processing-production \\
          --create-namespace \\
          --set image.repository=$ECR_REGISTRY/$IMAGE_NAME \\
          --set image.tag=$IMAGE_TAG \\
          --set config.projectId=${{ secrets.GCP_PROJECT_ID }} \\
          --values ./helm-chart/values-production.yaml
"""
    
    return github_actions.strip()


def create_monitoring_config() -> Dict[str, str]:
    """
    Create monitoring and alerting configuration.
    """
    
    prometheus_config = """
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "beam_alerts.yml"

scrape_configs:
  - job_name: 'enterprise-beam'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
            - data-processing-staging
            - data-processing-production
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: true
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
        action: replace
        target_label: __metrics_path__
        regex: (.+)
      - source_labels: [__address__, __meta_kubernetes_pod_annotation_prometheus_io_port]
        action: replace
        regex: ([^:]+)(?::\\d+)?;(\\d+)
        replacement: $1:$2
        target_label: __address__

alerting:
  alertmanagers:
    - kubernetes_sd_configs:
        - role: pod
          namespaces:
            names:
              - monitoring
      relabel_configs:
        - source_labels: [__meta_kubernetes_pod_label_app]
          action: keep
          regex: alertmanager
"""
    
    alert_rules = """
groups:
- name: enterprise-beam-alerts
  rules:
  - alert: BeamPipelineDown
    expr: up{job="enterprise-beam"} == 0
    for: 1m
    labels:
      severity: critical
    annotations:
      summary: "Beam pipeline is down"
      description: "Enterprise Beam pipeline {{ $labels.instance }} has been down for more than 1 minute."
      
  - alert: BeamHighErrorRate
    expr: rate(beam_errors_total[5m]) > 0.1
    for: 2m
    labels:
      severity: warning
    annotations:
      summary: "High error rate in Beam pipeline"
      description: "Error rate is {{ $value }} errors per second in {{ $labels.instance }}."
      
  - alert: BeamHighMemoryUsage
    expr: container_memory_usage_bytes{pod=~"enterprise-beam.*"} / container_spec_memory_limit_bytes > 0.9
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "High memory usage in Beam pipeline"
      description: "Memory usage is above 90% in {{ $labels.pod }}."
      
  - alert: BeamLowThroughput
    expr: rate(beam_items_processed_total[10m]) < 10
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "Low throughput in Beam pipeline"
      description: "Processing throughput is {{ $value }} items/second, below expected minimum."
"""
    
    grafana_dashboard = """
{
  "dashboard": {
    "id": null,
    "title": "Enterprise Apache Beam Pipeline",
    "tags": ["beam", "data-processing"],
    "timezone": "browser",
    "panels": [
      {
        "id": 1,
        "title": "Processing Throughput",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(beam_items_processed_total[1m])",
            "legendFormat": "Items/sec - {{instance}}"
          }
        ],
        "yAxes": [
          {
            "label": "Items per second"
          }
        ]
      },
      {
        "id": 2,
        "title": "Error Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(beam_errors_total[1m])",
            "legendFormat": "Errors/sec - {{instance}}"
          }
        ]
      },
      {
        "id": 3,
        "title": "Memory Usage",
        "type": "graph",
        "targets": [
          {
            "expr": "container_memory_usage_bytes{pod=~\"enterprise-beam.*\"} / 1024 / 1024",
            "legendFormat": "Memory MB - {{pod}}"
          }
        ]
      },
      {
        "id": 4,
        "title": "CPU Usage",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(container_cpu_usage_seconds_total{pod=~\"enterprise-beam.*\"}[1m]) * 100",
            "legendFormat": "CPU % - {{pod}}"
          }
        ]
      }
    ],
    "time": {
      "from": "now-1h",
      "to": "now"
    },
    "refresh": "5s"
  }
}
"""
    
    return {
        "prometheus.yml": prometheus_config.strip(),
        "beam_alerts.yml": alert_rules.strip(),
        "grafana_dashboard.json": grafana_dashboard.strip()
    }


def create_requirements_txt() -> str:
    """
    Create requirements.txt for the enterprise pipeline.
    """
    
    requirements = """
# Apache Beam and core dependencies
apache-beam[gcp]==2.50.0
apache-beam[aws]==2.50.0
apache-beam[interactive]==2.50.0

# Cloud storage and databases
google-cloud-storage==2.10.0
boto3==1.29.0
psycopg2-binary==2.9.7

# Data processing and analysis
pandas==2.1.0
numpy==1.24.3
pyarrow==13.0.0

# Monitoring and logging
prometheus-client==0.17.1
structlog==23.1.0
opencensus-ext-prometheus==0.8.0

# Configuration and utilities
pyyaml==6.0.1
python-dateutil==2.8.2
requests==2.31.0

# Development and testing
pytest==7.4.0
pytest-cov==4.1.0
flake8==6.0.0
black==23.7.0

# Security
cryptography==41.0.4
"""
    
    return requirements.strip()


def create_setup_py() -> str:
    """
    Create setup.py for packaging the pipeline.
    """
    
    setup_py = """
from setuptools import setup, find_packages

setup(
    name='enterprise-apache-beam-pipeline',
    version='1.0.0',
    description='Enterprise-grade Apache Beam data processing pipeline',
    author='Data Engineering Team',
    author_email='data-eng@yourcompany.com',
    packages=find_packages(),
    install_requires=[
        'apache-beam[gcp]>=2.50.0',
        'apache-beam[aws]>=2.50.0',
        'google-cloud-storage>=2.10.0',
        'boto3>=1.29.0',
        'pandas>=2.1.0',
        'numpy>=1.24.3',
        'pyarrow>=13.0.0',
        'prometheus-client>=0.17.1',
        'structlog>=23.1.0',
        'pyyaml>=6.0.1',
        'python-dateutil>=2.8.2',
        'requests>=2.31.0',
        'cryptography>=41.0.4',
    ],
    python_requires='>=3.8',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
    entry_points={
        'console_scripts': [
            'enterprise-beam-basic=enterprise_beam_basic:main',
            'enterprise-beam-pipeline=enterprise_beam_pipeline:main',
        ],
    },
)
"""
    
    return setup_py.strip()


if __name__ == "__main__":
    """
    Generate all deployment configurations when this module is run directly.
    """
    
    print("🚀 Generating Enterprise Apache Beam Deployment Configurations...")
    
    # Create deployment configurations
    config_manager = CloudDeploymentConfig("production")
    
    # Generate all configuration files
    configurations = {
        "Dockerfile": create_dockerfile(),
        "kubernetes-deployment.yaml": create_kubernetes_deployment(),
        "requirements.txt": create_requirements_txt(),
        "setup.py": create_setup_py(),
        ".github/workflows/ci-cd.yml": create_ci_cd_pipeline()
    }
    
    # Generate Helm chart files
    helm_files = create_helm_chart()
    for filename, content in helm_files.items():
        configurations[f"helm-chart/{filename}"] = content
    
    # Generate monitoring configurations
    monitoring_files = create_monitoring_config()
    for filename, content in monitoring_files.items():
        configurations[f"monitoring/{filename}"] = content
    
    # Write all files (in a real scenario, you'd write these to the filesystem)
    print("\n📁 Generated Configuration Files:")
    for filename, content in configurations.items():
        print(f"   ✅ {filename}")
        # In real implementation:
        # os.makedirs(os.path.dirname(filename), exist_ok=True)
        # with open(filename, 'w') as f:
        #     f.write(content)
    
    print(f"\n✅ Generated {len(configurations)} configuration files for enterprise deployment!")
    print("\n📋 Deployment Instructions:")
    print("1. Review and customize the generated configurations")
    print("2. Update project IDs, regions, and resource names")
    print("3. Set up your container registry and Kubernetes cluster")
    print("4. Configure CI/CD secrets and permissions")
    print("5. Deploy using: helm install enterprise-beam ./helm-chart")
    print("6. Monitor using the provided Grafana dashboards")
