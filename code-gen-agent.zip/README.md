# GitHub Copilot Code Generator

A Python-based code generation agent powered by GitHub Copilot's AI capabilities using the Microsoft Agent Framework.

## Features

- **Interactive Code Generation**: Generate code from natural language prompts
- **Multiple Model Support**: Use GPT-4o, Claude Sonnet 4, O1, and other models
- **Function Generation**: Create functions with specific names and descriptions
- **Class Generation**: Generate complete classes with methods
- **Code Refactoring**: Refactor existing code with AI assistance
- **Documentation**: Automatically add documentation to your code
- **Code Fixing**: Fix errors in existing code
- **System Prompt Customization**: Customize the agent's behavior with custom instructions

## Setup

1. **Install dependencies:**
```bash
pip install -r requirements.txt
```

2. **Configure GitHub Copilot:**

The agent uses the GitHub Copilot CLI, which requires authentication. You can configure it in `.env`:

```env
# Optional: Specify a model (defaults to gpt-4o)
GITHUB_COPILOT_MODEL=gpt-4o

# Optional: Other settings
GITHUB_COPILOT_TIMEOUT=60
GITHUB_COPILOT_LOG_LEVEL=info
GITHUB_COPILOT_CLI_PATH=copilot
```

**Note**: You don't need `COPILOT_GITHUB_TOKEN` in the .env file. The agent uses the GitHub Copilot CLI which handles authentication automatically through your GitHub account.

## Available Models

- `gpt-4o` (default)
- `claude-sonnet-4`
- `o1`
- And other models supported by GitHub Copilot

## Usage

### Interactive Mode

Run the main script for an interactive code generation session:

```bash
python main.py
```

Then enter your prompts:
```
> Create a function to sort a list of dictionaries by a specific key
```

### Using the CodeGenerator Module

```python
import asyncio
from code_generator import CodeGenerator

async def main():
    # Create generator with optional model specification
    generator = CodeGenerator(model=\"gpt-4o\")
    
    try:
        # Generate a function
        code = await generator.generate_function(
            function_name=\"calculate_average\",
            description=\"calculates the average of a list of numbers\"
        )
        print(code)
    finally:
        await generator.close()  # Clean up resources

asyncio.run(main())
```

### Custom System Instructions

```python
generator = CodeGenerator(
    model=\"claude-sonnet-4\",
    system_instructions=\"You are a Python expert. Always use type hints and write comprehensive docstrings.\"
)
```

### Examples

Run the examples to see various use cases:

```bash
python examples.py
```

## Available Methods

### `generate(prompt, context=None)`
Generate code from a natural language prompt.

```python
code = await generator.generate(
    \"Create a REST API endpoint for user authentication\",
    context=\"Using FastAPI framework\"
)
```

### `generate_function(function_name, description, language='python')`
Generate a specific function with the given name and description.

### `generate_class(class_name, description, methods=None, language='python')`
Generate a class with specified methods.

### `refactor_code(code, instructions)`
Refactor existing code based on instructions.

### `add_documentation(code)`
Add comprehensive documentation to existing code.

### `fix_code(code, error_message=None)`
Fix errors in code with optional error message context.

## API Reference

### GitHubCopilotAgent

The underlying agent supports these options:

- **instructions**: System instructions for the agent
- **name**: Agent name
- **description**: Agent description
- **default_options**:
  - `model`: Model to use (e.g., \"gpt-4o\", \"claude-sonnet-4\")
  - `timeout`: Request timeout in seconds
  - `system_message`: System message configuration with `mode` (\"append\" or \"replace\") and `content`
  - `cli_path`: Path to Copilot CLI executable
  - `log_level`: CLI log level
  - `on_permission_request`: Permission request handler
  - `mcp_servers`: MCP server configurations
- **tools**: Custom tools for the agent
- **context_provider**: Context provider for the agent
- **middleware**: Agent middleware

## Project Structure

```
code-gen-agent/
├── main.py              # Interactive CLI application
├── code_generator.py    # Core CodeGenerator class
├── examples.py          # Usage examples
├── requirements.txt     # Python dependencies
├── .env                 # Environment variables (optional)
└── README.md           # This file
```

## Requirements

- Python 3.8+
- GitHub Copilot CLI access
- Internet connection for API calls

## License

MIT
