"""
Enterprise Apache Beam Basic Implementation
Provides TPL-like functionality with enterprise features

This module demonstrates basic Apache Beam usage with:
- Batch processing (like TPL BatchBlock)
- Transform processing (like TPL TransformBlock)  
- Error handling and monitoring
- Configuration management
"""

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, SetupOptions
from apache_beam.transforms import window
import time
import logging
import argparse
from typing import List, Any, Dict, Optional
from dataclasses import dataclass, field
import json


# Configure logging for enterprise visibility
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class ProcessingConfig:
    """
    Enterprise configuration for processing behavior.
    
    This is like having a control panel for your data factory where you can
    adjust all the important settings without changing the code.
    """
    batch_size: int = 10
    max_workers: int = 4
    timeout_seconds: int = 300
    enable_monitoring: bool = True
    error_threshold: float = 0.1  # 10% error rate threshold
    processing_delay: float = 0.1  # Simulate processing time


class EnterpriseBatchProcessor(beam.DoFn):
    """
    Enterprise-grade batch processor equivalent to TPL's BatchBlock.
    
    This is like a processing station in a factory that:
    1. Takes a batch of items (like a group of car parts)
    2. Processes them together (like painting all parts the same color)
    3. Produces results with quality control
    4. Handles errors gracefully
    5. Reports metrics for monitoring
    """
    
    def __init__(self, config: ProcessingConfig):
        self.config = config
        self.processed_counter = beam.metrics.Metrics.counter('enterprise', 'batches_processed')
        self.error_counter = beam.metrics.Metrics.counter('enterprise', 'batch_errors')
        self.processing_timer = beam.metrics.Metrics.distribution('enterprise', 'batch_processing_time')
    
    def setup(self):
        """Called once per worker when the pipeline starts."""
        logger.info("🏭 EnterpriseBatchProcessor starting up")
    
    def process(self, batch: List[Any], window=beam.DoFn.WindowParam):
        """
        Process a batch of items with enterprise features.
        
        Args:
            batch: List of items to process together
            window: Beam windowing information (for advanced use cases)
        """
        start_time = time.time()
        
        try:
            logger.info(f"🔄 Processing batch of {len(batch)} items")
            
            # Simulate batch processing time
            time.sleep(self.config.processing_delay)
            
            # Calculate batch statistics (like a quality control check)
            if not batch:
                logger.warning("⚠️ Empty batch received")
                yield beam.TaggedOutput('errors', {
                    'error': 'Empty batch',
                    'timestamp': time.time(),
                    'window': str(window)
                })
                return
            
            # Perform batch calculations
            batch_sum = sum(batch) if all(isinstance(x, (int, float)) for x in batch) else 0
            batch_avg = batch_sum / len(batch) if batch else 0
            
            result = {
                'batch_id': f"batch_{int(time.time() * 1000)}",  # Unique ID
                'batch_size': len(batch),
                'items': batch,
                'sum': batch_sum,
                'average': batch_avg,
                'min_value': min(batch) if batch else None,
                'max_value': max(batch) if batch else None,
                'processed_at': time.time(),
                'processing_time': time.time() - start_time,
                'window_info': str(window)
            }
            
            # Update metrics for monitoring
            self.processed_counter.inc()
            self.processing_timer.update(int((time.time() - start_time) * 1000))
            
            logger.info(f"✅ Batch processed successfully: {len(batch)} items, sum={batch_sum}")
            yield beam.TaggedOutput('main', result)
            
        except Exception as e:
            # Enterprise error handling - don't crash the entire pipeline
            error_msg = f"Error processing batch: {str(e)}"
            logger.error(f"❌ {error_msg}")
            
            self.error_counter.inc()
            
            yield beam.TaggedOutput('errors', {
                'error': error_msg,
                'batch': batch,
                'timestamp': time.time(),
                'processing_time': time.time() - start_time
            })
    
    def teardown(self):
        """Called once per worker when the pipeline shuts down."""
        logger.info("🔧 EnterpriseBatchProcessor shutting down")


class EnterpriseTransformProcessor(beam.DoFn):
    """
    Enterprise-grade transform processor equivalent to TPL's TransformBlock.
    
    This is like a specialized workstation that:
    1. Takes individual items (like a single car part)
    2. Transforms each one (like adding special coating)
    3. Produces enhanced results
    4. Tracks performance and errors
    """
    
    def __init__(self, config: ProcessingConfig):
        self.config = config
        self.processed_counter = beam.metrics.Metrics.counter('enterprise', 'items_transformed')
        self.error_counter = beam.metrics.Metrics.counter('enterprise', 'transform_errors')
        self.processing_timer = beam.metrics.Metrics.distribution('enterprise', 'transform_processing_time')
    
    def setup(self):
        """Called once per worker when the pipeline starts."""
        logger.info("🔧 EnterpriseTransformProcessor starting up")
    
    def process(self, batch_result: Dict[str, Any]):
        """
        Transform batch results with enterprise features.
        
        Args:
            batch_result: Result from the batch processing stage
        """
        start_time = time.time()
        
        try:
            logger.info(f"🔄 Transforming batch result: {batch_result.get('batch_id', 'unknown')}")
            
            # Simulate transform processing time
            time.sleep(self.config.processing_delay * 0.5)  # Transforms are usually faster
            
            # Enhance the batch result with additional calculations
            original_sum = batch_result.get('sum', 0)
            original_avg = batch_result.get('average', 0)
            batch_size = batch_result.get('batch_size', 0)
            
            enhanced_result = {
                'original_batch': batch_result,
                'transform_id': f"transform_{int(time.time() * 1000)}",
                'enhancements': {
                    'sum_squared': original_sum ** 2,
                    'sum_cubed': original_sum ** 3,
                    'average_squared': original_avg ** 2,
                    'efficiency_score': original_avg / batch_size if batch_size > 0 else 0,
                    'variance': self._calculate_variance(batch_result.get('items', [])),
                    'std_deviation': self._calculate_std_dev(batch_result.get('items', []))
                },
                'metadata': {
                    'transformed_at': time.time(),
                    'transform_version': '1.0',
                    'processing_time': time.time() - start_time
                }
            }
            
            # Update metrics
            self.processed_counter.inc()
            self.processing_timer.update(int((time.time() - start_time) * 1000))
            
            logger.info(f"✅ Transform completed for batch {batch_result.get('batch_id')}")
            yield beam.TaggedOutput('main', enhanced_result)
            
        except Exception as e:
            # Enterprise error handling
            error_msg = f"Error transforming batch result: {str(e)}"
            logger.error(f"❌ {error_msg}")
            
            self.error_counter.inc()
            
            yield beam.TaggedOutput('errors', {
                'error': error_msg,
                'original_input': batch_result,
                'timestamp': time.time(),
                'processing_time': time.time() - start_time
            })
    
    def _calculate_variance(self, items: List[Any]) -> float:
        """Calculate variance of numeric items."""
        try:
            numeric_items = [x for x in items if isinstance(x, (int, float))]
            if len(numeric_items) < 2:
                return 0.0
            
            mean = sum(numeric_items) / len(numeric_items)
            variance = sum((x - mean) ** 2 for x in numeric_items) / len(numeric_items)
            return variance
        except:
            return 0.0
    
    def _calculate_std_dev(self, items: List[Any]) -> float:
        """Calculate standard deviation of numeric items."""
        try:
            variance = self._calculate_variance(items)
            return variance ** 0.5
        except:
            return 0.0
    
    def teardown(self):
        """Called once per worker when the pipeline shuts down."""
        logger.info("🔧 EnterpriseTransformProcessor shutting down")


class EnterpriseFinalProcessor(beam.DoFn):
    """
    Enterprise-grade final aggregation processor.
    
    This is like the final quality control and packaging station that:
    1. Takes all transformed results
    2. Creates final aggregated reports
    3. Ensures data quality
    4. Prepares results for output
    """
    
    def __init__(self, config: ProcessingConfig):
        self.config = config
        self.processed_counter = beam.metrics.Metrics.counter('enterprise', 'final_items_processed')
        self.error_counter = beam.metrics.Metrics.counter('enterprise', 'final_errors')
    
    def setup(self):
        logger.info("📊 EnterpriseFinalProcessor starting up")
    
    def process(self, enhanced_result: Dict[str, Any]):
        """
        Perform final processing and aggregation.
        
        Args:
            enhanced_result: Result from the transform stage
        """
        start_time = time.time()
        
        try:
            logger.info(f"📊 Final processing for transform {enhanced_result.get('transform_id')}")
            
            # Extract data for final aggregation
            original_batch = enhanced_result.get('original_batch', {})
            enhancements = enhanced_result.get('enhancements', {})
            
            final_result = {
                'final_id': f"final_{int(time.time() * 1000)}",
                'summary': {
                    'batch_id': original_batch.get('batch_id'),
                    'original_batch_size': original_batch.get('batch_size', 0),
                    'original_sum': original_batch.get('sum', 0),
                    'original_average': original_batch.get('average', 0),
                    'enhanced_sum_squared': enhancements.get('sum_squared', 0),
                    'efficiency_score': enhancements.get('efficiency_score', 0),
                    'data_quality_score': self._calculate_quality_score(original_batch, enhancements)
                },
                'performance_metrics': {
                    'total_processing_time': time.time() - start_time,
                    'batch_processing_time': original_batch.get('processing_time', 0),
                    'transform_processing_time': enhanced_result.get('metadata', {}).get('processing_time', 0)
                },
                'enterprise_metadata': {
                    'pipeline_version': '1.0.0',
                    'processed_at': time.time(),
                    'quality_assured': True,
                    'compliance_checked': True
                }
            }
            
            self.processed_counter.inc()
            
            logger.info(f"✅ Final processing completed for {original_batch.get('batch_id')}")
            yield final_result
            
        except Exception as e:
            error_msg = f"Error in final processing: {str(e)}"
            logger.error(f"❌ {error_msg}")
            
            self.error_counter.inc()
            
            yield {
                'error': error_msg,
                'input': enhanced_result,
                'timestamp': time.time()
            }
    
    def _calculate_quality_score(self, original_batch: Dict, enhancements: Dict) -> float:
        """Calculate a data quality score (0.0 to 1.0)."""
        try:
            # Simple quality scoring based on data completeness and validity
            score = 1.0
            
            # Check if required fields are present
            required_fields = ['batch_size', 'sum', 'average']
            for field in required_fields:
                if field not in original_batch:
                    score -= 0.2
            
            # Check for reasonable values
            if original_batch.get('batch_size', 0) <= 0:
                score -= 0.3
                
            # Check enhancement quality
            if enhancements.get('efficiency_score', 0) < 0:
                score -= 0.1
            
            return max(0.0, score)
            
        except:
            return 0.5  # Default quality score


def create_enterprise_pipeline(config: ProcessingConfig, input_data: List[Any]) -> beam.Pipeline:
    """
    Create an enterprise-grade Apache Beam pipeline.
    
    This is like designing the entire factory layout with all stations
    connected properly and quality control at each step.
    
    Args:
        config: Configuration for processing behavior
        input_data: List of items to process
        
    Returns:
        Configured Apache Beam Pipeline
    """
    
    # Configure pipeline options for enterprise deployment
    pipeline_options = PipelineOptions([
        '--runner=DirectRunner',  # Use DirectRunner for local development
        f'--max_num_workers={config.max_workers}',
        '--experiments=use_runner_v2',  # Use latest runner features
    ])
    
    # Enable setup.py requirement if needed for dependencies
    pipeline_options.view_as(SetupOptions).save_main_session = True
    
    # Create the pipeline
    pipeline = beam.Pipeline(options=pipeline_options)
    
    logger.info(f"🏗️ Creating enterprise pipeline with {len(input_data)} input items")
    
    # Main processing pipeline
    main_results = (
        pipeline
        | 'Create Input Data' >> beam.Create(input_data)
        | 'Add Timestamps' >> beam.Map(lambda x: beam.window.TimestampedValue(x, time.time()))
        | 'Create Batches' >> beam.BatchElements(
            min_batch_size=config.batch_size,
            max_batch_size=config.batch_size
        )
        | 'Process Batches' >> beam.ParDo(EnterpriseBatchProcessor(config)).with_outputs('errors', main='main')
    )
    
    # Process successful batch results
    transformed_results = (
        main_results.main
        | 'Transform Results' >> beam.ParDo(EnterpriseTransformProcessor(config)).with_outputs('errors', main='main')
    )
    
    # Final processing
    final_results = (
        transformed_results.main
        | 'Final Processing' >> beam.ParDo(EnterpriseFinalProcessor(config))
        | 'Format Output' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Results' >> beam.io.WriteToText('/tmp/enterprise_beam_results', file_name_suffix='.json')
    )
    
    # Handle batch processing errors
    batch_errors = (
        main_results.errors
        | 'Format Batch Errors' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Batch Errors' >> beam.io.WriteToText('/tmp/enterprise_beam_batch_errors', file_name_suffix='.json')
    )
    
    # Handle transform errors
    transform_errors = (
        transformed_results.errors
        | 'Format Transform Errors' >> beam.Map(lambda x: json.dumps(x, indent=2, default=str))
        | 'Write Transform Errors' >> beam.io.WriteToText('/tmp/enterprise_beam_transform_errors', file_name_suffix='.json')
    )
    
    return pipeline


def run_enterprise_beam_pipeline():
    """
    Main function to run the enterprise Apache Beam pipeline.
    
    This is like starting up the entire factory and watching it process
    data through all the stations with full monitoring and error handling.
    """
    
    # Parse command line arguments for enterprise flexibility
    parser = argparse.ArgumentParser(description='Enterprise Apache Beam Pipeline')
    parser.add_argument('--batch_size', type=int, default=10, help='Size of batches to process')
    parser.add_argument('--max_workers', type=int, default=4, help='Maximum number of workers')
    parser.add_argument('--input_size', type=int, default=50, help='Number of input items to generate')
    parser.add_argument('--processing_delay', type=float, default=0.1, help='Simulated processing delay')
    
    args = parser.parse_args()
    
    # Create configuration
    config = ProcessingConfig(
        batch_size=args.batch_size,
        max_workers=args.max_workers,
        processing_delay=args.processing_delay
    )
    
    logger.info("🚀 Starting Enterprise Apache Beam Pipeline")
    logger.info(f"📋 Configuration: batch_size={config.batch_size}, max_workers={config.max_workers}")
    
    # Generate sample input data (in real enterprise use, this would come from databases, files, etc.)
    input_data = list(range(1, args.input_size + 1))
    logger.info(f"📥 Generated {len(input_data)} input items: {input_data[:10]}{'...' if len(input_data) > 10 else ''}")
    
    # Create and run the pipeline
    start_time = time.time()
    
    try:
        pipeline = create_enterprise_pipeline(config, input_data)
        
        logger.info("▶️ Starting pipeline execution...")
        result = pipeline.run()
        result.wait_until_finish()
        
        end_time = time.time()
        total_time = end_time - start_time
        
        logger.info("✅ Pipeline completed successfully!")
        logger.info(f"📊 Performance Summary:")
        logger.info(f"   • Total Processing Time: {total_time:.2f} seconds")
        logger.info(f"   • Items Processed: {len(input_data)}")
        logger.info(f"   • Throughput: {len(input_data) / total_time:.2f} items/second")
        logger.info(f"   • Average Batch Size: {config.batch_size}")
        
        # Display sample results
        logger.info("📄 Results written to:")
        logger.info("   • Main results: /tmp/enterprise_beam_results-*.json")
        logger.info("   • Batch errors: /tmp/enterprise_beam_batch_errors-*.json")
        logger.info("   • Transform errors: /tmp/enterprise_beam_transform_errors-*.json")
        
        # Try to display a sample result
        try:
            import glob
            result_files = glob.glob('/tmp/enterprise_beam_results-*.json')
            if result_files:
                with open(result_files[0], 'r') as f:
                    sample_result = f.readline().strip()
                    if sample_result:
                        logger.info("📋 Sample Result:")
                        print(sample_result)
        except Exception as e:
            logger.warning(f"Could not display sample result: {e}")
            
    except Exception as e:
        logger.error(f"❌ Pipeline failed: {str(e)}")
        raise


if __name__ == '__main__':
    run_enterprise_beam_pipeline()
