---
agent: speckit.git.feature
---
