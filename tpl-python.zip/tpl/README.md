# Python Concurrent Futures Examples
# TPL-like Batch and Transform Blocks

This project demonstrates how to implement TPL (Task Parallel Library) patterns in Python using `concurrent.futures`.

## Examples Included:
- Batch Block: Groups items into batches for processing
- Transform Block: Applies transformations to data streams
- Combined Pipeline: Shows how to chain batch and transform operations

## Usage:
Run the individual example files to see the patterns in action:
- `batch_block_example.py` - Batch processing pattern
- `transform_block_example.py` - Transform processing pattern  
- `pipeline_example.py` - Combined batch + transform pipeline
