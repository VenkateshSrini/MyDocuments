"""
Pipeline Example combining Batch and Transform Blocks
Demonstrates how to chain BatchBlock and TransformBlock patterns

This example shows how to create processing pipelines similar to TPL Dataflow
by combining batch processing and transformation operations.
"""

import concurrent.futures
import time
import random
from typing import List, Any, Callable, Dict
from batch_block_example import BatchBlock
from transform_block_example import TransformBlock


class Pipeline:
    """
    A processing pipeline that chains multiple processing blocks together.
    
    This demonstrates how to combine BatchBlock and TransformBlock patterns
    to create complex data processing workflows.
    """
    
    def __init__(self):
        self.stages = []
    
    def add_transform_stage(self, transform_func: Callable, max_workers: int = None, stage_name: str = None):
        """Add a transform stage to the pipeline."""
        self.stages.append({
            'type': 'transform',
            'block': TransformBlock(transform_func, max_workers),
            'name': stage_name or f'Transform Stage {len(self.stages) + 1}'
        })
        return self
    
    def add_batch_stage(self, batch_size: int, batch_processor: Callable, max_workers: int = None, stage_name: str = None):
        """Add a batch processing stage to the pipeline."""
        self.stages.append({
            'type': 'batch',
            'block': BatchBlock(batch_size, max_workers),
            'processor': batch_processor,
            'name': stage_name or f'Batch Stage {len(self.stages) + 1}'
        })
        return self
    
    def process(self, input_data: List[Any]) -> List[Any]:
        """Process data through all stages of the pipeline."""
        current_data = input_data
        
        for i, stage in enumerate(self.stages):
            print(f"Processing stage {i+1}: {stage['name']}")
            start_time = time.time()
            
            if stage['type'] == 'transform':
                current_data = stage['block'].process(current_data)
            elif stage['type'] == 'batch':
                current_data = stage['block'].process_batches(current_data, stage['processor'])
            
            end_time = time.time()
            print(f"  Completed in {end_time - start_time:.2f} seconds")
            print(f"  Output size: {len(current_data)} items")
        
        return current_data


# Example pipeline stages

def validate_number(x: int) -> int:
    """Validation transform: ensure number is positive."""
    time.sleep(0.1)  # Simulate validation work
    if x < 0:
        raise ValueError(f"Negative number not allowed: {x}")
    return x


def multiply_by_two(x: int) -> int:
    """Simple transform: multiply by 2."""
    time.sleep(0.05)
    return x * 2


def calculate_statistics(batch: List[int]) -> Dict[str, Any]:
    """Batch processor: calculate statistics for a batch of numbers."""
    time.sleep(0.2)  # Simulate statistical calculations
    
    if not batch:
        return {'error': 'Empty batch'}
    
    return {
        'count': len(batch),
        'sum': sum(batch),
        'mean': sum(batch) / len(batch),
        'min': min(batch),
        'max': max(batch),
        'range': max(batch) - min(batch)
    }


def process_text_batch(batch: List[str]) -> Dict[str, Any]:
    """Batch processor: analyze a batch of text strings."""
    time.sleep(0.3)
    
    return {
        'batch_size': len(batch),
        'total_chars': sum(len(s) for s in batch),
        'total_words': sum(len(s.split()) for s in batch),
        'longest_string': max(batch, key=len) if batch else '',
        'shortest_string': min(batch, key=len) if batch else '',
        'concatenated': ' '.join(batch)
    }


def normalize_text(text: str) -> str:
    """Transform: normalize text (lowercase, strip whitespace)."""
    time.sleep(0.02)
    return text.lower().strip()


def extract_words(text: str) -> List[str]:
    """Transform: extract words from text."""
    time.sleep(0.03)
    return text.split()


def simulate_api_call(data: Any) -> Dict[str, Any]:
    """Transform: simulate calling an external API."""
    time.sleep(random.uniform(0.1, 0.5))  # Simulate variable API response time
    
    return {
        'input': str(data),
        'api_response': f"API_RESULT_{hash(str(data)) % 1000}",
        'processing_time': random.uniform(0.1, 0.5),
        'timestamp': time.time()
    }


if __name__ == "__main__":
    print("=== Pipeline Example: Combining Batch and Transform Blocks ===\n")
    
    # Example 1: Numeric processing pipeline
    print("1. Numeric Processing Pipeline:")
    print("   Input -> Validate -> Multiply by 2 -> Batch Statistics")
    
    numbers = list(range(1, 21))  # 1 to 20
    print(f"Input data: {numbers}")
    
    numeric_pipeline = (Pipeline()
                       .add_transform_stage(validate_number, max_workers=3, stage_name="Validation")
                       .add_transform_stage(multiply_by_two, max_workers=3, stage_name="Multiply by 2")
                       .add_batch_stage(5, calculate_statistics, max_workers=2, stage_name="Statistics"))
    
    start_time = time.time()
    numeric_results = numeric_pipeline.process(numbers)
    total_time = time.time() - start_time
    
    print(f"\nTotal pipeline time: {total_time:.2f} seconds")
    print("Final results:")
    for i, result in enumerate(numeric_results):
        print(f"  Batch {i+1}: {result}")
    
    print("\n" + "="*70 + "\n")
    
    # Example 2: Text processing pipeline
    print("2. Text Processing Pipeline:")
    print("   Input -> Normalize -> Batch Process -> API Simulation")
    
    texts = [
        "Hello World", "Python Programming", "Concurrent Futures",
        "Batch Processing", "Transform Blocks", "Pipeline Example",
        "Data Flow", "Parallel Computing", "Task Parallel Library",
        "Asynchronous Programming"
    ]
    print(f"Input texts: {texts}")
    
    text_pipeline = (Pipeline()
                    .add_transform_stage(normalize_text, max_workers=3, stage_name="Text Normalization")
                    .add_batch_stage(3, process_text_batch, max_workers=2, stage_name="Text Analysis")
                    .add_transform_stage(simulate_api_call, max_workers=4, stage_name="API Simulation"))
    
    start_time = time.time()
    text_results = text_pipeline.process(texts)
    total_time = time.time() - start_time
    
    print(f"\nTotal pipeline time: {total_time:.2f} seconds")
    print("Final results (first 3):")
    for i, result in enumerate(text_results[:3]):
        print(f"  Result {i+1}: {result}")
    
    print("\n" + "="*70 + "\n")
    
    # Example 3: Complex data processing pipeline
    print("3. Complex Data Processing Pipeline:")
    print("   Numbers -> Validate -> Transform -> Batch -> API Calls")
    
    # Generate some test data with potential invalid values
    complex_data = list(range(-5, 16))  # -5 to 15 (includes negative numbers)
    print(f"Input data: {complex_data}")
    
    def safe_validate_number(x: int) -> int:
        """Validate number but filter out negatives instead of raising error."""
        time.sleep(0.02)
        return x if x >= 0 else None
    
    def filter_none_values(data: List[Any]) -> List[Any]:
        """Helper to filter out None values between stages."""
        return [item for item in data if item is not None]
    
    def square_and_format(x: int) -> str:
        """Transform number to formatted string."""
        time.sleep(0.03)
        return f"squared_{x*x}"
    
    def batch_string_processor(batch: List[str]) -> Dict[str, Any]:
        """Process a batch of formatted strings."""
        time.sleep(0.15)
        return {
            'batch_items': batch,
            'total_length': sum(len(s) for s in batch),
            'processed_count': len(batch)
        }
    
    # Build and execute complex pipeline
    complex_pipeline = Pipeline()
    
    # First, validate and filter
    validated_data = TransformBlock(safe_validate_number, max_workers=3).process(complex_data)
    filtered_data = filter_none_values(validated_data)
    print(f"After validation and filtering: {filtered_data}")
    
    # Continue with pipeline
    complex_pipeline = (Pipeline()
                       .add_transform_stage(square_and_format, max_workers=3, stage_name="Square & Format")
                       .add_batch_stage(4, batch_string_processor, max_workers=2, stage_name="String Batch Processing")
                       .add_transform_stage(simulate_api_call, max_workers=3, stage_name="Final API Calls"))
    
    start_time = time.time()
    complex_results = complex_pipeline.process(filtered_data)
    total_time = time.time() - start_time
    
    print(f"\nTotal pipeline time: {total_time:.2f} seconds")
    print("Final results:")
    for i, result in enumerate(complex_results):
        print(f"  API Result {i+1}: Input='{result['input']}', Response='{result['api_response']}'")
    
    print("\n" + "="*70 + "\n")
    
    # Example 4: Performance comparison
    print("4. Performance Comparison: Pipeline vs Sequential")
    
    def simple_process(x: int) -> int:
        """Simple processing function for comparison."""
        time.sleep(0.1)
        return x * 2
    
    def simple_batch_process(batch: List[int]) -> List[int]:
        """Simple batch processing function."""
        time.sleep(0.2)
        return [x * 3 for x in batch]
    
    test_data = list(range(1, 13))  # 12 items
    
    # Sequential processing
    print("Sequential processing:")
    start_time = time.time()
    sequential_results = []
    
    # Transform stage
    transformed = [simple_process(x) for x in test_data]
    
    # Batch stage
    batch_size = 4
    for i in range(0, len(transformed), batch_size):
        batch = transformed[i:i+batch_size]
        batch_result = simple_batch_process(batch)
        sequential_results.extend(batch_result)
    
    sequential_time = time.time() - start_time
    
    # Pipeline processing
    print("Pipeline processing:")
    pipeline = (Pipeline()
               .add_transform_stage(simple_process, max_workers=3, stage_name="Transform")
               .add_batch_stage(4, simple_batch_process, max_workers=2, stage_name="Batch"))
    
    start_time = time.time()
    pipeline_results = pipeline.process(test_data)
    
    # Flatten results since batch processing returns list of lists
    flattened_results = []
    for result in pipeline_results:
        if isinstance(result, list):
            flattened_results.extend(result)
        else:
            flattened_results.append(result)
    
    pipeline_time = time.time() - start_time
    
    print(f"\nSequential time: {sequential_time:.2f} seconds")
    print(f"Pipeline time: {pipeline_time:.2f} seconds")
    print(f"Speedup: {sequential_time / pipeline_time:.2f}x")
    print(f"Results match: {len(sequential_results) == len(flattened_results)}")
