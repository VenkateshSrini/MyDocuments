﻿using System;

namespace A.BankingApp
{
    public class Class1
    {
    }
}
