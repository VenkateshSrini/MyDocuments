﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Steeltoe.Extensions.Configuration.CloudFoundry;

namespace Dotnet.RabbitMQ.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        
        private CloudFoundryServicesOptions CloudFoundryServices { get; set; }
        private CloudFoundryApplicationOptions CloudFoundryApplication { get; set; }
        private ILogger<HomeController> logger;
        public HomeController (IOptions<CloudFoundryServicesOptions> cfServicesOptions, 
            IOptions<CloudFoundryApplicationOptions> cfAppsOptions, ILogger<HomeController> logger)
        {
            CloudFoundryServices = cfServicesOptions.Value;
            CloudFoundryApplication = cfAppsOptions.Value;
            this.logger = logger;
        }
        [HttpGet]
        public void Get()
        {
            
            if (CloudFoundryApplication!=null)
            {
                logger.LogInformation("***************application variable***************");
                logger.LogInformation(JsonSerializer.Serialize(CloudFoundryApplication));
               
            }
            if(CloudFoundryServices!=null)
            {
                logger.LogInformation("***************service variable***************");
                logger.LogInformation(JsonSerializer.Serialize(CloudFoundryServices));
                var service = CloudFoundryServices.ServicesList.FirstOrDefault(srvc => srvc.Name == "env-service")
                    .Credentials.FirstOrDefault().Value;
                logger.LogInformation("***************service credential value***************");
                logger.LogInformation(service.Value);
            }
        }
    }
}