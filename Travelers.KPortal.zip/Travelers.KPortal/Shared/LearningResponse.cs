﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Travelers.KPortal.Shared
{
    public class LearningResponse
    {
        public List<Learning> Learnings { get; set; }
        public string UserName { get; set; }
    }
}
