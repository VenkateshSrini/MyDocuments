﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Travelers.KPortal.Shared
{
    public class Learning
    {
        public string StyleName { get; set; }
        public string ImageUrl { get; set; }
        public string TopicSynopsis { get; set; }
        public string LearningUrl { get; set; }
        
    }
}
