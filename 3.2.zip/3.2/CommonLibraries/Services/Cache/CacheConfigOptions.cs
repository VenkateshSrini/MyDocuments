﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibraries.Services.Cache
{
    public class CacheConfigOptions
    {
        public int SyncTimeput { get; set; }

        public double TimeToLiveInSeconds { get; set; }
    }
}
