﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Travelers.KPortal.Shared;
namespace Travelers.KPortal.Server.Configuration
{
    public class LearningDetails
    {
        public List<Learning> Learnings { get; set; }
    }
}
