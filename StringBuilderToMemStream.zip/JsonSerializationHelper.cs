﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace StringBuilderToMemStream
{
    internal static class JsonSerializationHelper
    {
        private static SemaphoreSlim semaphoreSlimforSerialization = new SemaphoreSlim(1, 1);
        private static SemaphoreSlim semaphoreSlimforDeserialization = new SemaphoreSlim(1, 1);
        public static async Task<Stream> SerializeAsync<T>(T obj)
        {
            await semaphoreSlimforSerialization.WaitAsync();
            var memoryStream = new MemoryStream();
            try
            {
                var sw = new StreamWriter(memoryStream, Encoding.UTF8);
                var jw = new JsonTextWriter(sw);
                var serializer = new JsonSerializer();
                serializer.Serialize(jw, obj);
                jw.Flush();
                memoryStream.Position = 0;
                return memoryStream;
            }
            finally
            {
                semaphoreSlimforSerialization.Release();
            }
        }
        public static async Task<T> DeserializeAsync<T>(Stream stream)
        {
            await semaphoreSlimforDeserialization.WaitAsync();
            try
            {
                var sr = new StreamReader(stream, Encoding.UTF8);
                var jr = new JsonTextReader(sr);
                var serializer = new JsonSerializer();
                return serializer.Deserialize<T>(jr);
            }
            finally
            {
                semaphoreSlimforDeserialization.Release();
            }
        }
    }
}
