﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibraries.Services.Cache
{
    public interface IRemoteCache
    {
        string Get(string key, string field); 

        void Set(string key, string field, string value);

        IEnumerable<string> GetValues(string key);

        long Count(string key);

        long IncrementKey(string key, string field);

        bool Delete(string key);

        bool SetExpiry(string key, TimeSpan expiry);
    }
}
