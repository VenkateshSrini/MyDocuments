﻿// See https://aka.ms/new-console-template for more information
using Serialiation.PB.Console;

Console.WriteLine("Hello, World!");
await ProtoBaseSerialization.Run();