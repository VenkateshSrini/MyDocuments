"""
Advanced Producer-Consumer Patterns using concurrent.futures
Demonstrates advanced TPL-like patterns including producer-consumer scenarios
"""

import concurrent.futures
import time
import queue
import threading
from typing import List, Callable, Any, Optional
import random


class ProducerConsumerPipeline:
    """
    Advanced producer-consumer pipeline using concurrent.futures.
    Similar to TPL Dataflow's producer-consumer patterns.
    """
    
    def __init__(self, max_queue_size: int = 100):
        self.queue = queue.Queue(maxsize=max_queue_size)
        self.producers_done = threading.Event()
        self.results = []
        self.results_lock = threading.Lock()
    
    def add_producer(self, producer_func: Callable[[], List[Any]], executor: concurrent.futures.Executor):
        """Add a producer that generates items."""
        future = executor.submit(self._run_producer, producer_func)
        return future
    
    def add_consumer(self, consumer_func: Callable[[Any], Any], executor: concurrent.futures.Executor, num_consumers: int = 1):
        """Add consumers that process items."""
        futures = []
        for _ in range(num_consumers):
            future = executor.submit(self._run_consumer, consumer_func)
            futures.append(future)
        return futures
    
    def _run_producer(self, producer_func: Callable[[], List[Any]]):
        """Run a producer function."""
        try:
            items = producer_func()
            for item in items:
                self.queue.put(item)
        finally:
            self.producers_done.set()
    
    def _run_consumer(self, consumer_func: Callable[[Any], Any]):
        """Run a consumer function."""
        while True:
            try:
                # Wait for item or timeout
                item = self.queue.get(timeout=1.0)
                result = consumer_func(item)
                
                with self.results_lock:
                    self.results.append(result)
                
                self.queue.task_done()
                
            except queue.Empty:
                # If producers are done and queue is empty, exit
                if self.producers_done.is_set() and self.queue.empty():
                    break
                continue
    
    def wait_completion(self, producer_futures: List, consumer_futures: List):
        """Wait for all producers and consumers to complete."""
        # Wait for producers
        for future in producer_futures:
            future.result()
        
        # Wait for queue to be empty
        self.queue.join()
        
        # Cancel consumers (they'll exit naturally when queue is empty)
        for future in consumer_futures:
            future.cancel()
        
        return self.results


class DataFlowBlock:
    """
    Generic dataflow block that can be chained together.
    Similar to TPL Dataflow blocks.
    """
    
    def __init__(self, processor_func: Callable[[Any], Any], max_workers: int = None, max_queue_size: int = 100):
        self.processor_func = processor_func
        self.max_workers = max_workers
        self.input_queue = queue.Queue(maxsize=max_queue_size)
        self.output_queue = queue.Queue(maxsize=max_queue_size)
        self.is_processing = False
        self.next_block = None
    
    def link_to(self, next_block: 'DataFlowBlock'):
        """Link this block to the next block in the pipeline."""
        self.next_block = next_block
        return next_block
    
    def post(self, item: Any):
        """Post an item to this block for processing."""
        self.input_queue.put(item)
    
    def start_processing(self):
        """Start processing items from the input queue."""
        if self.is_processing:
            return
        
        self.is_processing = True
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = []
            
            # Start worker threads
            for _ in range(self.max_workers or 1):
                future = executor.submit(self._process_items)
                futures.append(future)
            
            # Wait for all workers to complete
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    print(f"Worker error: {e}")
    
    def _process_items(self):
        """Process items from the input queue."""
        while True:
            try:
                item = self.input_queue.get(timeout=1.0)
                
                # Process the item
                result = self.processor_func(item)
                
                # Send result to next block or output queue
                if self.next_block:
                    self.next_block.post(result)
                else:
                    self.output_queue.put(result)
                
                self.input_queue.task_done()
                
            except queue.Empty:
                # Check if we should continue processing
                if not self.is_processing:
                    break
                continue
    
    def complete(self):
        """Signal that no more items will be posted."""
        self.is_processing = False
        
        # Wait for input queue to be empty
        self.input_queue.join()
        
        # Signal next block to complete
        if self.next_block:
            self.next_block.complete()
    
    def get_results(self) -> List[Any]:
        """Get all results from the output queue."""
        results = []
        while True:
            try:
                result = self.output_queue.get_nowait()
                results.append(result)
            except queue.Empty:
                break
        return results


# Example functions for demonstrations

def data_producer() -> List[int]:
    """Producer that generates data."""
    print("Producer: Generating data...")
    time.sleep(0.5)  # Simulate data generation time
    data = list(range(1, 21))  # Generate 20 items
    print(f"Producer: Generated {len(data)} items")
    return data


def slow_data_producer() -> List[str]:
    """Slow producer that generates data over time."""
    print("Slow Producer: Starting data generation...")
    data = []
    for i in range(10):
        time.sleep(0.2)  # Simulate slow generation
        data.append(f"item_{i}")
        print(f"Slow Producer: Generated item_{i}")
    print("Slow Producer: Finished")
    return data


def data_consumer(item: Any) -> dict:
    """Consumer that processes data items."""
    time.sleep(0.1)  # Simulate processing time
    result = {
        'original': item,
        'processed': item * 2 if isinstance(item, int) else f"processed_{item}",
        'timestamp': time.time()
    }
    print(f"Consumer: Processed {item}")
    return result


def validation_processor(item: int) -> int:
    """First stage: validate data."""
    time.sleep(0.05)
    if item < 0:
        raise ValueError(f"Invalid item: {item}")
    return item


def transformation_processor(item: int) -> str:
    """Second stage: transform data."""
    time.sleep(0.1)
    return f"transformed_{item ** 2}"


def aggregation_processor(item: str) -> dict:
    """Third stage: aggregate/analyze data."""
    time.sleep(0.15)
    return {
        'input': item,
        'length': len(item),
        'hash': hash(item),
        'uppercase': item.upper()
    }


if __name__ == "__main__":
    print("=== Advanced Producer-Consumer Patterns ===\n")
    
    # Example 1: Basic Producer-Consumer
    print("1. Basic Producer-Consumer Pattern:")
    
    pipeline = ProducerConsumerPipeline(max_queue_size=50)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        # Start producer
        producer_futures = [pipeline.add_producer(data_producer, executor)]
        
        # Start consumers
        consumer_futures = pipeline.add_consumer(data_consumer, executor, num_consumers=3)
        
        # Wait for completion
        start_time = time.time()
        results = pipeline.wait_completion(producer_futures, consumer_futures)
        end_time = time.time()
    
    print(f"Processed {len(results)} items in {end_time - start_time:.2f} seconds")
    print(f"First 3 results: {results[:3]}")
    
    print("\n" + "="*60 + "\n")
    
    # Example 2: Multi-stage DataFlow Pipeline
    print("2. Multi-stage DataFlow Pipeline:")
    print("   Input -> Validation -> Transformation -> Aggregation -> Output")
    
    # Create pipeline stages
    validation_block = DataFlowBlock(validation_processor, max_workers=2)
    transformation_block = DataFlowBlock(transformation_processor, max_workers=2)
    aggregation_block = DataFlowBlock(aggregation_processor, max_workers=2)
    
    # Link blocks together
    validation_block.link_to(transformation_block).link_to(aggregation_block)
    
    # Post input data
    input_data = list(range(1, 11))
    print(f"Input data: {input_data}")
    
    for item in input_data:
        validation_block.post(item)
    
    # Start processing in separate threads
    import threading
    
    validation_thread = threading.Thread(target=validation_block.start_processing)
    transformation_thread = threading.Thread(target=transformation_block.start_processing)
    aggregation_thread = threading.Thread(target=aggregation_block.start_processing)
    
    start_time = time.time()
    
    validation_thread.start()
    transformation_thread.start()
    aggregation_thread.start()
    
    # Complete the pipeline
    validation_block.complete()
    
    # Wait for all stages to complete
    validation_thread.join()
    transformation_thread.join()
    aggregation_thread.join()
    
    end_time = time.time()
    
    # Get results
    final_results = aggregation_block.get_results()
    print(f"Pipeline completed in {end_time - start_time:.2f} seconds")
    print(f"Results: {len(final_results)} items processed")
    print("First 3 results:")
    for result in final_results[:3]:
        print(f"  {result}")
    
    print("\n" + "="*60 + "\n")
    
    # Example 3: Multiple Producers, Single Consumer
    print("3. Multiple Producers, Single Consumer:")
    
    def number_producer(start: int, count: int) -> List[int]:
        """Producer that generates a range of numbers."""
        time.sleep(0.3)
        numbers = list(range(start, start + count))
        print(f"Number Producer ({start}-{start+count-1}): Generated {len(numbers)} numbers")
        return numbers
    
    def string_producer(prefix: str, count: int) -> List[str]:
        """Producer that generates strings."""
        time.sleep(0.4)
        strings = [f"{prefix}_{i}" for i in range(count)]
        print(f"String Producer ({prefix}): Generated {len(strings)} strings")
        return strings
    
    def universal_consumer(item: Any) -> dict:
        """Consumer that can handle different types."""
        time.sleep(0.05)
        return {
            'item': item,
            'type': type(item).__name__,
            'str_representation': str(item),
            'processed_at': time.time()
        }
    
    multi_pipeline = ProducerConsumerPipeline(max_queue_size=100)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        # Start multiple producers
        producer_futures = [
            multi_pipeline.add_producer(lambda: number_producer(1, 10), executor),
            multi_pipeline.add_producer(lambda: number_producer(100, 8), executor),
            multi_pipeline.add_producer(lambda: string_producer("data", 12), executor),
            multi_pipeline.add_producer(lambda: string_producer("test", 6), executor)
        ]
        
        # Start single consumer
        consumer_futures = multi_pipeline.add_consumer(universal_consumer, executor, num_consumers=1)
        
        # Wait for completion
        start_time = time.time()
        results = multi_pipeline.wait_completion(producer_futures, consumer_futures)
        end_time = time.time()
    
    print(f"Processed {len(results)} items from multiple producers in {end_time - start_time:.2f} seconds")
    
    # Group results by type
    by_type = {}
    for result in results:
        item_type = result['type']
        by_type.setdefault(item_type, []).append(result)
    
    for item_type, items in by_type.items():
        print(f"  {item_type}: {len(items)} items")
    
    print("\n" + "="*60 + "\n")
    
    # Example 4: Error Handling in Pipeline
    print("4. Error Handling in Pipeline:")
    
    def error_prone_processor(item: int) -> str:
        """Processor that sometimes fails."""
        time.sleep(0.05)
        
        if item % 7 == 0:  # Simulate error for multiples of 7
            raise ValueError(f"Processing error for item {item}")
        
        return f"success_{item}"
    
    def safe_processor_wrapper(processor_func: Callable) -> Callable:
        """Wrapper that handles errors gracefully."""
        def wrapper(item: Any) -> dict:
            try:
                result = processor_func(item)
                return {'status': 'success', 'result': result, 'error': None}
            except Exception as e:
                return {'status': 'error', 'result': None, 'error': str(e)}
        return wrapper
    
    # Test error handling
    error_test_data = list(range(1, 22))  # Includes multiples of 7
    safe_processor = safe_processor_wrapper(error_prone_processor)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(safe_processor, error_test_data))
    
    # Analyze results
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'error']
    
    print(f"Processed {len(error_test_data)} items:")
    print(f"  Successful: {len(successful)}")
    print(f"  Failed: {len(failed)}")
    print("Failed items:")
    for failure in failed:
        print(f"  Error: {failure['error']}")
    
    print("\nSuccessful results (first 5):")
    for success in successful[:5]:
        print(f"  {success['result']}")
