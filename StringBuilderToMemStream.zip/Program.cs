﻿// See https://aka.ms/new-console-template for more information
using System.Text;

Console.WriteLine("Hello, World!");

MemoryStream StringBuilderToMemoryStream(StringBuilder sb, Encoding encoding)
{
    var ms = new MemoryStream();
    var sw = new StreamWriter(ms, encoding);

    // Write the StringBuilder to the MemoryStream in chunks
    const int chunkSize = 1024; // Adjust this value as needed
    for (int i = 0; i < sb.Length; i += chunkSize)
    {
        
        int len = Math.Min(chunkSize, sb.Length - i);
        sw.Write(sb.ToString(i, len));
        sw.Flush(); // Ensure the last chunk is written to the MemoryStream
    }

    ms.Position = 0; // Reset the MemoryStream position to the start
    return ms;
}
