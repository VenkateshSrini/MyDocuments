﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;

using Steeltoe.Common.HealthChecks;
using Microsoft.Extensions.Logging;
using Steeltoe.Connector;
using Steeltoe.Connector.Services;
using Steeltoe.Connector.Redis;

namespace CommonLibraries.Services.Cache
{
    public static class RedisCacheServiceCollectionExtensions
    {
        public static IServiceCollection AddSingletonRedisConnectionMultiplexer(this IServiceCollection services,
            IConfiguration configuration)
        {
            if (services == null)
                throw new ArgumentNullException(nameof(services));
            if (configuration == null)
                throw new ArgumentNullException(nameof(configuration));

            var redisConfig = new RedisCacheConnectorOptionsExt(configuration);
            var syncTimeoutConfig = configuration.GetSection("CacheConfiguration")["SyncTimeout"];
            if (!string.IsNullOrEmpty(syncTimeoutConfig))
            {
                if (int.TryParse(syncTimeoutConfig, out var timeout))
                    redisConfig.SyncTimeout = timeout;
                else
                    throw new ArgumentException("Timeout must be integer and greater than or equal to 1.");
            }
            var info = configuration.GetSingletonServiceInfo<RedisServiceInfo>();
            var redisInterface = RedisTypeLocator.StackExchangeInterface;
            var redisImplementation = RedisTypeLocator.StackExchangeImplementation;
            var redisOptions = RedisTypeLocator.StackExchangeOptions;
            var initializer = RedisTypeLocator.StackExchangeInitializer;
            var factory = new RedisServiceConnectorFactory(info, redisConfig, redisImplementation, redisOptions, initializer);

            var healthType = Type.GetType("Steeltoe.Common.HealthChecks.IHealthContributor, Steeltoe.Common.Abstractions");
            services.AddSingleton(typeof(IConnectionMultiplexer), factory.Create);

            services.Add(new ServiceDescriptor(healthType,
                            ctx => new RedisHealthContributor(factory, redisImplementation, 
                            ctx.GetService<ILogger<RedisHealthContributor>>()),ServiceLifetime.Singleton));
            return services;
        }

        public static IServiceCollection AddSingletonRedisConnectionMultiplexer_NoHealthCheck(this IServiceCollection services,
            IConfiguration configuration)
        {
            if (services == null)
                throw new ArgumentNullException(nameof(services));
            if (configuration == null)
                throw new ArgumentNullException(nameof(configuration));

            var redisConfig = new RedisCacheConnectorOptionsExt(configuration);
            var syncTimeoutConfig = configuration.GetSection("CacheConfiguration")["SyncTimeout"];
            if (!string.IsNullOrEmpty(syncTimeoutConfig))
            {
                if (int.TryParse(syncTimeoutConfig, out var timeout))
                    redisConfig.SyncTimeout = timeout;
                else
                    throw new ArgumentException("Timeout must be integer and greater than or equal to 1.");
            }

            var info = configuration.GetSingletonServiceInfo<RedisServiceInfo>();
            var redisInterface = RedisTypeLocator.StackExchangeInterface;
            var redisImplementation = RedisTypeLocator.StackExchangeImplementation;
            var redisOptions = RedisTypeLocator.StackExchangeOptions;
            var initializer = RedisTypeLocator.StackExchangeInitializer;
            var factory = new RedisServiceConnectorFactory(info, redisConfig, redisImplementation, redisOptions, initializer);
            services.AddSingleton(typeof(IConnectionMultiplexer), factory.Create);

            return services;
        }

        public static IServiceCollection AddSingletonTlsRedisConnectionMultiplexer(this IServiceCollection services,
            IConfiguration configuration)
        {
            if(services == null)
                throw new ArgumentNullException(nameof(services));
            if(configuration == null)
                throw new ArgumentNullException(nameof(configuration));

            var redisConfig = new RedisCacheConnectorOptionsExt(configuration);
            var syncTimeoutConfig = configuration.GetSection("CacheConfiguration")["SyncTimeout"];
            if(!string.IsNullOrEmpty(syncTimeoutConfig))
            {
                if (int.TryParse(syncTimeoutConfig, out var timeout))
                    redisConfig.SyncTimeout = timeout;
                else
                    throw new ArgumentException("Timeout must be integer and greater than or equal to 1.");
            }

            var info = configuration.GetSingletonServiceInfo<RedisServiceInfo>();

            Type redisInterface = RedisTypeLocator.StackExchangeInterface;
            Type redisImplementation = RedisTypeLocator.StackExchangeImplementation;
            Type redisOptions = RedisTypeLocator.StackExchangeOptions;
            MethodInfo initializer = RedisTypeLocator.StackExchangeInitializer;

            var factory = new StackExchangeRedisFactory(info, redisConfig, redisImplementation, redisOptions, initializer);
            services.AddSingleton(typeof(IConnectionMultiplexer), factory.Create);
            services.Add(new ServiceDescriptor(typeof(IHealthContributor),
                ctx => new RedisHealthContributor(factory, redisImplementation,
                ctx.GetService<ILogger<RedisHealthContributor>>())
                , ServiceLifetime.Singleton));

            return services;
        }

        public static IServiceCollection AddRawRedisMultiplexer(this IServiceCollection services, 
            IConfiguration configuration)
        {
            ConfigurationOptions configurationOptions = new ConfigurationOptions
            {
                ServiceName = configuration["CacheConfiguration:service-name"],
                SyncTimeout = int.Parse(configuration["CacheConfiguration:sync-timeout"]),
                Password = configuration["CacheConfiguration:password"]
            };

            configurationOptions.EndPoints.Add($"{configuration["CacheConfiguration:host"]}:" + 
                $"{configuration["CacheConfiguration:port"]}"); 

            var connectionMultiplexer = ConnectionMultiplexer.Connect(configurationOptions);
            var time = double.Parse(configuration["CacheConfiguration:timeToLiveInSeconds"]);
            services.AddSingleton<IConnectionMultiplexer>(connectionMultiplexer);

            return services;
        }
    }
}
