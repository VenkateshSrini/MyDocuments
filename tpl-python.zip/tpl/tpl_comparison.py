"""
TPL to Python concurrent.futures Comparison
Shows equivalent patterns between .NET TPL and Python concurrent.futures
"""

import concurrent.futures
import time
from typing import List, Callable, Any


def demonstrate_tpl_equivalents():
    """
    Demonstrates Python equivalents of common TPL patterns.
    """
    
    print("=== TPL to Python concurrent.futures Equivalents ===\n")
    
    # Sample data for demonstrations
    numbers = list(range(1, 11))
    
    print("Sample data:", numbers)
    print("\n" + "="*60 + "\n")
    
    # 1. Task.Run equivalent
    print("1. Task.Run Equivalent:")
    print("   C# TPL: Task.Run(() => SomeWork())")
    print("   Python: executor.submit(some_work)")
    
    def some_work(x):
        time.sleep(0.1)
        return x * x
    
    # Python equivalent using ThreadPoolExecutor
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future = executor.submit(some_work, 5)
        result = future.result()
        print(f"   Result: {result}")
    
    print("\n" + "-"*40 + "\n")
    
    # 2. Parallel.ForEach equivalent
    print("2. Parallel.ForEach Equivalent:")
    print("   C# TPL: Parallel.ForEach(collection, item => Process(item))")
    print("   Python: executor.map(process_func, collection)")
    
    def process_item(x):
        time.sleep(0.05)
        return x * 2
    
    start_time = time.time()
    
    # Sequential version
    sequential_results = [process_item(x) for x in numbers]
    sequential_time = time.time() - start_time
    
    # Parallel version
    start_time = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        parallel_results = list(executor.map(process_item, numbers))
    parallel_time = time.time() - start_time
    
    print(f"   Sequential time: {sequential_time:.3f}s")
    print(f"   Parallel time: {parallel_time:.3f}s")
    print(f"   Results match: {sequential_results == parallel_results}")
    
    print("\n" + "-"*40 + "\n")
    
    # 3. Task.WhenAll equivalent
    print("3. Task.WhenAll Equivalent:")
    print("   C# TPL: await Task.WhenAll(tasks)")
    print("   Python: concurrent.futures.as_completed(futures)")
    
    def async_work(x):
        time.sleep(0.1 * x)  # Variable delay
        return f"completed_{x}"
    
    start_time = time.time()
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        # Submit all tasks
        futures = [executor.submit(async_work, x) for x in range(1, 6)]
        
        # Wait for all to complete (equivalent to WhenAll)
        results = [future.result() for future in futures]
    
    total_time = time.time() - start_time
    print(f"   All tasks completed in: {total_time:.3f}s")
    print(f"   Results: {results}")
    
    print("\n" + "-"*40 + "\n")
    
    # 4. Task.WhenAny equivalent
    print("4. Task.WhenAny Equivalent:")
    print("   C# TPL: await Task.WhenAny(tasks)")
    print("   Python: concurrent.futures.as_completed(futures) - first result")
    
    def variable_work(x):
        delay = [0.3, 0.1, 0.5, 0.2, 0.4][x-1]  # Different delays
        time.sleep(delay)
        return f"task_{x}_completed"
    
    start_time = time.time()
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(variable_work, x) for x in range(1, 6)]
        
        # Get first completed task (equivalent to WhenAny)
        for future in concurrent.futures.as_completed(futures):
            first_result = future.result()
            first_time = time.time() - start_time
            break
    
    print(f"   First task completed in: {first_time:.3f}s")
    print(f"   First result: {first_result}")
    
    print("\n" + "-"*40 + "\n")
    
    # 5. ActionBlock equivalent (Consumer pattern)
    print("5. ActionBlock Equivalent:")
    print("   C# TPL: var actionBlock = new ActionBlock<T>(item => Process(item))")
    print("   Python: ThreadPoolExecutor with submit for each item")
    
    def action_processor(item):
        time.sleep(0.05)
        print(f"     Processed: {item}")
        return item
    
    print("   Processing items:")
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(action_processor, x) for x in range(1, 6)]
        
        # Wait for all actions to complete
        for future in concurrent.futures.as_completed(futures):
            future.result()  # Just to ensure completion
    
    print("\n" + "-"*40 + "\n")
    
    # 6. TransformBlock equivalent
    print("6. TransformBlock Equivalent:")
    print("   C# TPL: var transformBlock = new TransformBlock<TInput, TOutput>(input => Transform(input))")
    print("   Python: Custom TransformBlock class (see transform_block_example.py)")
    
    def transform_function(x):
        time.sleep(0.02)
        return x ** 2
    
    # Simple transform using map
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        transformed = list(executor.map(transform_function, numbers[:5]))
    
    print(f"   Input: {numbers[:5]}")
    print(f"   Transformed: {transformed}")
    
    print("\n" + "-"*40 + "\n")
    
    # 7. BatchBlock equivalent
    print("7. BatchBlock Equivalent:")
    print("   C# TPL: var batchBlock = new BatchBlock<T>(batchSize)")
    print("   Python: Custom BatchBlock class (see batch_block_example.py)")
    
    def create_batches(items, batch_size):
        for i in range(0, len(items), batch_size):
            yield items[i:i + batch_size]
    
    def process_batch(batch):
        time.sleep(0.1)
        return sum(batch)
    
    batches = list(create_batches(numbers, 3))
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        batch_results = list(executor.map(process_batch, batches))
    
    print(f"   Batches: {batches}")
    print(f"   Batch sums: {batch_results}")
    
    print("\n" + "="*60 + "\n")
    
    # Summary of key differences
    print("Key Differences Summary:")
    print("=" * 30)
    print("• TPL uses async/await, Python uses futures and executors")
    print("• TPL has built-in dataflow blocks, Python requires custom classes")
    print("• TPL integrates with C# language features, Python uses library approach")
    print("• Both provide similar parallel processing capabilities")
    print("• Python's approach is more explicit about thread/process management")


if __name__ == "__main__":
    demonstrate_tpl_equivalents()
