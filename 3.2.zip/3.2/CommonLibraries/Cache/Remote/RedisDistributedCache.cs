﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StackExchange.Redis;
using Microsoft.Extensions.Logging;

namespace CommonLibraries.Cache.Remote
{
    public class RedisDistributedCache : IDistributedCache
    {
        private IConnectionMultiplexer _conMultiplexer;
        private ILogger<RedisDistributedCache> _logger; 
        public RedisDistributedCache(ConnectionMultiplexer conMultiplexer, ILogger<RedisDistributedCache> logger)
        {
            this._conMultiplexer = conMultiplexer;
            this._logger = logger;
            logger.LogInformation($"connection multiplexer config {_conMultiplexer.Configuration}");
        }

        public bool Delete(string key)
        {
            return _conMultiplexer.GetDatabase().KeyDelete(key);
        }

        public string Get(string key, string subKey)
        {
          var result =   _conMultiplexer.GetDatabase().HashGet(key, subKey);
            return result.HasValue ? result.ToString() : "";
        }

        public void Set(string key, string field, string value)
        {
            _conMultiplexer.GetDatabase().HashSet(key, field, value);
        }

        public bool SetExpiry(string key, TimeSpan expiry)
        {
            return _conMultiplexer.GetDatabase().KeyExpire(key, expiry);
        }
    }
}
