﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Steeltoe.Common.HealthChecks;

using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using Steeltoe.Connector.Redis;

namespace CommonLibraries.Services.Cache
{
    public class RedisHealthContributor : IHealthContributor
    {
        private readonly ILogger<RedisHealthContributor> _logger;
        private readonly Type _implementationType;
        private readonly RedisServiceConnectorFactory _factory;

        private bool IsMicroSoftImplementation => _implementationType.FullName.Contains("Microsoft");
        public static IHealthContributor GetRedisContributor(RedisServiceConnectorFactory redisFactory, Type redisImplementation,
            ILogger<RedisHealthContributor> logger = null)
        {
            return new RedisHealthContributor(redisFactory, redisImplementation, logger); 
        }

        public RedisHealthContributor(RedisServiceConnectorFactory factory, Type implementaionType, ILogger<RedisHealthContributor> logger = null)
        {
            _factory = factory;
            _implementationType = implementaionType;
            _logger = logger;  
        }

        public string Id => IsMicroSoftImplementation ? "Redis-Cache" : "Redis";

        private void DoMicrosoftHealth()
        {
            var connector = _factory.Create(null);
            var getMethod = connector.GetType().GetMethod("Get");
            getMethod.Invoke(connector, new object[] { "1" }); 
        }

        private void DoStackExchangeHealth(HealthCheckResult result)
        {
            var connectionMultiplexer = _factory.Create(null) as ConnectionMultiplexer;
            if (connectionMultiplexer == null)
                throw new ApplicationException("Unable to create multiplexer object");
            else
            {
                using(connectionMultiplexer)
                {
                    var redisDb = connectionMultiplexer.GetDatabase(-1);
                    var latency = redisDb.Ping(CommandFlags.None);
                    result.Details.Add("ping", latency.TotalMilliseconds);
                }
            }
        }

        public HealthCheckResult Health()
        {
            _logger?.LogTrace("Checking Redis Connection Health");

            HealthCheckResult result = new HealthCheckResult();
            try 
            {
                if(IsMicroSoftImplementation)
                {
                    DoMicrosoftHealth();
                }
                else 
                {
                    DoStackExchangeHealth(result);
                }

                result.Details.Add("status", HealthStatus.UP.ToString());
                result.Status = HealthStatus.UP;
                _logger?.LogTrace("Redis Connection up!");
            }
            catch (Exception ex)
            {
                if(ex is TargetInvocationException)
                {
                    ex = ex.InnerException;
                }

                _logger.LogError($"Redis Connection down ", ex.Message);
                result.Details.Add("error", ex.GetType().Name + ":" + ex.Message);
                result.Details.Add("status", HealthStatus.DOWN.ToString());
                result.Status = HealthStatus.DOWN;
                result.Description = "Redis Health Check failed";
            }

            return result;
        }
    }
}
