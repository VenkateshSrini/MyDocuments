﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLibraries.Cache.Remote
{
    public interface IDistributedCache
    {
        void Set(string key, string field, string value);
        string Get(string key, string field);
        bool Delete(string key);
        bool SetExpiry(string key, TimeSpan expiry);
    }   
}
