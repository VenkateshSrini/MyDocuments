﻿namespace TaskApi.Unit.Test.Repository
{
    internal class User
    {
    }
}