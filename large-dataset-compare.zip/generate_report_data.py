from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

import pandas as pd
import duckdb
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from datetime import datetime
import os
@dataclass
class ReportGenerator:
    master_data_frame: pd.DataFrame
    mod_data_frame: pd.DataFrame
    output_dir: Path = Path("reports")
    report_filename: str = "sales_report.pdf"

    def __generate_data(self) -> None:
        group_cols = ["Region", "Country", "Item Type", "Sales Channel"]
        profit_col = "Total Profit"

        # Direct aggregation on original DataFrames - no copying/cloning
        # Extract and convert profit columns directly during groupby
        m_grp = (
            self.master_data_frame.groupby(group_cols, observed=True)[profit_col]
            .agg(lambda x: pd.to_numeric(x, errors="coerce").sum())
            .rename("Base Profit")
            .reset_index()
        )
        
        n_grp = (
            self.mod_data_frame.groupby(group_cols, observed=True)[profit_col] 
            .agg(lambda x: pd.to_numeric(x, errors="coerce").sum())
            .rename("Current Profit")
            .reset_index()
        )

        # Create the minimal third DataFrame with only required data
        # Start with unique keys from master (no copying - just the keys)
        base_keys = self.master_data_frame[group_cols].drop_duplicates().reset_index(drop=True)
        
        # Optimize grouping columns memory in the result
        for col in group_cols:
            base_keys[col] = base_keys[col].astype("category")
        
        # Memory-efficient merges to build the third DataFrame
        df = base_keys.merge(m_grp, on=group_cols, how="left")
        df = df.merge(n_grp, on=group_cols, how="left")
        df[["Base Profit", "Current Profit"]] = df[["Base Profit", "Current Profit"]].fillna(0)

        # Vectorized trend calculation (faster than apply)
        base_profit = df["Base Profit"]
        current_profit = df["Current Profit"]
        df["trends"] = "-"  # Default
        df.loc[base_profit > current_profit, "trends"] = "↓"
        df.loc[base_profit < current_profit, "trends"] = "↑"

        # Store the minimal third DataFrame
        self.report_df = df

    def build_report(self) -> pd.DataFrame:
        self.__generate_data()
        return self.report_df
    
    def build_detailed_report(self) -> pd.DataFrame:
        """Generate detailed report with individual records (not aggregated)"""
        self.__generate_detailed_data()
        return self.detailed_report_df

    def __generate_detailed_data(self) -> pd.DataFrame:
        """Generate detailed report with all individual records"""
        
        # Add unique identifier to both datasets for proper matching
        master_df = self.master_data_frame.copy()
        mod_df = self.mod_data_frame.copy()
        
        # Create matching key from multiple columns to identify same transactions
        key_cols = ['Region', 'Country', 'Item Type', 'Sales Channel', 'Order ID', 'Order Date']
        
        master_df['match_key'] = master_df[key_cols].astype(str).agg('|'.join, axis=1)
        mod_df['match_key'] = mod_df[key_cols].astype(str).agg('|'.join, axis=1)
        
        # Convert profit columns to numeric
        master_df['Base Profit'] = pd.to_numeric(master_df['Total Profit'], errors='coerce').fillna(0)
        mod_df['Current Profit'] = pd.to_numeric(mod_df['Total Profit'], errors='coerce').fillna(0)
        
        # Merge on the match key to align individual records
        # Only include the columns we want in the final report (excluding Order ID, Order Date, Units Sold, Sales Channel)
        detailed_df = master_df[['Region', 'Country', 'Item Type', 'Base Profit', 'match_key']].merge(
            mod_df[['Current Profit', 'match_key']], 
            on='match_key', 
            how='left'
        )
        
        # Fill missing values
        detailed_df['Current Profit'] = detailed_df['Current Profit'].fillna(0)
        
        # Calculate trends for individual records
        detailed_df['trends'] = (
            (detailed_df['Base Profit'] < detailed_df['Current Profit']).astype(int).map({0: '↓', 1: '↑'})
        )
        detailed_df.loc[detailed_df['Base Profit'] == detailed_df['Current Profit'], 'trends'] = '-'
        
        # Remove the temporary match_key column
        detailed_df = detailed_df.drop('match_key', axis=1)
        
        # Store the result
        self.detailed_report_df = detailed_df
        return detailed_df

    def __generate_pdf(self, dataFrame: pd.DataFrame) -> None:
        """Generate a PDF report from the DataFrame"""
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from datetime import datetime
        import os
        
        # Create output directory if it doesn't exist
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Full path for the PDF file
        pdf_path = self.output_dir / self.report_filename
        
        # Create the PDF document
        doc = SimpleDocTemplate(str(pdf_path), pagesize=A4)
        elements = []
        
        # Get styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        
        # Add title
        title = Paragraph("Sales Trend Analysis Report", title_style)
        elements.append(title)
        
        # Add generation timestamp
        timestamp = Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal'])
        elements.append(timestamp)
        elements.append(Spacer(1, 20))
        
        # Add summary statistics
        total_records = len(dataFrame)
        up_trends = len(dataFrame[dataFrame['trends'] == '↑'])
        down_trends = len(dataFrame[dataFrame['trends'] == '↓'])
        stable_trends = len(dataFrame[dataFrame['trends'] == '-'])
        
        summary_data = [
            ['Metric', 'Value'],
            ['Total Records', f'{total_records:,}'],
            ['Upward Trends (↑)', f'{up_trends:,}'],
            ['Downward Trends (↓)', f'{down_trends:,}'],
            ['Stable Trends (-)', f'{stable_trends:,}'],
            ['Total Base Profit', f'${dataFrame["Base Profit"].sum():,.2f}'],
            ['Total Current Profit', f'${dataFrame["Current Profit"].sum():,.2f}']
        ]
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(Spacer(1, 30))
        
        # Add detailed data table (all rows with pagination)
        total_rows = len(dataFrame)
        detail_title = Paragraph(f"Detailed Sales Trend Data (All {total_rows:,} Records)", styles['Heading2'])
        elements.append(detail_title)
        elements.append(Spacer(1, 10))
        
        # For large datasets, create multiple tables across pages
        rows_per_page = 35  # Optimal rows per page for readability
        
        for page_start in range(0, total_rows, rows_per_page):
            page_end = min(page_start + rows_per_page, total_rows)
            page_df = dataFrame.iloc[page_start:page_end].copy()
            
            # Format numbers for this page
            page_df['Base Profit'] = page_df['Base Profit'].apply(lambda x: f'${x:,.2f}')
            page_df['Current Profit'] = page_df['Current Profit'].apply(lambda x: f'${x:,.2f}')
            
            # Add page header if multiple pages
            if total_rows > rows_per_page:
                page_header = Paragraph(f"Records {page_start + 1:,} - {page_end:,}", styles['Heading3'])
                elements.append(page_header)
                elements.append(Spacer(1, 5))
            
            # Convert DataFrame to list for reportlab
            if page_start == 0:  # Include headers only on first page
                data = [page_df.columns.tolist()] + page_df.values.tolist()
                header_rows = 1
            else:
                data = page_df.values.tolist()
                header_rows = 0
            
            # Create the data table for this page
            col_widths = [1.2*inch, 1.2*inch, 1*inch, 1*inch, 0.8*inch, 0.8*inch, 0.4*inch]
            
            data_table = Table(data, colWidths=col_widths)
            
            # Apply styling
            table_style = [
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ROWBACKGROUNDS', (0, header_rows), (-1, -1), [colors.white, colors.lightgrey])
            ]
            
            # Add header styling only if headers are included
            if header_rows > 0:
                table_style.extend([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 8),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ])
            
            data_table.setStyle(TableStyle(table_style))
            elements.append(data_table)
            
            # Add page break between tables (except for the last one)
            if page_end < total_rows:
                from reportlab.platypus import PageBreak
                elements.append(PageBreak())
        
        # Build the PDF
        doc.build(elements)
        
        print(f"PDF report generated successfully: {pdf_path}")
        print(f"Report contains {total_records} records")
        
    def generate_pdf_report(self, dataFrame: pd.DataFrame = None) -> None:
        """Public method to generate PDF report"""
        if dataFrame is None:
            dataFrame = self.build_report()
        self.__generate_pdf(dataFrame)
    
    def generate_detailed_pdf_report(self) -> None:
        """Generate PDF report with all individual records"""
        detailed_df = self.build_detailed_report()
        # Use a different filename for detailed report
        original_filename = self.report_filename
        self.report_filename = "detailed_sales_report.pdf"
        self.__generate_pdf(detailed_df)
        self.report_filename = original_filename  # Restore original


@dataclass 
class DuckDBReportGenerator:
    """Memory-efficient report generator using DuckDB"""
    duckdb_connection: duckdb.DuckDBPyConnection
    output_dir: Path = Path("reports")
    report_filename: str = "sales_report.pdf"

    def build_report(self) -> pd.DataFrame:
        self.report_df = self.__generate_data()
        return self.report_df

    def __generate_data(self) -> pd.DataFrame:
        """Generate report using DuckDB SQL - extremely memory efficient"""
        
        # Single SQL query that does all the work without loading data into memory
        query = """
        WITH master_agg AS (
            SELECT 
                Region, 
                Country, 
                "Item Type", 
                "Sales Channel",
                SUM(TRY_CAST("Total Profit" AS DOUBLE)) as "Base Profit"
            FROM master 
            GROUP BY Region, Country, "Item Type", "Sales Channel"
        ),
        mod_agg AS (
            SELECT 
                Region, 
                Country, 
                "Item Type", 
                "Sales Channel",
                SUM(TRY_CAST("Total Profit" AS DOUBLE)) as "Current Profit"
            FROM mod 
            GROUP BY Region, Country, "Item Type", "Sales Channel"
        )
        SELECT 
            m.Region, 
            m.Country, 
            m."Item Type", 
            m."Sales Channel",
            COALESCE(m."Base Profit", 0) as "Base Profit",
            COALESCE(n."Current Profit", 0) as "Current Profit",
            CASE 
                WHEN COALESCE(m."Base Profit", 0) = COALESCE(n."Current Profit", 0) THEN '-'
                WHEN COALESCE(m."Base Profit", 0) > COALESCE(n."Current Profit", 0) THEN '↓' 
                ELSE '↑'
            END as trends
        FROM master_agg m
        LEFT JOIN mod_agg n USING (Region, Country, "Item Type", "Sales Channel")
        ORDER BY m.Region, m.Country, m."Item Type", m."Sales Channel"
        """
        
        # Execute and return as pandas DataFrame (only the final result is in memory)
        return self.duckdb_connection.execute(query).df()
    
    def __generate_pdf(self, dataFrame: pd.DataFrame) -> None:
        """Generate a PDF report from the DataFrame"""
        
        
        # Create output directory if it doesn't exist
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Full path for the PDF file
        pdf_path = self.output_dir / self.report_filename
        
        # Create the PDF document
        doc = SimpleDocTemplate(str(pdf_path), pagesize=A4)
        elements = []
        
        # Get styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        
        # Add title
        title = Paragraph("Sales Trend Analysis Report (DuckDB)", title_style)
        elements.append(title)
        
        # Add generation timestamp
        timestamp = Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal'])
        elements.append(timestamp)
        elements.append(Spacer(1, 20))
        
        # Add summary statistics
        total_records = len(dataFrame)
        up_trends = len(dataFrame[dataFrame['trends'] == '↑'])
        down_trends = len(dataFrame[dataFrame['trends'] == '↓'])
        stable_trends = len(dataFrame[dataFrame['trends'] == '-'])
        
        summary_data = [
            ['Metric', 'Value'],
            ['Total Records', f'{total_records:,}'],
            ['Upward Trends (↑)', f'{up_trends:,}'],
            ['Downward Trends (↓)', f'{down_trends:,}'],
            ['Stable Trends (-)', f'{stable_trends:,}'],
            ['Total Base Profit', f'${dataFrame["Base Profit"].sum():,.2f}'],
            ['Total Current Profit', f'${dataFrame["Current Profit"].sum():,.2f}']
        ]
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(Spacer(1, 30))
        
        # Add detailed data table (all rows with pagination)
        total_rows = len(dataFrame)
        detail_title = Paragraph(f"Detailed Sales Trend Data (All {total_rows:,} Records)", styles['Heading2'])
        elements.append(detail_title)
        elements.append(Spacer(1, 10))
        
        # For large datasets, create multiple tables across pages
        rows_per_page = 35  # Optimal rows per page for readability
        
        for page_start in range(0, total_rows, rows_per_page):
            page_end = min(page_start + rows_per_page, total_rows)
            page_df = dataFrame.iloc[page_start:page_end].copy()
            
            # Format numbers for this page
            page_df['Base Profit'] = page_df['Base Profit'].apply(lambda x: f'${x:,.2f}')
            page_df['Current Profit'] = page_df['Current Profit'].apply(lambda x: f'${x:,.2f}')
            
            # Add page header if multiple pages
            if total_rows > rows_per_page:
                page_header = Paragraph(f"Records {page_start + 1:,} - {page_end:,}", styles['Heading3'])
                elements.append(page_header)
                elements.append(Spacer(1, 5))
            
            # Convert DataFrame to list for reportlab
            if page_start == 0:  # Include headers only on first page
                data = [page_df.columns.tolist()] + page_df.values.tolist()
                header_rows = 1
            else:
                data = page_df.values.tolist()
                header_rows = 0
            
            # Create the data table for this page
            col_widths = [1.2*inch, 1.2*inch, 1*inch, 1*inch, 0.8*inch, 0.8*inch, 0.4*inch]
            
            data_table = Table(data, colWidths=col_widths)
            
            # Apply styling
            table_style = [
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ROWBACKGROUNDS', (0, header_rows), (-1, -1), [colors.white, colors.lightgrey])
            ]
            
            # Add header styling only if headers are included
            if header_rows > 0:
                table_style.extend([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 8),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ])
            
            data_table.setStyle(TableStyle(table_style))
            elements.append(data_table)
            
            # Add page break between tables (except for the last one)
            if page_end < total_rows:
                from reportlab.platypus import PageBreak
                elements.append(PageBreak())
        
        # Build the PDF
        doc.build(elements)
        
        print(f"PDF report generated successfully: {pdf_path}")
        print(f"Report contains {total_records} records")
        
    def generate_pdf_report(self, dataFrame: pd.DataFrame = None) -> None:
        """Public method to generate PDF report"""
        if dataFrame is None:
            dataFrame = self.build_report()
        self.__generate_pdf(dataFrame)
    
    def cleanup(self) -> None:
        """Clean up DuckDB connection and free memory"""
        if self.duckdb_connection:
            try:
                # Drop all tables to free memory
                self.duckdb_connection.execute("DROP TABLE IF EXISTS master")
                self.duckdb_connection.execute("DROP TABLE IF EXISTS mod")
                
                # Close the connection
                self.duckdb_connection.close()
                print("DuckDB connection closed and memory cleaned up")
            except Exception as e:
                print(f"Warning: Error during DuckDB cleanup: {e}")
            finally:
                self.duckdb_connection = None
    
    def __del__(self) -> None:
        """Destructor to ensure cleanup on object deletion"""
        self.cleanup()
        