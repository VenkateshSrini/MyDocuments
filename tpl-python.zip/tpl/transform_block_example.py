"""
Transform Block Example using concurrent.futures
Equivalent to TPL's TransformBlock<TInput, TOutput> in .NET

This example demonstrates how to transform data streams using Python's concurrent.futures.
The TransformBlock applies a transformation function to each input item and produces output.
"""

import concurrent.futures
import time
import math
from typing import List, Any, Callable, TypeVar
from concurrent.futures import as_completed

# Type variables for generic transform block
TInput = TypeVar('TInput')
TOutput = TypeVar('TOutput')


class TransformBlock:
    """
    A transform processing block that applies a transformation function to items concurrently.
    
    Similar to TPL's TransformBlock<TInput, TOutput>, this applies a transformation
    to each input item and produces transformed output.
    """
    
    def __init__(self, transform_func: Callable[[TInput], TOutput], max_workers: int = None):
        """
        Initialize the transform block.
        
        Args:
            transform_func: Function to apply to each input item
            max_workers: Maximum number of worker threads (None for default)
        """
        self.transform_func = transform_func
        self.max_workers = max_workers
    
    def process(self, items: List[TInput]) -> List[TOutput]:
        """
        Process items through the transform function concurrently.
        
        Args:
            items: List of input items to transform
            
        Returns:
            List of transformed output items (order preserved)
        """
        if not items:
            return []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all items for processing, keeping track of original index
            future_to_index = {
                executor.submit(self.transform_func, item): index
                for index, item in enumerate(items)
            }
            
            # Create results list with same length as input
            results = [None] * len(items)
            
            # Collect results as they complete
            for future in as_completed(future_to_index):
                try:
                    result = future.result()
                    original_index = future_to_index[future]
                    results[original_index] = result
                except Exception as exc:
                    original_index = future_to_index[future]
                    print(f'Item at index {original_index} generated an exception: {exc}')
                    results[original_index] = None
            
            return results
    
    def process_stream(self, items: List[TInput]) -> List[TOutput]:
        """
        Process items as a stream, yielding results as they become available.
        Note: This version doesn't preserve order for better throughput.
        
        Args:
            items: List of input items to transform
            
        Returns:
            List of transformed output items (order not preserved)
        """
        if not items:
            return []
        
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all items for processing
            futures = [executor.submit(self.transform_func, item) for item in items]
            
            # Collect results as they complete (no order preservation)
            for future in as_completed(futures):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as exc:
                    print(f'An item generated an exception: {exc}')
        
        return results


# Example transformation functions

def square_transform(x: int) -> int:
    """Transform function that squares a number."""
    time.sleep(0.1)  # Simulate some processing time
    return x * x


def string_analysis_transform(text: str) -> dict:
    """Transform function that analyzes a string."""
    time.sleep(0.2)  # Simulate processing time
    
    return {
        'original': text,
        'length': len(text),
        'uppercase': text.upper(),
        'word_count': len(text.split()),
        'vowel_count': sum(1 for c in text.lower() if c in 'aeiou'),
        'is_palindrome': text.lower() == text.lower()[::-1]
    }


def math_transform(x: float) -> dict:
    """Transform function that performs various math operations."""
    time.sleep(0.3)  # Simulate complex calculations
    
    return {
        'input': x,
        'square': x * x,
        'sqrt': math.sqrt(abs(x)),
        'sin': math.sin(x),
        'cos': math.cos(x),
        'log': math.log(abs(x)) if x != 0 else None,
        'factorial': math.factorial(int(abs(x))) if x >= 0 and x <= 10 else None
    }


def web_request_transform(url: str) -> dict:
    """Simulate a web request transformation (without actual HTTP calls)."""
    time.sleep(0.5)  # Simulate network delay
    
    # Simulate different response times and status codes
    import random
    status_codes = [200, 200, 200, 404, 500]  # Mostly successful
    
    return {
        'url': url,
        'status_code': random.choice(status_codes),
        'response_time': random.uniform(0.1, 2.0),
        'content_length': random.randint(1000, 50000),
        'processed_at': time.time()
    }


if __name__ == "__main__":
    print("=== Transform Block Example ===\n")
    
    # Example 1: Simple numeric transformation
    print("1. Squaring numbers:")
    numbers = list(range(1, 11))
    print(f"Input numbers: {numbers}")
    
    square_transformer = TransformBlock(square_transform, max_workers=3)
    start_time = time.time()
    
    squared_results = square_transformer.process(numbers)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print(f"Results: {squared_results}")
    
    print("\n" + "="*50 + "\n")
    
    # Example 2: String analysis transformation
    print("2. Analyzing strings:")
    texts = ["hello", "world", "python", "concurrent", "programming"]
    print(f"Input texts: {texts}")
    
    text_transformer = TransformBlock(string_analysis_transform, max_workers=2)
    start_time = time.time()
    
    text_results = text_transformer.process(texts)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print("Results:")
    for result in text_results:
        print(f"  {result}")
    
    print("\n" + "="*50 + "\n")
    
    # Example 3: Math operations transformation
    print("3. Mathematical transformations:")
    math_inputs = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    print(f"Input numbers: {math_inputs}")
    
    math_transformer = TransformBlock(math_transform, max_workers=4)
    start_time = time.time()
    
    math_results = math_transformer.process(math_inputs)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print("Results (first 3):")
    for i, result in enumerate(math_results[:3]):
        print(f"  Input {i+1}: {result}")
    
    print("\n" + "="*50 + "\n")
    
    # Example 4: Simulated web requests
    print("4. Simulated web requests:")
    urls = [
        "https://api.example.com/users",
        "https://api.example.com/posts",
        "https://api.example.com/comments",
        "https://api.example.com/photos",
        "https://api.example.com/albums"
    ]
    print(f"URLs to process: {len(urls)} URLs")
    
    web_transformer = TransformBlock(web_request_transform, max_workers=3)
    start_time = time.time()
    
    web_results = web_transformer.process(urls)
    
    end_time = time.time()
    print(f"Processing completed in {end_time - start_time:.2f} seconds")
    print("Results:")
    for result in web_results:
        print(f"  {result['url']}: Status {result['status_code']}, "
              f"Time {result['response_time']:.2f}s")
    
    print("\n" + "="*50 + "\n")
    
    # Example 5: Comparing ordered vs stream processing
    print("5. Comparing ordered vs stream processing:")
    
    def slow_transform(x: int) -> str:
        """A slow transform to show the difference."""
        time.sleep(0.5)
        return f"processed_{x}"
    
    test_numbers = [1, 2, 3, 4, 5]
    
    # Ordered processing (preserves input order)
    print("Ordered processing (preserves order):")
    ordered_transformer = TransformBlock(slow_transform, max_workers=3)
    start_time = time.time()
    ordered_results = ordered_transformer.process(test_numbers)
    ordered_time = time.time() - start_time
    print(f"Results: {ordered_results}")
    print(f"Time: {ordered_time:.2f} seconds")
    
    # Stream processing (order not preserved, potentially faster)
    print("\nStream processing (order not preserved):")
    stream_transformer = TransformBlock(slow_transform, max_workers=3)
    start_time = time.time()
    stream_results = stream_transformer.process_stream(test_numbers)
    stream_time = time.time() - start_time
    print(f"Results: {stream_results}")
    print(f"Time: {stream_time:.2f} seconds")
