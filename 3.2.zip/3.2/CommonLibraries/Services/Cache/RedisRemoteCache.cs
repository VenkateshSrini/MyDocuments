﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace CommonLibraries.Services.Cache
{
    internal class RedisRemoteCache : IRemoteCache
    {
        private ILogger _logger;
        private IConnectionMultiplexer _connectionMultiplexer;
        public RedisRemoteCache(ILogger<RedisRemoteCache> logger, ConnectionMultiplexer connectionMultiplexter)
            : this(logger, (IConnectionMultiplexer)connectionMultiplexter)
        {

        }

        public RedisRemoteCache(ILogger<RedisRemoteCache> logger, IConnectionMultiplexer connectionMultiplexter)
        {
            _logger = logger;
            _connectionMultiplexer = connectionMultiplexter;
            logger.LogInformation($"connection multiplexer config:{connectionMultiplexter.Configuration}");
        }

        public long Count(string key)
        {
            throw new NotImplementedException();
        }

        public bool Delete(string key)
        {
            throw new NotImplementedException();
        }

        public string Get(string key, string field)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> GetValues(string key)
        {
            throw new NotImplementedException();
        }

        public long IncrementKey(string key, string field)
        {
            throw new NotImplementedException();
        }

        public void Set(string key, string field, string value)
        {
            throw new NotImplementedException();
        }

        public bool SetExpiry(string key, TimeSpan expiry)
        {
            throw new NotImplementedException();
        }
    }
}
