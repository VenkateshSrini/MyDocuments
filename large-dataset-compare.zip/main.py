from __future__ import annotations

import argparse
import time
import psutil
import os
from pathlib import Path

from csv_loader import CSVLoader
from generate_report_data import ReportGenerator, DuckDBReportGenerator


def get_memory_usage() -> float:
    """Get current process memory usage in MB"""
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024


def main() -> None:
    parser = argparse.ArgumentParser(description="Load two CSV files and report memory usage.")
    parser.add_argument("--file1", default="master_sales_record.csv", help="First CSV filename in data/ (default: master_sales_record.csv)")
    parser.add_argument("--file2", default="mod_sales_record.csv", help="Second CSV filename in data/ (default: mod_sales_record.csv)")
    parser.add_argument("--data-dir", default="data", help="Base data directory (default: data)")
    parser.add_argument("--generate-report", action="store_true", help="Generate sales trend report")
    parser.add_argument("--save-pdf", action="store_true", help="Save report as PDF file")
    parser.add_argument("--detailed-report", action="store_true", help="Generate detailed report with all individual records (~100k rows)")
    parser.add_argument("--memory-efficient", action="store_true", help="Use memory-efficient loading")
    parser.add_argument("--compare-engines", action="store_true", help="Compare pandas vs DuckDB performance")
    args = parser.parse_args()

    if args.compare_engines:
        print("=== PANDAS vs DUCKDB COMPARISON ===\n")
        
        # Measure pandas approach
        print("1. PANDAS APPROACH:")
        start_memory = get_memory_usage()
        start_time = time.time()
        
        loader = CSVLoader(data_dir=Path(args.data_dir))
        df1, df2 = loader.load_two(args.file1, args.file2)
        
        load_time = time.time() - start_time
        load_memory = get_memory_usage()
        
        rg = ReportGenerator(master_data_frame=df1, mod_data_frame=df2)
        report_df_pandas = rg.build_report()
        
        end_time = time.time()
        end_memory = get_memory_usage()
        
        print(f"   Loading time: {load_time:.2f}s")
        print(f"   Total time: {end_time - start_time:.2f}s")
        print(f"   Peak memory: {end_memory:.1f} MB")
        print(f"   Report rows: {len(report_df_pandas)}")
        
        # Clear pandas data
        del df1, df2, rg, report_df_pandas
        
        # Measure DuckDB approach  
        print("\n2. DUCKDB APPROACH:")
        start_memory = get_memory_usage()
        start_time = time.time()
        
        duckdb_conn = loader.load_two_duckdb(args.file1, args.file2)
        duckdb_rg = None
        
        try:
            load_time = time.time() - start_time
            load_memory = get_memory_usage()
            
            duckdb_rg = DuckDBReportGenerator(duckdb_connection=duckdb_conn)
            report_df_duckdb = duckdb_rg.build_report()
            
            end_time = time.time()
            end_memory = get_memory_usage()
            
            print(f"   Loading time: {load_time:.2f}s")
            print(f"   Total time: {end_time - start_time:.2f}s") 
            print(f"   Peak memory: {end_memory:.1f} MB")
            print(f"   Report rows: {len(report_df_duckdb)}")
            
            print("\n3. SAMPLE OUTPUT (DuckDB):")
            print(report_df_duckdb.head(10).to_string(index=False))
            
        finally:
            # Always clean up DuckDB connection and free memory
            if duckdb_rg:
                duckdb_rg.cleanup()
            else:
                # Fallback cleanup if DuckDBReportGenerator wasn't created
                loader.cleanup_duckdb_connection(duckdb_conn)
        
        return

    if args.generate_report:
        # Load DataFrames
        if args.memory_efficient:
            # Determine required columns based on report type
            if args.detailed_report:
                # For detailed reports, we need columns for matching but only show Region, Country, Item Type
                required_cols = ["Region", "Country", "Item Type", "Sales Channel", "Order ID", "Order Date", "Total Profit"]
            else:
                # For aggregated reports, we only need basic columns
                required_cols = ["Region", "Country", "Item Type", "Sales Channel", "Total Profit"]
                
            dtype_map = {
                "Region": "category",
                "Country": "category", 
                "Item Type": "category",
                "Sales Channel": "category",
            }
            loader = CSVLoader(data_dir=Path(args.data_dir))
            df1, df2 = loader.load_two(args.file1, args.file2, usecols=required_cols, dtype=dtype_map)
            print("Using memory-efficient loading for report generation...")
        else:
            loader = CSVLoader(data_dir=Path(args.data_dir))
            df1, df2 = loader.load_two(args.file1, args.file2)
        
        # Generate report using the optimized ReportGenerator
        rg = ReportGenerator(master_data_frame=df1, mod_data_frame=df2)
        
        if args.detailed_report:
            # Generate detailed report with all individual records
            report_df = rg.build_detailed_report()
            print(f"Generated DETAILED report with {len(report_df)} individual records")
            print("\nSample detailed report data:")
            print(report_df.head(10).to_string(index=False))
            
            # Generate PDF if requested
            if args.save_pdf:
                rg.generate_detailed_pdf_report()
        else:
            # Generate aggregated report (default)
            report_df = rg.build_report()
            print(f"Generated AGGREGATED report with {len(report_df)} rows")
            print("\nSample report data:")
            print(report_df.head(10).to_string(index=False))
            
            # Generate PDF if requested
            if args.save_pdf:
                rg.generate_pdf_report(report_df)
    else:
        # Memory usage reporting
        if args.memory_efficient:
            # Load only required columns for memory testing
            required_cols = ["Region", "Country", "Item Type", "Sales Channel", "Total Profit"]
            dtype_map = {
                "Region": "category",
                "Country": "category", 
                "Item Type": "category",
                "Sales Channel": "category",
            }
            loader = CSVLoader(data_dir=Path(args.data_dir))
            df1, df2 = loader.load_two(args.file1, args.file2, usecols=required_cols, dtype=dtype_map)
        else:
            loader = CSVLoader(data_dir=Path(args.data_dir))
            df1, df2 = loader.load_two(args.file1, args.file2)

        mem1 = loader.memory_bytes(df1)
        mem2 = loader.memory_bytes(df2)

        print(f"File 1: {args.file1}")
        print(f"  Rows: {len(df1):,}")
        print(f"  Memory: {loader.format_bytes(mem1)} ({mem1:,} bytes)")
        print()
        print(f"File 2: {args.file2}")
        print(f"  Rows: {len(df2):,}")
        print(f"  Memory: {loader.format_bytes(mem2)} ({mem2:,} bytes)")
        print()
        print("Combined:")
        print(f"  Total memory: {loader.format_bytes(mem1 + mem2)} ({mem1 + mem2:,} bytes)")


if __name__ == "__main__":
    main()
