﻿namespace TaskApi.Unit.Test.Repository
{
    internal class UsersContext
    {
        public object Users { get; internal set; }
    }
}