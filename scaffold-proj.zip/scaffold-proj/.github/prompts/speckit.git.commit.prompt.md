---
agent: speckit.git.commit
---
