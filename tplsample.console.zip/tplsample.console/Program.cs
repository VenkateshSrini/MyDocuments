﻿// See https://aka.ms/new-console-template for more information
using System.Threading.Tasks.Dataflow;
var batchBlock = new BatchBlock<int>(10);
var actionBlock = new ActionBlock<int>(batch =>
{
    batchBlock.Post(batch);
});
var printBlock = new ActionBlock<int[]>(batch =>
{
    Console.WriteLine($"Batch: {string.Join(", ", batch)}");
});
batchBlock.LinkTo(printBlock, new DataflowLinkOptions { PropagateCompletion=true});
var computeArr = Enumerable.Range(0, 17);
foreach (var item in computeArr)
{
    actionBlock.Post(item);
}
actionBlock.Complete();
actionBlock.Completion.Wait();
batchBlock.Complete();
printBlock.Completion.Wait();
