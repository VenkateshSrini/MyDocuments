﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StackExchange.Redis;
using Microsoft.Extensions.Configuration;
using Steeltoe.Connector.Redis;

namespace CommonLibraries.Services.Cache
{
    public class RedisCacheConnectorOptionsExt: RedisCacheConnectorOptions
    {
        public RedisCacheConnectorOptionsExt(IConfiguration config): base(config)
        {
            
        }

        public int SyncTimeout { get; set; } = new ConfigurationOptions().SyncTimeout;

        public override string ToString()
        {
            var options = base.ToString() + $", Sync Timeout={SyncTimeout}";
            return options;
        }
    }
}
