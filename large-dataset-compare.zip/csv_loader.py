from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

import pandas as pd
import duckdb


@dataclass
class CSVLoader:
    data_dir: Path = Path("data")

    def _resolve(self, filename: str | Path) -> Path:
        path = Path(filename)
        if not path.is_absolute():
            path = self.data_dir / path
        return path

    def load_two(self, file1: str | Path, file2: str | Path, 
                 usecols: list[str] | None = None, 
                 dtype: dict | None = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Load two CSV files with optional column/dtype optimization"""
        p1 = self._resolve(file1)
        p2 = self._resolve(file2)

        if not p1.exists():
            raise FileNotFoundError(f"File not found: {p1}")
        if not p2.exists():
            raise FileNotFoundError(f"File not found: {p2}")

        df1 = self._read_any_csv(p1, usecols=usecols, dtype=dtype)
        df2 = self._read_any_csv(p2, usecols=usecols, dtype=dtype)
        return df1, df2

    def _read_any_csv(self, path: Path, usecols: list[str] | None = None, dtype: dict | None = None) -> pd.DataFrame:
        """Read CSV with memory optimizations"""
        suffix = path.suffix.lower()
        
        # Common memory optimizations
        read_kwargs = {
            "usecols": usecols,
            "dtype": dtype,
            "low_memory": False,  # For consistent dtypes
        }
        
        if suffix == ".csv":
            return pd.read_csv(path, **read_kwargs)
        if suffix == ".zip":
            # Reads the (first) CSV inside the ZIP archive
            return pd.read_csv(path, compression="zip", **read_kwargs)
        # Fallback: try letting pandas infer
        return pd.read_csv(path, **read_kwargs)

    def load_two_duckdb(self, file1: str | Path, file2: str | Path) -> duckdb.DuckDBPyConnection:
        """Load two CSV files into DuckDB for memory-efficient processing"""
        p1 = self._resolve(file1)
        p2 = self._resolve(file2)

        if not p1.exists():
            raise FileNotFoundError(f"File not found: {p1}")
        if not p2.exists():
            raise FileNotFoundError(f"File not found: {p2}")

        # Create DuckDB connection (in-memory)
        conn = duckdb.connect()
        
        # Register CSV files as virtual tables (no loading into memory)
        conn.execute(f"CREATE TABLE master AS SELECT * FROM '{p1}'")
        conn.execute(f"CREATE TABLE mod AS SELECT * FROM '{p2}'")
        
        return conn

    def get_duckdb_memory_usage(self, conn: duckdb.DuckDBPyConnection) -> dict[str, int]:
        """Get memory usage information from DuckDB tables"""
        master_count = conn.execute("SELECT COUNT(*) FROM master").fetchone()[0]
        mod_count = conn.execute("SELECT COUNT(*) FROM mod").fetchone()[0]
        
        # DuckDB doesn't expose direct memory usage, so we estimate based on row counts
        # This is much more accurate than pandas memory_usage for large datasets
        return {
            "master_rows": master_count,
            "mod_rows": mod_count,
            "estimated_memory_bytes": (master_count + mod_count) * 200  # Rough estimate
        }

    @staticmethod
    def cleanup_duckdb_connection(conn: duckdb.DuckDBPyConnection) -> None:
        """Clean up DuckDB connection and free memory"""
        if conn:
            try:
                # Drop all tables to free memory
                conn.execute("DROP TABLE IF EXISTS master")
                conn.execute("DROP TABLE IF EXISTS mod")
                
                # Close the connection
                conn.close()
                print("DuckDB connection cleaned up")
            except Exception as e:
                print(f"Warning: Error during DuckDB cleanup: {e}")

    @staticmethod
    def memory_bytes(df: pd.DataFrame) -> int:
        return int(df.memory_usage(deep=True).sum())

    @staticmethod
    def format_bytes(num_bytes: int) -> str:
        units = ["B", "KB", "MB", "GB", "TB"]
        size = float(num_bytes)
        for unit in units:
            if size < 1024.0:
                return f"{size:,.2f} {unit}"
            size /= 1024.0
        return f"{size:,.2f} PB"
