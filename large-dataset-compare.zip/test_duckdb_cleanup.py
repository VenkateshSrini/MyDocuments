#!/usr/bin/env python3
"""
Test script to verify DuckDB connection cleanup is working properly
"""

import psutil
import os
from pathlib import Path
from csv_loader import CSVLoader
from generate_report_data import DuckDBReportGenerator


def get_memory_usage():
    """Get current process memory usage in MB"""
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024


def test_duckdb_cleanup():
    print("=== DuckDB Connection Cleanup Test ===\n")
    
    # Initial memory
    initial_memory = get_memory_usage()
    print(f"Initial memory: {initial_memory:.1f} MB")
    
    # Load data into DuckDB
    loader = CSVLoader(data_dir=Path("data"))
    duckdb_conn = loader.load_two_duckdb("master_sales_record.csv", "mod_sales_record.csv")
    
    after_load_memory = get_memory_usage()
    print(f"After loading data: {after_load_memory:.1f} MB (+{after_load_memory - initial_memory:.1f} MB)")
    
    # Generate report
    duckdb_rg = DuckDBReportGenerator(duckdb_connection=duckdb_conn)
    report_df = duckdb_rg.build_report()
    
    after_report_memory = get_memory_usage()
    print(f"After report generation: {after_report_memory:.1f} MB (+{after_report_memory - initial_memory:.1f} MB)")
    print(f"Report contains {len(report_df)} rows")
    
    # Clean up
    print("\nCleaning up DuckDB connection...")
    duckdb_rg.cleanup()
    
    after_cleanup_memory = get_memory_usage()
    print(f"After cleanup: {after_cleanup_memory:.1f} MB (+{after_cleanup_memory - initial_memory:.1f} MB)")
    
    # Summary
    print(f"\nMemory freed by cleanup: {after_report_memory - after_cleanup_memory:.1f} MB")
    print("✅ DuckDB cleanup test completed successfully!")


if __name__ == "__main__":
    test_duckdb_cleanup()