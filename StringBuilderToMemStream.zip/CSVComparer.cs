using Deedle;
using System;
using System.Linq;

class CSVComparer
{
    static void Compare(string leftFile, string rightFile, string indexColumn, IEnumerable<string>IgnoreColumns )
    {
        // Load the two CSV files
        // Load the two CSV files
        var df1 = Frame.ReadCsv(leftFile).IndexRowsWith(indexColumn);
        var df2 = Frame.ReadCsv(rightFile).IndexRowsWith(indexColumn);
        //// Create a new column that combines the values of the columns you want to index by
        //df.AddColumn("CombinedIndex", df["Column1"].Join(df["Column2"], (value1, value2) => value1 + "_" + value2));

        //// Index by the new column
        //df = df.IndexRowsWith("CombinedIndex");
        // Drop the columns that should be ignored
        foreach (var column in IgnoreColumns)
        {
            df1.DropColumn(column);
            df2.DropColumn(column);
        }
        // Group the rows by the index
        var grouped1 = df1.Rows.GroupBy(row => row.Key);
        var grouped2 = df2.Rows.GroupBy(row => row.Key);

        // Find groups which are different between the two dataframes
        var diff_df = grouped1.Where(g1 => !grouped2.ContainsKey(g1.Key) || !df1.Rows[g1.Key].Values.All(v => df2.Rows[g1.Key].Values.Contains(v)));
        var diffFrame = Frame.FromRecords(diff_df.Values.Select(group => group.Values));
        // Save the differing rows to a new CSV file
        diffFrame.SaveCsv("differences.csv");
        // Print differing groups

    }
}
