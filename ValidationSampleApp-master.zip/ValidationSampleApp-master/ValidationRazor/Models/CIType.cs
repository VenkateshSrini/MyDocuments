﻿namespace ValidationRazor.Models
{
    public enum CIType
    {
        Movie,
        Series,
        Short
    }
}