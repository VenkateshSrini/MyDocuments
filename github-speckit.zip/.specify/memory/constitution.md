<!--
Sync Impact Report:
===================
Version Change: Initial → 1.0.0
Modified Principles: N/A (initial version)
Added Sections: 
  - Core Principles (7 principles)
  - Technology Stack & Architecture Constraints
  - Development Workflow & Quality Gates
  - Governance

Removed Sections: N/A

Templates Requiring Updates:
  ✅ .specify/templates/plan-template.md - Constitution Check section aligned
  ✅ .specify/templates/spec-template.md - Requirements and user story format aligned
  ✅ .specify/templates/tasks-template.md - Task categorization aligned with principles

Follow-up TODOs: None
===================
-->

# Pizza Shop Application Constitution

## Core Principles

### I. Image-Driven UI Generation (NON-NEGOTIABLE)

Every UI implementation MUST originate from an input image placed in the `input-image/` directory.
The design, color scheme, layout, and visual elements MUST faithfully replicate the input image.
No creative liberties are permitted unless explicitly approved by stakeholders. The UI technology
MUST be React.js without exception.

**Rationale**: Ensures pixel-perfect design fidelity and predictable output from visual
specifications, eliminating ambiguity in UI requirements.

### II. Wireframe-First Design Validation

Before implementing any feature, a wireframe MUST be created and placed in the `wire-frames/`
directory. Wireframes MUST be self-contained single HTML files with embedded CSS that can be
opened directly in any browser without additional dependencies or build steps. Wireframes MUST
use stubbed data to demonstrate functionality and MUST preserve the exact color scheme from
the input image.

**Rationale**: Enables rapid design validation and stakeholder feedback without requiring full
development environment setup, accelerating the approval cycle.

### III. Backend-for-Frontend Dual Implementation

Every BFF (Backend-for-Frontend) API MUST be implemented in BOTH Python and .NET 8, with each
implementation residing in separate directories. Both implementations MUST provide identical
REST API contracts, functionality, and behavior. HTTP MUST be used for all UI-to-backend
communication without exception.

**Rationale**: Provides technology flexibility, enables comparative performance analysis, and
ensures teams skilled in either language can contribute without barriers.

### IV. gRPC Internal Communication (NON-NEGOTIABLE)

All server-side API-to-API communication MUST use gRPC without TLS. HTTP-based inter-service
communication is explicitly forbidden for backend services. The gRPC schema (.proto files)
MUST be versioned and stored in a shared schemas directory accessible to all services.

**Rationale**: Maximizes inter-service communication performance through binary protocols while
reducing network overhead; TLS omitted for internal network performance optimization.

### V. Swagger-Enabled APIs with Test UI

Every API endpoint MUST be documented and exposed through Swagger/OpenAPI. The Swagger UI MUST
be enabled in all environments (development, staging, production) and MUST allow direct testing
of endpoints without requiring external tools. API documentation MUST include request/response
examples, error codes, and authentication requirements.

**Rationale**: Enables self-service API exploration and testing, reducing support overhead and
accelerating integration efforts for consumers.

### VI. Test Coverage Across All Layers

Both server-side and client-side code MUST include comprehensive test suites covering unit,
integration, and end-to-end scenarios. Tests MUST be executable via standard test runners
(pytest for Python, xUnit/NUnit for .NET, Jest for React). Minimum code coverage thresholds:
80% for backend services, 70% for React components.

**Rationale**: Ensures reliability, facilitates refactoring confidence, and provides executable
documentation of expected behavior.

### VII. Documentation-at-Generation

All code generation activities MUST produce corresponding documentation in the `documents/`
folder at the time of code creation, not as an afterthought. Documentation MUST include
architecture diagrams, API contracts, deployment instructions, and troubleshooting guides.
Documentation format MUST be Markdown for version control compatibility.

**Rationale**: Prevents documentation debt, ensures knowledge capture during peak context
availability, and maintains documentation accuracy through version control.

## Technology Stack & Architecture Constraints

### Frontend

- **Framework**: React.js (latest stable version)
- **Styling**: CSS modules or styled-components (preserve input image color scheme)
- **Build Tool**: Vite or Create React App
- **Testing**: Jest + React Testing Library
- **Directory**: `/frontend` or `/ui`

### Backend-for-Frontend (Dual Implementation)

- **Python Implementation**:
  - Framework: FastAPI or Flask
  - Directory: `/bff-python`
  - Testing: pytest, pytest-asyncio
  - Documentation: Auto-generated via FastAPI/Flask-RESTX

- **.NET Implementation**:
  - Framework: ASP.NET Core 8
  - Directory: `/bff-dotnet`
  - Testing: xUnit or NUnit
  - Documentation: Swashbuckle (Swagger)

### Inter-Service Communication

- **Protocol**: gRPC (no TLS for internal communication)
- **Schema Location**: `/grpc-schemas` (shared .proto files)
- **Code Generation**: Automated via protoc for both Python and .NET

### Documentation

- **Location**: `/documents`
- **Format**: Markdown (.md files)
- **Required Artifacts**: Architecture diagrams, API contracts, setup guides, troubleshooting

### Wireframes

- **Location**: `/wire-frames`
- **Format**: Single HTML file with embedded CSS (no external dependencies)
- **Naming**: `{feature-name}-wireframe.html`

## Development Workflow & Quality Gates

### Phase 0: Design Input Validation

1. Input image MUST be placed in `input-image/` directory
2. Color palette MUST be extracted and documented
3. Layout dimensions and component hierarchy MUST be documented

### Phase 1: Wireframe Creation

1. Create self-contained HTML wireframe in `wire-frames/`
2. Embed all CSS within HTML file (no external stylesheets)
3. Use stubbed data to demonstrate interactions
4. Validate wireframe opens correctly in Chrome, Firefox, and Edge
5. Obtain stakeholder approval before proceeding

### Phase 2: API Contract Definition

1. Define REST API endpoints for BFF services
2. Define gRPC .proto files for inter-service communication
3. Document in `/documents/api-contracts.md`
4. Generate Swagger documentation

### Phase 3: Test-First Implementation

1. Write failing tests for all layers (unit, integration, e2e)
2. Obtain approval on test scenarios
3. Implement code to pass tests (Red-Green-Refactor cycle)
4. Verify code coverage meets minimum thresholds (80% backend, 70% frontend)

### Phase 4: Dual BFF Implementation

1. Implement Python BFF first (reference implementation)
2. Implement .NET BFF to match Python behavior exactly
3. Run contract tests to verify identical behavior
4. Document any platform-specific considerations

### Phase 5: Documentation & Deployment

1. Generate all documentation in `/documents` folder
2. Create architecture diagrams showing system components
3. Write deployment and troubleshooting guides
4. Verify Swagger UI accessibility in all environments

### Quality Gates (Must Pass Before Merge)

- [ ] Wireframe approved by stakeholders
- [ ] All tests passing with minimum coverage thresholds
- [ ] Swagger UI functional and complete
- [ ] Both Python and .NET BFF implementations pass identical contract tests
- [ ] gRPC schemas validated and versioned
- [ ] Documentation complete in `/documents` folder
- [ ] Code review completed by at least one peer

## Governance

This constitution supersedes all other development practices, guidelines, and conventions. Any
deviation from these principles MUST be documented, justified with technical rationale, and
approved by project leadership before implementation.

### Amendment Procedure

1. Proposed amendments MUST be submitted via pull request to `.specify/memory/constitution.md`
2. Amendments MUST include: rationale, impact analysis, migration plan for existing code
3. Amendments require approval from at least two project maintainers
4. Version MUST be incremented per semantic versioning rules:
   - MAJOR: Principle removal or redefinition that breaks existing workflows
   - MINOR: New principle addition or material expansion of existing principles
   - PATCH: Clarifications, typo fixes, non-semantic refinements

### Compliance Verification

All pull requests and code reviews MUST explicitly verify compliance with this constitution.
Any complexity violations (e.g., skipping tests, omitting documentation) MUST be justified
in writing within the pull request description and approved by project leadership.

### Runtime Development Guidance

Developers MUST consult `.github/agents/` for agent-specific workflows and `.specify/templates/`
for template structures when executing development tasks.

**Version**: 1.0.0 | **Ratified**: 2026-01-25 | **Last Amended**: 2026-01-25
