import os
import asyncio
from dotenv import load_dotenv
from code_generator import CodeGenerator

# Load environment variables
load_dotenv(override=True)


async def main():
    """Main function to run the code generation agent."""
    print("GitHub Copilot Code Generator")
    print("=" * 50)
    print("\nUsing model:", os.getenv("GITHUB_COPILOT_MODEL", "gpt-5.2"))
    print("\nTip: Set GITHUB_COPILOT_MODEL in .env to use a different model")
    print("     (e.g., gpt-5.2, gpt-4o, claude-sonnet-4, o1, etc.)\n")
    
    # Initialize the code generator
    generator = CodeGenerator()
    
    try:
        # Interactive mode
        while True:
            print("\nEnter your code generation prompt (or 'quit' to exit):")
            prompt = input("> ").strip()
            
            if prompt.lower() in ['quit', 'exit', 'q']:
                print("Goodbye!")
                break
            
            if not prompt:
                print("Please enter a valid prompt.")
                continue
            
            try:
                print("\nGenerating code...")
                result = await generator.generate(prompt)
                print("\nGenerated Response:")
                print("-" * 50)
                print(result)
                print("-" * 50)
            except Exception as e:
                print(f"\nError: {e}")
                import traceback
                traceback.print_exc()
    finally:
        # Clean up resources
        await generator.close()


if __name__ == "__main__":
    asyncio.run(main())